<?php

namespace CYA\YogaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CYAYogaBundle extends Bundle
{
}
