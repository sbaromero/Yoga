<?php

namespace CYA\YogaBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class TipocuotaControllerTest extends WebTestCase
{
}
