<?php

namespace CYA\YogaBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class RubroControllerTest extends WebTestCase
{
}
