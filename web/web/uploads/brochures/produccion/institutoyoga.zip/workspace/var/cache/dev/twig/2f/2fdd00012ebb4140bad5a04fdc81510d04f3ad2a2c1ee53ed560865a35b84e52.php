<?php

/* CYAYogaBundle:Alumnocc:detallepagopublic.html.twig */
class __TwigTemplate_c68927f00e52fffa68fe70fd9da4dae77266304e50f392dbab5b02db4f579ddd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Alumnocc:detallepagopublic.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_292c2758de17317103877303501438ba7be8940c2c2f4157cebb44a05c04c889 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_292c2758de17317103877303501438ba7be8940c2c2f4157cebb44a05c04c889->enter($__internal_292c2758de17317103877303501438ba7be8940c2c2f4157cebb44a05c04c889_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Alumnocc:detallepagopublic.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_292c2758de17317103877303501438ba7be8940c2c2f4157cebb44a05c04c889->leave($__internal_292c2758de17317103877303501438ba7be8940c2c2f4157cebb44a05c04c889_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_318cfc42a97fe6357c687dd2b87aa0fcf26f9aded08a2973132ae6cc8ceed9a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_318cfc42a97fe6357c687dd2b87aa0fcf26f9aded08a2973132ae6cc8ceed9a3->enter($__internal_318cfc42a97fe6357c687dd2b87aa0fcf26f9aded08a2973132ae6cc8ceed9a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Alumnocc:detallepagopublic.html.twig"));

        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/danger.html.twig");
        echo "
    <div class=\"container-fluid cuenta\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Detalle</h2>
                </div>
                <div class=\"col-sm-7\">
                    <form action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_indexpublic");
        echo "\" class=\"btn btn-success\">
                            Regresar al listado
                        </a>

        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

                            <th>";
        // line 35
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Fecha", "m.fecha");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 36
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Monto", "m.monto");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 37
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Descripcion", "m.descripcion");
        echo "</th>
\t\t\t\t\t\t\t<th>Usuario</th>

                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["movimiento"]) {
            // line 44
            echo "                                
                                <td>";
            // line 45
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["movimiento"], "fecha", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td> \$ ";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "monto", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "descripcion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["movimiento"], "usuario", array()), "nombrecompleto", array()), "html", null, true);
            echo "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['movimiento'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "                    </tbody>
                </table>
           <H4> Total Cuotas: ";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                <div class=\"navigation\">
                    ";
        // line 55
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_318cfc42a97fe6357c687dd2b87aa0fcf26f9aded08a2973132ae6cc8ceed9a3->leave($__internal_318cfc42a97fe6357c687dd2b87aa0fcf26f9aded08a2973132ae6cc8ceed9a3_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Alumnocc:detallepagopublic.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 55,  131 => 53,  127 => 51,  118 => 48,  114 => 47,  110 => 46,  106 => 45,  103 => 44,  99 => 43,  90 => 37,  86 => 36,  82 => 35,  60 => 16,  48 => 7,  44 => 6,  40 => 5,  34 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

  
{% block body %}
{{ parent() }}
{{ include('CYAYogaBundle:Alumnocc:messages/success.html.twig')}}
{{ include('CYAYogaBundle:Alumnocc:messages/danger.html.twig')}}
    <div class=\"container-fluid cuenta\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Detalle</h2>
                </div>
                <div class=\"col-sm-7\">
                    <form action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <a href=\"{{ path('cya_alumnocc_indexpublic') }}\" class=\"btn btn-success\">
                            Regresar al listado
                        </a>

        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

                            <th>{{ knp_pagination_sortable(pagination, 'Fecha', 'm.fecha') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Monto', 'm.monto') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Descripcion', 'm.descripcion') }}</th>
\t\t\t\t\t\t\t<th>Usuario</th>

                        </tr>
                    </thead>
                    <tbody>
                        {% for movimiento in pagination %}
                                
                                <td>{{ movimiento.fecha | date('d m Y - h:i:s') }}</td>
                                <td> \$ {{ movimiento.monto }}</td>
                                <td>{{ movimiento.descripcion }}</td>
                                <td>{{ movimiento.usuario.nombrecompleto }}</td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
           <H4> Total Cuotas: {{ pagination.getTotalItemCount }}</H4>
                <div class=\"navigation\">
                    {{ knp_pagination_render(pagination) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "CYAYogaBundle:Alumnocc:detallepagopublic.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Alumnocc/detallepagopublic.html.twig");
    }
}
