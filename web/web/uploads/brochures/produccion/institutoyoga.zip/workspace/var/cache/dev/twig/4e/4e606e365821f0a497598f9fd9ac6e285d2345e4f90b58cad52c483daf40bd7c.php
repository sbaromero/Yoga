<?php

/* CYAYogaBundle:Usuario:index.html.twig */
class __TwigTemplate_f175c8d23575a1b6e2722dfeb1b9cb1ee132c8806cfccd1c155b2da8ec3c489d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d202cd7d539ecb221172b90b9ef348c22f4cf1d942ee74b867a8897711c5caef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d202cd7d539ecb221172b90b9ef348c22f4cf1d942ee74b867a8897711c5caef->enter($__internal_d202cd7d539ecb221172b90b9ef348c22f4cf1d942ee74b867a8897711c5caef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Usuario:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d202cd7d539ecb221172b90b9ef348c22f4cf1d942ee74b867a8897711c5caef->leave($__internal_d202cd7d539ecb221172b90b9ef348c22f4cf1d942ee74b867a8897711c5caef_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_dc56428030c3e2d659f6d461dcf5daadf5ed9a6736656f0d8239a3819bc2a43f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc56428030c3e2d659f6d461dcf5daadf5ed9a6736656f0d8239a3819bc2a43f->enter($__internal_dc56428030c3e2d659f6d461dcf5daadf5ed9a6736656f0d8239a3819bc2a43f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Usuario:index.html.twig"));

        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/danger.html.twig");
        echo "
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Usuarios</h2>
                    <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_add");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t            <span><i class=\"icon ion-android-person-add\"></i></span>
        \t\t\t            agregar nuevo usuario
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "query"), "method"), "html", null, true);
        echo "\" class=\"form-control\" placeholder=\"Buscar Usuario por Apellido, Nombre o DNI\" />
        \t\t\t\t</div>
        \t\t\t\t
        \t\t\t\t<div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"estado\"name=\"estado\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "estado"), "method"), "html", null, true);
        echo "\">
                            <option value=\"3\">Todos</option>
                            <option value=\"1\">Activos</option>
                            <option value=\"0\">Inactivos</option>
                          </select>
                        </div>
                        
                        <br>
                        <br>
                        
                        <div class=\"form-group select-class\">
                            <select class=\"form-control\" id=\"tipocuota\" name=\"tipocuota\" value=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "tipocuota"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Buscar por Tipo de cuota</option>
                                ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tipocuotas"]) ? $context["tipocuotas"] : $this->getContext($context, "tipocuotas")));
        foreach ($context['_seq'] as $context["_key"] => $context["tc"]) {
            // line 41
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tc"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tc"], "nombre", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tc'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "                             </select>
                        </div>
                        
        \t\t\t\t
        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-default\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 63
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Usuario", "u.apellido");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 64
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "DNI", "u.dni");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 65
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Teléfono", "u.telefono");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 66
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Mail", "u.mail");
        echo "</th>
\t\t\t\t\t\t\t<th>Tipo de Cuota</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 72
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["usuario"]) {
            // line 73
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td colspan=\"1\"> <img src=\"";
            // line 75
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/img/avatar.jpg"), "html", null, true);
            echo "\" class=\"avatar-tabla\" />  ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "apellido", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "nombre", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "dni", array()), "html", null, true);
            echo "</td>
                                 <td>";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "telefono", array()), "html", null, true);
            echo "</td>
                                 <td>";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "mail", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 79
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["usuario"], "tipocuota", array()), "nombre", array()), "html", null, true);
            echo "</td>
                               
                               
                                <td class=\"actions\">
                                    <a href=\"";
            // line 83
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_view", array("id" => $this->getAttribute($context["usuario"], "id", array()))), "html", null, true);
            echo "\"class=\"btn btn-sm btn-primary\">
                                        <i class=\"icon ion-eye\"></i> Ver
                                    </a>
                                    <a href=\"";
            // line 86
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_edit", array("id" => $this->getAttribute($context["usuario"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                                        <i class=\"icon ion-wand\"></i> Editar
                                    </a>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['usuario'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 92
        echo "                    </tbody>
                </table>
           <H4> Total Usuarios: ";
        // line 94
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                <div class=\"navigation\">
                    ";
        // line 96
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_dc56428030c3e2d659f6d461dcf5daadf5ed9a6736656f0d8239a3819bc2a43f->leave($__internal_dc56428030c3e2d659f6d461dcf5daadf5ed9a6736656f0d8239a3819bc2a43f_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 96,  213 => 94,  209 => 92,  197 => 86,  191 => 83,  184 => 79,  180 => 78,  176 => 77,  172 => 76,  164 => 75,  158 => 73,  154 => 72,  145 => 66,  141 => 65,  137 => 64,  133 => 63,  111 => 43,  100 => 41,  96 => 40,  91 => 38,  77 => 27,  70 => 23,  57 => 13,  48 => 7,  44 => 6,  40 => 5,  34 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

  
{% block body %}
{{ parent() }}
{{ include('CYAYogaBundle:Usuario:messages/success.html.twig')}}
{{ include('CYAYogaBundle:Usuario:messages/danger.html.twig')}}
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Usuarios</h2>
                    <a href=\"{{ path('cya_usuario_add') }}\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t            <span><i class=\"icon ion-android-person-add\"></i></span>
        \t\t\t            agregar nuevo usuario
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"{{ app.request.get('query') }}\" class=\"form-control\" placeholder=\"Buscar Usuario por Apellido, Nombre o DNI\" />
        \t\t\t\t</div>
        \t\t\t\t
        \t\t\t\t<div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"estado\"name=\"estado\" value=\"{{ app.request.get('estado') }}\">
                            <option value=\"3\">Todos</option>
                            <option value=\"1\">Activos</option>
                            <option value=\"0\">Inactivos</option>
                          </select>
                        </div>
                        
                        <br>
                        <br>
                        
                        <div class=\"form-group select-class\">
                            <select class=\"form-control\" id=\"tipocuota\" name=\"tipocuota\" value=\"{{ app.request.get('tipocuota') }}\">
                                <option value=\"\" selected disabled>Buscar por Tipo de cuota</option>
                                {% for tc in tipocuotas %}
                                    <option value=\"{{ tc.id }}\">{{ tc.nombre }}</option>
                                {% endfor %}
                             </select>
                        </div>
                        
        \t\t\t\t
        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-default\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Usuario', 'u.apellido') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'DNI', 'u.dni') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Teléfono', 'u.telefono') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Mail', 'u.mail') }}</th>
\t\t\t\t\t\t\t<th>Tipo de Cuota</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for usuario in pagination %}
                            <tr data-id=\"{{ usuario.id }}\">
                                
                                <td colspan=\"1\"> <img src=\"{{ asset('public/img/avatar.jpg') }}\" class=\"avatar-tabla\" />  {{ usuario.apellido }}, {{ usuario.nombre }}</td>
                                <td>{{ usuario.dni }}</td>
                                 <td>{{ usuario.telefono }}</td>
                                 <td>{{ usuario.mail }}</td>
                                <td>{{ usuario.tipocuota.nombre }}</td>
                               
                               
                                <td class=\"actions\">
                                    <a href=\"{{ path('cya_usuario_view', {id: usuario.id }) }}\"class=\"btn btn-sm btn-primary\">
                                        <i class=\"icon ion-eye\"></i> Ver
                                    </a>
                                    <a href=\"{{ path('cya_usuario_edit', {id: usuario.id }) }}\" class=\"btn btn-sm btn-primary\">
                                        <i class=\"icon ion-wand\"></i> Editar
                                    </a>
                                </td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
           <H4> Total Usuarios: {{ pagination.getTotalItemCount }}</H4>
                <div class=\"navigation\">
                    {{ knp_pagination_render(pagination) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "CYAYogaBundle:Usuario:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/index.html.twig");
    }
}
