<?php

/* CYAYogaBundle:Usuario:edit.html.twig */
class __TwigTemplate_2617e82da04835342aa5324a3049944df9a8c8468d68dd0c61179b5fc87d99b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5634ea6f44801abdda0c4b028f37dbac5708fbe5df245ef8cdaf2eb8196d736d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5634ea6f44801abdda0c4b028f37dbac5708fbe5df245ef8cdaf2eb8196d736d->enter($__internal_5634ea6f44801abdda0c4b028f37dbac5708fbe5df245ef8cdaf2eb8196d736d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Usuario:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5634ea6f44801abdda0c4b028f37dbac5708fbe5df245ef8cdaf2eb8196d736d->leave($__internal_5634ea6f44801abdda0c4b028f37dbac5708fbe5df245ef8cdaf2eb8196d736d_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_59cb7697b7544fe46d1c386ef6a9a03613236e0694d3bb5e237b7d0edf5849a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59cb7697b7544fe46d1c386ef6a9a03613236e0694d3bb5e237b7d0edf5849a6->enter($__internal_59cb7697b7544fe46d1c386ef6a9a03613236e0694d3bb5e237b7d0edf5849a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Usuario:edit.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/success.html.twig");
        echo "
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar Usuario</h2>
\t\t\t\t</div>
\t\t\t\t";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("rol" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "</h4>
                     
\t\t\t\t\t<fieldset>

\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Nombre de usuario
\t\t\t\t\t        ";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombreusuario", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre de usuario")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombreusuario", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
                        <div class=\"form-group\">
\t\t\t\t\t        Nombre
\t\t\t\t\t        ";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div> 
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Apellido
\t\t\t\t\t        ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "apellido", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Apellido")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "apellido", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>  
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        DNI
\t\t\t\t\t        ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dni", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "DNI")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dni", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        Dirección
\t\t\t\t\t        ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "direccion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Dirección")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "direccion", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        Ciudad
\t\t\t\t\t        ";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "ciudad", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Ciudad")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "ciudad", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Teléfono
\t\t\t\t\t        ";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telefono", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Teléfono")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telefono", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Mail
\t\t\t\t\t        ";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mail", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Mail")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mail", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Fecha de nacimiento
\t\t\t\t\t        ";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechanacimiento", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha de nacimiento")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechanacimiento", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Fecha de Ingreso
\t\t\t\t\t        ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechaingreso", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha de ingreso")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 65
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechaingreso", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t           Fecha de Re-Ingreso (se generarán las deudas de cta. cte a partir de esta fecha)
\t\t\t\t\t        ";
        // line 69
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechareingreso", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha de reingreso")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 70
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechareingreso", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Rol
\t\t\t\t\t        ";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "rol", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Rol")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "rol", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Tipo de cuota
\t\t\t\t\t        ";
        // line 79
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipocuota", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Tipo de cuota")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 80
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipocuota", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <br>
\t\t\t\t\t   \t<div class=\"checkbox\">
\t\t\t\t\t\t    <label>
\t\t\t\t\t\t\t\t";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'widget');
        echo " 
\t\t\t\t\t\t\t\t<span class=\"text-danger\">";
        // line 86
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "rol", array()), 'errors');
        echo "</span>
\t\t\t\t\t\t    </label>
\t\t\t\t\t\t</div>
\t\t\t\t\t    <br> 
\t\t\t\t\t    
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 94
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Modificar Usuario", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 98
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
        
        $__internal_59cb7697b7544fe46d1c386ef6a9a03613236e0694d3bb5e237b7d0edf5849a6->leave($__internal_59cb7697b7544fe46d1c386ef6a9a03613236e0694d3bb5e237b7d0edf5849a6_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  234 => 98,  227 => 94,  216 => 86,  212 => 85,  204 => 80,  200 => 79,  193 => 75,  189 => 74,  182 => 70,  178 => 69,  171 => 65,  167 => 64,  160 => 60,  156 => 59,  149 => 55,  145 => 54,  138 => 50,  134 => 49,  127 => 45,  123 => 44,  116 => 40,  112 => 39,  105 => 35,  101 => 34,  94 => 30,  90 => 29,  83 => 25,  79 => 24,  72 => 20,  68 => 19,  59 => 13,  55 => 12,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    {{ include('CYAYogaBundle:Usuario:messages/success.html.twig') }}
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar Usuario</h2>
\t\t\t\t</div>
\t\t\t\t{{ form_start(form, {'attr': { 'rol' : 'form'}}) }}
\t\t\t\t<h4 class=\"text-danger\">{{ form_errors(form) }}</h4>
                     
\t\t\t\t\t<fieldset>

\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Nombre de usuario
\t\t\t\t\t        {{ form_widget(form.nombreusuario, {'attr': {'class': 'form-control', 'placeholder' : 'Nombre de usuario'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.nombreusuario) }}</span>
\t\t\t\t\t    </div>
                        <div class=\"form-group\">
\t\t\t\t\t        Nombre
\t\t\t\t\t        {{ form_widget(form.nombre, {'attr': {'class': 'form-control', 'placeholder' : 'Nombre'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.nombre) }}</span>
\t\t\t\t\t    </div> 
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Apellido
\t\t\t\t\t        {{ form_widget(form.apellido, {'attr': {'class': 'form-control', 'placeholder' : 'Apellido'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.apellido) }}</span>
\t\t\t\t\t    </div>  
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        DNI
\t\t\t\t\t        {{ form_widget(form.dni, {'attr': {'class': 'form-control', 'placeholder' : 'DNI'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.dni) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        Dirección
\t\t\t\t\t        {{ form_widget(form.direccion, {'attr': {'class': 'form-control', 'placeholder' : 'Dirección'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.direccion) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        Ciudad
\t\t\t\t\t        {{ form_widget(form.ciudad, {'attr': {'class': 'form-control', 'placeholder' : 'Ciudad'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.ciudad) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Teléfono
\t\t\t\t\t        {{ form_widget(form.telefono, {'attr': {'class': 'form-control', 'placeholder' : 'Teléfono'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.telefono) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Mail
\t\t\t\t\t        {{ form_widget(form.mail, {'attr': {'class': 'form-control', 'placeholder' : 'Mail'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.mail) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Fecha de nacimiento
\t\t\t\t\t        {{ form_widget(form.fechanacimiento, {'attr': {'class': 'form-control', 'placeholder' : 'Fecha de nacimiento'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.fechanacimiento) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Fecha de Ingreso
\t\t\t\t\t        {{ form_widget(form.fechaingreso, {'attr': {'class': 'form-control', 'placeholder' : 'Fecha de ingreso'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.fechaingreso) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t           Fecha de Re-Ingreso (se generarán las deudas de cta. cte a partir de esta fecha)
\t\t\t\t\t        {{ form_widget(form.fechareingreso, {'attr': {'class': 'form-control', 'placeholder' : 'Fecha de reingreso'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.fechareingreso) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Rol
\t\t\t\t\t        {{ form_widget(form.rol, {'attr': {'class': 'form-control', 'placeholder' : 'Rol'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.rol) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Tipo de cuota
\t\t\t\t\t        {{ form_widget(form.tipocuota, {'attr': {'class': 'form-control', 'placeholder' : 'Tipo de cuota'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.tipocuota) }}</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <br>
\t\t\t\t\t   \t<div class=\"checkbox\">
\t\t\t\t\t\t    <label>
\t\t\t\t\t\t\t\t{{ form_widget(form.isActive) }} 
\t\t\t\t\t\t\t\t<span class=\"text-danger\">{{ form_errors(form.rol) }}</span>
\t\t\t\t\t\t    </label>
\t\t\t\t\t\t</div>
\t\t\t\t\t    <br> 
\t\t\t\t\t    
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        {{ form_widget(form.save, {'label' : 'Modificar Usuario', 'attr': {'class': 'btn btn-success'}}) }}
\t\t\t\t    </p>
                 
                   
\t\t\t\t{{ form_end(form) }}
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}", "CYAYogaBundle:Usuario:edit.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/edit.html.twig");
    }
}
