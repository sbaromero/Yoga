<?php

/* CYAYogaBundle:Movimiento:index.html.twig */
class __TwigTemplate_277cb3e04d3c6a2e1c12b5d6c148a411abee7be47dd71aced97144f673c85d1a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Movimiento:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Movimiento:messages/success.html.twig");
        echo "
<div class=\"container-fluid caja\">
        <div class=\"container caja-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Movimientos de Caja</h2>
                    <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_add");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
        \t\t\t            Nuevo movimiento
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t
        \t\t\t\t<div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"dc\"name=\"dc\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "dc"), "method"), "html", null, true);
        echo "\">
                            <option value=\"\" selected disabled>Débito/Crédito</option>
                            <option value=\"\">Todos</option>
                            <option value=\"D\">Débito</option>
                            <option value=\"C\">Crédito</option>
                          </select>
                        </div>
                        
                        <div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"tipo\"name=\"tipo\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "tipo"), "method"), "html", null, true);
        echo "\">
                            <option value=\"\" selected disabled>Tipo</option>
                            <option value=\"\">Todos</option>
                            <option value=\"MB\">Movimientos básicos</option>
                            <option value=\"CC\">Movimientos CC</option>
                            <option value=\"VP\">Venta de productos</option>
                          </select>
                        </div>
                        
                        <div class=\"form-group select-class\">
                            <select class=\"form-control\" id=\"rubro\" name=\"rubro\" value=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "rubro"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Rubro</option>
                                ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rubros"]) ? $context["rubros"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["ru"]) {
            // line 45
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ru"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ru"], "nombre", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ru'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "                             </select>
                        </div>
                        <br>
                         <br>
                        <div class=\"form-group select-class\">
                            <select class=\"form-control\" id=\"usuario\" name=\"usuario\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "usuario"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Usuario (que hizo el movimiento)</option>
                                ";
        // line 54
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["usuarios"]) ? $context["usuarios"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["us"]) {
            // line 55
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "nombrecompleto", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['us'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "                             </select>
                        </div>
                        
                        <div class=\"select-class2\">
                            <div class=\"form-group\">
                                    Desde
                                    <input type='date' class=\"\" id=\"fd\"name=\"fd\" value=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "fd"), "method"), "html", null, true);
        echo "\" />
                            </div>
                            
                            <div class=\"form-group\">
                                    Hasta
                                    <input type='date' class=\"\" id=\"fh\"name=\"fh\" value=\"";
        // line 68
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "fh"), "method"), "html", null, true);
        echo "\" />
                            </div>
                        
                        <input type=\"submit\" value=\"buscar\" class=\"btn btn-success\" margin-top=\"5px\">
        \t\t\t\t</div>
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
    <div class=\"container\">
        <div class=\"row\">
    \t
    \t    <div class=\"table-responsive\">
                    <table class=\"table table-hover\">
                        <thead>
                            <tr>
    
    \t\t\t\t\t\t\t<th>";
        // line 86
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Fecha", "m.fecha");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 87
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Monto", "m.monto");
        echo " </th>
    \t\t\t\t\t\t\t<th>";
        // line 88
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Descripcion", "m.descripcion");
        echo " </th>
    \t\t\t\t\t\t\t<th>";
        // line 89
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Rubro", "m.rubro.nombre");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 90
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "D/C", "m.rubro.tipo");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 91
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Tipo", "m.tipo");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 92
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Usuario", "m.usuario.nombrecompleto");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 93
        echo "Acciones";
        echo "</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 98
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["movimiento"]) {
            // line 99
            echo "                                <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "id", array()), "html", null, true);
            echo "\">
                                    
                                    <td>";
            // line 101
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["movimiento"], "fecha", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                    <td>\$ ";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "monto", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 103
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "descripcion", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 104
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "nombre", array()), "html", null, true);
            echo "</td>
                                    
                                    <td>
                                        ";
            // line 107
            if (($this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "tipo", array()) == "C")) {
                // line 108
                echo "                                            <strong>Crédito</strong>
                                        ";
            }
            // line 109
            echo "    
                                        ";
            // line 110
            if (($this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "tipo", array()) == "D")) {
                // line 111
                echo "                                            <strong>Débito</strong>
                                        ";
            }
            // line 112
            echo "    
                                    </td>
                                    
                                    
                                    <td>
                                        ";
            // line 117
            if (($this->getAttribute($context["movimiento"], "tipo", array()) == "MB")) {
                // line 118
                echo "                                            <strong>Movimiento de caja básico</strong>
                                        ";
            }
            // line 119
            echo "    
                                        ";
            // line 120
            if (($this->getAttribute($context["movimiento"], "tipo", array()) == "CC")) {
                // line 121
                echo "                                            <strong>Movimiento de CC - ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["movimiento"], "alumnocc", array()), "usuario", array()), "nombrecompleto", array()), "html", null, true);
                echo "</strong>
                                        ";
            }
            // line 122
            echo "   
                                        ";
            // line 123
            if (($this->getAttribute($context["movimiento"], "tipo", array()) == "VP")) {
                // line 124
                echo "                                            <strong>Venta de productos</strong>
                                        ";
            }
            // line 125
            echo "   
                                    </td>
                                    
                                    <td>";
            // line 128
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["movimiento"], "usuario", array()), "nombrecompleto", array()), "html", null, true);
            echo "</td>
                                    <td class=\"actions\">
                                        <a href=\"";
            // line 130
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_details", array("id" => $this->getAttribute($context["movimiento"], "id", array()))), "html", null, true);
            echo "\" 
                                        ";
            // line 131
            if ((($this->getAttribute($context["movimiento"], "tipo", array()) == "MB") || ($this->getAttribute($context["movimiento"], "tipo", array()) == "CC"))) {
                // line 132
                echo "                                            class=\"btn btn-sm btn-primary disabled\"
                                        ";
            } elseif (($this->getAttribute(            // line 133
$context["movimiento"], "tipo", array()) == "VP")) {
                echo " 
                                            class=\"btn btn-sm btn-primary\"
                                        ";
            }
            // line 135
            echo "  
                                        >
                                            detalles
                                        </a>
                                         <a href=\"";
            // line 139
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_delete", array("id" => $this->getAttribute($context["movimiento"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-danger btn-delete\" onclick=\"return confirm('Está seguro?')\">
    \t\t\t                            eliminar
    \t\t\t                        </a>
                                    </td>
    
                                </tr>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['movimiento'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 146
        echo "                        </tbody>
                    </table>
                   
               <H4> ";
        // line 149
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("Total Movimientos:", array(), "messages");
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                    <div class=\"navigation\">
                        ";
        // line 151
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                    </div>
    
                </div>   
                    
                </div>
            </div>
        </div>
 </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Movimiento:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  335 => 151,  328 => 149,  323 => 146,  310 => 139,  304 => 135,  298 => 133,  295 => 132,  293 => 131,  289 => 130,  284 => 128,  279 => 125,  275 => 124,  273 => 123,  270 => 122,  264 => 121,  262 => 120,  259 => 119,  255 => 118,  253 => 117,  246 => 112,  242 => 111,  240 => 110,  237 => 109,  233 => 108,  231 => 107,  225 => 104,  221 => 103,  217 => 102,  213 => 101,  207 => 99,  203 => 98,  195 => 93,  191 => 92,  187 => 91,  183 => 90,  179 => 89,  175 => 88,  171 => 87,  167 => 86,  146 => 68,  138 => 63,  130 => 57,  119 => 55,  115 => 54,  110 => 52,  103 => 47,  92 => 45,  88 => 44,  83 => 42,  70 => 32,  58 => 23,  44 => 12,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Movimiento:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Movimiento/index.html.twig");
    }
}
