<?php

/* CYAYogaBundle:Rubro:edit.html.twig */
class __TwigTemplate_c64e88f7cb508a700265f696e54ed5b32b9eaf518d6b0f2e66a99d0a10161777 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Rubro:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_373dbbddf2a35d9db294138b1355f484d9840ae489d6cccb422f39f782595640 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_373dbbddf2a35d9db294138b1355f484d9840ae489d6cccb422f39f782595640->enter($__internal_373dbbddf2a35d9db294138b1355f484d9840ae489d6cccb422f39f782595640_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Rubro:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_373dbbddf2a35d9db294138b1355f484d9840ae489d6cccb422f39f782595640->leave($__internal_373dbbddf2a35d9db294138b1355f484d9840ae489d6cccb422f39f782595640_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_840082a889fa8e91096a03d366bf273d0c8be872c8e67a253841eb1160e8d307 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_840082a889fa8e91096a03d366bf273d0c8be872c8e67a253841eb1160e8d307->enter($__internal_840082a889fa8e91096a03d366bf273d0c8be872c8e67a253841eb1160e8d307_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Rubro:edit.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Rubro:messages/success.html.twig");
        echo "
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar Rubro de Caja</h2>
\t\t\t\t</div>
\t\t\t\t";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("role" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"checkbox\">
\t\t                 <label>
\t\t                     ";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'widget');
        echo " Activo
\t\t                     <span class=\"text-danger\"> ";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'errors');
        echo " </span>
\t\t                 </label>
\t\t               </div>
\t\t\t\t\t\t
\t\t\t\t\t    <div class=\"form-group\">
\t                         ";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'label');
        echo "
\t                         ";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
\t                         <span class=\"text-danger\"> ";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'errors');
        echo " </span>
                    \t</div>
                          
\t\t\t\t\t    <div class=\"form-group\">
\t\t                     ";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipo", array()), 'label');
        echo "
\t\t                     ";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipo", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
\t\t                     <span class=\"text-danger\"> ";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipo", array()), 'errors');
        echo " </span>
\t\t                </div>

\t\t               
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Modificar Rubro", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 44
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
        
        $__internal_840082a889fa8e91096a03d366bf273d0c8be872c8e67a253841eb1160e8d307->leave($__internal_840082a889fa8e91096a03d366bf273d0c8be872c8e67a253841eb1160e8d307_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Rubro:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 44,  113 => 40,  103 => 33,  99 => 32,  95 => 31,  88 => 27,  84 => 26,  80 => 25,  72 => 20,  68 => 19,  59 => 13,  55 => 12,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    {{ include('CYAYogaBundle:Rubro:messages/success.html.twig') }}
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar Rubro de Caja</h2>
\t\t\t\t</div>
\t\t\t\t{{ form_start(form, {'attr': { 'role' : 'form'}}) }}
\t\t\t\t<h4 class=\"text-danger\">{{ form_errors(form) }}</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"checkbox\">
\t\t                 <label>
\t\t                     {{ form_widget(form.isActive) }} Activo
\t\t                     <span class=\"text-danger\"> {{ form_errors(form.isActive) }} </span>
\t\t                 </label>
\t\t               </div>
\t\t\t\t\t\t
\t\t\t\t\t    <div class=\"form-group\">
\t                         {{ form_label(form.nombre) }}
\t                         {{ form_widget(form.nombre, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Nombre'} }) }}
\t                         <span class=\"text-danger\"> {{ form_errors(form.nombre) }} </span>
                    \t</div>
                          
\t\t\t\t\t    <div class=\"form-group\">
\t\t                     {{ form_label(form.tipo) }}
\t\t                     {{ form_widget(form.tipo, { 'attr' : { 'class' : 'form-control'} }) }}
\t\t                     <span class=\"text-danger\"> {{ form_errors(form.tipo) }} </span>
\t\t                </div>

\t\t               
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        {{ form_widget(form.save, {'label' : 'Modificar Rubro', 'attr': {'class': 'btn btn-success'}}) }}
\t\t\t\t    </p>
                 
                   
\t\t\t\t{{ form_end(form) }}
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}", "CYAYogaBundle:Rubro:edit.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Rubro/edit.html.twig");
    }
}
