<?php

/* CYAYogaBundle:Usuario:edit.html.twig */
class __TwigTemplate_08b6a801395d50c9c5b92ae9d182fa2f2fe5e819dbaae278cb3a7ce728e62a62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/success.html.twig");
        echo "
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar Usuario</h2>
\t\t\t\t</div>
\t\t\t\t";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("rol" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'errors');
        echo "</h4>
                     
\t\t\t\t\t<fieldset>

\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Nombre de usuario
\t\t\t\t\t        ";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombreusuario", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre de usuario")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombreusuario", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
                        <div class=\"form-group\">
\t\t\t\t\t        Nombre
\t\t\t\t\t        ";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div> 
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Apellido
\t\t\t\t\t        ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "apellido", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Apellido")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "apellido", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>  
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        DNI
\t\t\t\t\t        ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dni", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "DNI")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dni", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        Dirección
\t\t\t\t\t        ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "direccion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Dirección")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "direccion", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t        Ciudad
\t\t\t\t\t        ";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "ciudad", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Ciudad")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "ciudad", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Teléfono
\t\t\t\t\t        ";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "telefono", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Teléfono")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "telefono", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Mail
\t\t\t\t\t        ";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "mail", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Mail")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "mail", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Fecha de nacimiento
\t\t\t\t\t        ";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechanacimiento", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha de nacimiento")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechanacimiento", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Fecha de Ingreso
\t\t\t\t\t        ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechaingreso", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha de ingreso")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 65
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechaingreso", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t           Fecha de Re-Ingreso (se generarán las deudas de cta. cte a partir de esta fecha)
\t\t\t\t\t        ";
        // line 69
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechareingreso", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha de reingreso")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 70
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechareingreso", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Rol
\t\t\t\t\t        ";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "rol", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Rol")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "rol", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Tipo de cuota
\t\t\t\t\t        ";
        // line 79
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipocuota", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Tipo de cuota")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 80
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipocuota", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
\t\t\t\t\t    <br>
\t\t\t\t\t   \t<div class=\"checkbox\">
\t\t\t\t\t\t    <label>
\t\t\t\t\t\t\t\t";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isActive", array()), 'widget');
        echo " 
\t\t\t\t\t\t\t\t<span class=\"text-danger\">";
        // line 86
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "rol", array()), 'errors');
        echo "</span>
\t\t\t\t\t\t    </label>
\t\t\t\t\t\t</div>
\t\t\t\t\t    <br> 
\t\t\t\t\t    
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 94
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Modificar Usuario", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 98
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  225 => 98,  218 => 94,  207 => 86,  203 => 85,  195 => 80,  191 => 79,  184 => 75,  180 => 74,  173 => 70,  169 => 69,  162 => 65,  158 => 64,  151 => 60,  147 => 59,  140 => 55,  136 => 54,  129 => 50,  125 => 49,  118 => 45,  114 => 44,  107 => 40,  103 => 39,  96 => 35,  92 => 34,  85 => 30,  81 => 29,  74 => 25,  70 => 24,  63 => 20,  59 => 19,  50 => 13,  46 => 12,  36 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Usuario:edit.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/edit.html.twig");
    }
}
