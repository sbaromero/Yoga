<?php

/* CYAYogaBundle:Movimiento:add.html.twig */
class __TwigTemplate_59bb8081b9e79107c9839915c9392a78298324bd8c08f9fcd7209d0e8e6125ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Movimiento:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Movimiento:messages/success.html.twig");
        echo "
<div class=\"container-fluid caja\">
        <div class=\"container caja-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Cargar Nuevo Movimiento</h2>
                </div>
            </div>

        </div>
    </div>
    
\t<div class=\"container\">
\t    ";
        // line 19
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
\t    <div class=\"container grey-input\">
        <div class=\"row\">

            <div class=\"col-sm-4\">
                <div class=\"form-group\"> 
        \t        Rubro
        \t        ";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "rubro", array()), 'widget', array("attr" => array("class" => "form-control", "id" => "select_rubro")));
        echo " 
        \t         <span class=\"text-danger\">";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "rubro", array()), 'errors');
        echo "</span> 
        \t    </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                <div class=\"form-group\">
                     Monto
                     ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "monto", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Monto")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "monto", array()), 'errors');
        echo " </span>
                </div>
            </div>

            <div class=\"col-sm-4\"> 
                <div class=\"form-group\">
                     Descripcion
                     ";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "descripcion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripcion")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "descripcion", array()), 'errors');
        echo " </span>
                    
                </div>
                
            </div>
            


            <div class=\"col-sm-12\">
                ";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Cargar Movimiento", "attr" => array("class" => "btn alumnos-btn")));
        echo "
            </div>
            
            ";
        // line 55
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
         </div>
         
         
         
         
         
         
        <div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 71
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Fecha", "m.fecha");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 72
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Monto", "m.monto");
        echo " </th>
\t\t\t\t\t\t\t<th>";
        // line 73
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Descripcion", "m.descripcion");
        echo " </th>
\t\t\t\t\t\t\t<th>";
        // line 74
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Rubro", "m.rubro.nombre");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 75
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "D/C", "m.rubro.tipo");
        echo "</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 80
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["movimiento"]) {
            // line 81
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 83
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["movimiento"], "fecha", array()), "d M Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td>\$ ";
            // line 84
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "monto", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 85
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "descripcion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 86
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "nombre", array()), "html", null, true);
            echo "</td>
                                
                                <td>
                                    ";
            // line 89
            if (($this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "tipo", array()) == "C")) {
                // line 90
                echo "                                        <strong>Crédito</strong>
                                    ";
            }
            // line 91
            echo "    
                                    ";
            // line 92
            if (($this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "tipo", array()) == "D")) {
                // line 93
                echo "                                        <strong>Débito</strong>
                                    ";
            }
            // line 94
            echo "    
                                </td>
                                
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['movimiento'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 99
        echo "                    </tbody>

                </table>

<br>

            <b>
           <H4> ";
        // line 106
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("Total Movimientos:", array(), "messages");
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo " </H4> <h4>Saldo: \$ ";
        echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : null), "html", null, true);
        echo "</h4>
                ";
        // line 108
        echo "                <div class=\"navigation\">
                    ";
        // line 109
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                </div>
             
            </b>
            </div>   
                
            </div>
        </div>
    </div>

 </div>
 
 ";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Movimiento:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  227 => 109,  224 => 108,  216 => 106,  207 => 99,  197 => 94,  193 => 93,  191 => 92,  188 => 91,  184 => 90,  182 => 89,  176 => 86,  172 => 85,  168 => 84,  164 => 83,  158 => 81,  154 => 80,  146 => 75,  142 => 74,  138 => 73,  134 => 72,  130 => 71,  111 => 55,  105 => 52,  93 => 43,  89 => 42,  79 => 35,  75 => 34,  65 => 27,  61 => 26,  51 => 19,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Movimiento:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Movimiento/add.html.twig");
    }
}
