<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_8d7900117c8a867fe336065e71a8f125f790a25bb2ac39f9dd17063662a22c85 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a38862aee3e7a431594148601b5f6d2f4d53d015a8dd93e71a84e040ccd40d60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a38862aee3e7a431594148601b5f6d2f4d53d015a8dd93e71a84e040ccd40d60->enter($__internal_a38862aee3e7a431594148601b5f6d2f4d53d015a8dd93e71a84e040ccd40d60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_a38862aee3e7a431594148601b5f6d2f4d53d015a8dd93e71a84e040ccd40d60->leave($__internal_a38862aee3e7a431594148601b5f6d2f4d53d015a8dd93e71a84e040ccd40d60_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/home/ubuntu/workspace/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/password_widget.html.php");
    }
}
