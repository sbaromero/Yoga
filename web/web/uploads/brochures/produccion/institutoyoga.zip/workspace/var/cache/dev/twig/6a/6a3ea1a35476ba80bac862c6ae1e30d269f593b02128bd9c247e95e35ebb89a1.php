<?php

/* CYAYogaBundle:Tipocuota:edit.html.twig */
class __TwigTemplate_fb79f892cd353a2d0b9457ef9945daf001c929d450791e2e595781019f14769b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Tipocuota:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d74d3d37c78ca5fa0fc1156cf293fced6c038c87b2af9d8f301a0eed3825f4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d74d3d37c78ca5fa0fc1156cf293fced6c038c87b2af9d8f301a0eed3825f4d->enter($__internal_6d74d3d37c78ca5fa0fc1156cf293fced6c038c87b2af9d8f301a0eed3825f4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Tipocuota:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6d74d3d37c78ca5fa0fc1156cf293fced6c038c87b2af9d8f301a0eed3825f4d->leave($__internal_6d74d3d37c78ca5fa0fc1156cf293fced6c038c87b2af9d8f301a0eed3825f4d_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_4b49eb50e49d5636c2979c61d54a06bf802c67066a1e0cca1cd1a3408117d7e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b49eb50e49d5636c2979c61d54a06bf802c67066a1e0cca1cd1a3408117d7e5->enter($__internal_4b49eb50e49d5636c2979c61d54a06bf802c67066a1e0cca1cd1a3408117d7e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Tipocuota:edit.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Tipocuota:messages/success.html.twig");
        echo "
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar tipo de cuota</h2>
\t\t\t\t</div>
\t\t\t\t";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("role" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t                <div class=\"form-group\">
\t\t\t                     Nombre
\t\t\t                     ";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
\t\t\t                     <span class=\"text-danger\"> ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'errors');
        echo " </span>
\t\t\t               </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                <div class=\"form-group\">
\t\t\t                     Valor
\t\t\t                     ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "valor", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Valor")));
        echo "
\t\t\t                     <span class=\"text-danger\"> ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "valor", array()), 'errors');
        echo " </span>
\t\t\t                </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "instructorado", array()), 'widget');
        echo " Profesorado 1er. Nivel
\t\t\t                         <span class=\"text-danger\"> ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "instructorado", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "clasesyoga", array()), 'widget');
        echo " Clases de yoga
\t\t\t                         <span class=\"text-danger\"> ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "clasesyoga", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "asociacion", array()), 'widget');
        echo " Asociacion
\t\t\t                         <span class=\"text-danger\"> ";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "asociacion", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "profesorado", array()), 'widget');
        echo " Profesorado 2do Nivel.
\t\t\t                         <span class=\"text-danger\"> ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "profesorado", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 72
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "posgrado", array()), 'widget');
        echo " Posgrado
\t\t\t                         <span class=\"text-danger\"> ";
        // line 73
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "posgrado", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "casillero", array()), 'widget');
        echo " Casillero
\t\t\t                         <span class=\"text-danger\"> ";
        // line 82
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "casillero", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 90
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "otro", array()), 'widget');
        echo " Otro  
\t\t\t                         <span class=\"text-danger\"> ";
        // line 91
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "otro", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 99
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Modificar tipo de cuota", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 103
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
        
        $__internal_4b49eb50e49d5636c2979c61d54a06bf802c67066a1e0cca1cd1a3408117d7e5->leave($__internal_4b49eb50e49d5636c2979c61d54a06bf802c67066a1e0cca1cd1a3408117d7e5_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Tipocuota:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  209 => 103,  202 => 99,  191 => 91,  187 => 90,  176 => 82,  172 => 81,  161 => 73,  157 => 72,  146 => 64,  142 => 63,  131 => 55,  127 => 54,  116 => 46,  112 => 45,  101 => 37,  97 => 36,  87 => 29,  83 => 28,  73 => 21,  69 => 20,  59 => 13,  55 => 12,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    {{ include('CYAYogaBundle:Tipocuota:messages/success.html.twig') }}
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar tipo de cuota</h2>
\t\t\t\t</div>
\t\t\t\t{{ form_start(form, {'attr': { 'role' : 'form'}}) }}
\t\t\t\t<h4 class=\"text-danger\">{{ form_errors(form) }}</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t                <div class=\"form-group\">
\t\t\t                     Nombre
\t\t\t                     {{ form_widget(form.nombre, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Nombre'} }) }}
\t\t\t                     <span class=\"text-danger\"> {{ form_errors(form.nombre) }} </span>
\t\t\t               </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                <div class=\"form-group\">
\t\t\t                     Valor
\t\t\t                     {{ form_widget(form.valor, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Valor'} }) }}
\t\t\t                     <span class=\"text-danger\"> {{ form_errors(form.valor) }} </span>
\t\t\t                </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         {{ form_widget(form.instructorado) }} Profesorado 1er. Nivel
\t\t\t                         <span class=\"text-danger\"> {{ form_errors(form.instructorado) }} </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         {{ form_widget(form.clasesyoga) }} Clases de yoga
\t\t\t                         <span class=\"text-danger\"> {{ form_errors(form.clasesyoga) }} </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         {{ form_widget(form.asociacion) }} Asociacion
\t\t\t                         <span class=\"text-danger\"> {{ form_errors(form.asociacion) }} </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         {{ form_widget(form.profesorado) }} Profesorado 2do Nivel.
\t\t\t                         <span class=\"text-danger\"> {{ form_errors(form.profesorado) }} </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         {{ form_widget(form.posgrado) }} Posgrado
\t\t\t                         <span class=\"text-danger\"> {{ form_errors(form.posgrado) }} </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         {{ form_widget(form.casillero) }} Casillero
\t\t\t                         <span class=\"text-danger\"> {{ form_errors(form.casillero) }} </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         {{ form_widget(form.otro) }} Otro  
\t\t\t                         <span class=\"text-danger\"> {{ form_errors(form.otro) }} </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        {{ form_widget(form.save, {'label' : 'Modificar tipo de cuota', 'attr': {'class': 'btn btn-success'}}) }}
\t\t\t\t    </p>
                 
                   
\t\t\t\t{{ form_end(form) }}
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}", "CYAYogaBundle:Tipocuota:edit.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Tipocuota/edit.html.twig");
    }
}
