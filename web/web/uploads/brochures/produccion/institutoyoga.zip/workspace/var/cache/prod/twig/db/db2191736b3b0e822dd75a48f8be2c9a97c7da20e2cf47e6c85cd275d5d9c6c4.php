<?php

/* CYAYogaBundle:Usuario:add.html.twig */
class __TwigTemplate_02b55d3f881bf50dfe15648462d103d296bd4a12fcf767cc31e824c92a5e929f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <h2>Agregar nuevo usuario </h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar al listado de usuarios
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                
            </div>
        </div>
    </div>
    
           
     <div class=\"container grey-input\">
        
        <div class=\"modulo-form\">
        
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                 
             ";
        // line 31
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
            


                 <div class=\"form-group\">
                     Usuario
                     ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombreusuario", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre de Usuario")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombreusuario", array()), 'errors');
        echo " </span>
                 </div>
                     

            </div>
            <div class=\"col-sm-4\">
  
                <div class=\"form-group\">
                         DNI
                         ";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dni", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "DNI")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dni", array()), 'errors');
        echo " </span>
               </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         ";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'label');
        echo "
                         ";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            <div class=\"col-sm-4\"> 
                     <div class=\"form-group\">
                         ";
        // line 62
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "apellido", array()), 'label');
        echo "
                         ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "apellido", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Apellido")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "apellido", array()), 'errors');
        echo " </span>
                     </div>
            </div>
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         Fecha de Nacimiento
                         ";
        // line 70
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechanacimiento", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha de Nacimiento")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 71
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechanacimiento", array()), 'errors');
        echo " </span>
                 </div>
            </div> 
        </div>
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <div class=\"form-group\">
                     Dirección
                     ";
        // line 79
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "direccion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Dirección")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 80
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "direccion", array()), 'errors');
        echo " </span>
                 </div>
            </div>

            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                    Ciudad/Provincia
                     ";
        // line 87
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "ciudad", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Ciudad/Provincia")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 88
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "ciudad", array()), 'errors');
        echo " </span>
                 </div>
            </div>
          </div>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                 <div class=\"form-group\">
                     Mail
                     ";
        // line 96
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "mail", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Mail")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 97
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "mail", array()), 'errors');
        echo " </span>
                 </div>
                 </div>
            <div class=\"col-sm-4\">
                  <div class=\"form-group\">
                     Teléfono
                     ";
        // line 103
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "telefono", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Teléfono")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 104
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "telefono", array()), 'errors');
        echo " </span>
                 </div>
           
            </div>
          </div>
     
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                    Fecha de Ingreso
                     ";
        // line 115
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechaingreso", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha Ingreso")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 116
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechaingreso", array()), 'errors');
        echo " </span>
                 </div>
                
            </div>
                    <div class=\"col-sm-4\">
                <div class=\"form-group\">
                       Fecha de Re-Ingreso (se generarán las deudas de cta. cte a partir de esta fecha) 
                     ";
        // line 123
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechareingreso", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha Reingreso")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 124
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "fechareingreso", array()), 'errors');
        echo " </span>
                </div>
            </div>
        </div>   
        
    
    
      
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Tipo de Cuota
                     ";
        // line 137
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipocuota", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 138
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipocuota", array()), 'errors');
        echo " </span>
                 </div>
            </div>
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Rol
                     ";
        // line 144
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "rol", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 145
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "rol", array()), 'errors');
        echo " </span>
                 </div>
            </div>
        </div>
           
        <div class=\"row\">
            <div class=\"col-sm-4\">

                     ";
        // line 153
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "password", array()), 'label');
        echo "
                     ";
        // line 154
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "password", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Password")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 155
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "password", array()), 'errors');
        echo " </span>
        
                  </div> 
                            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 161
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isActive", array()), 'widget');
        echo "
                         <span class=\"text-danger\"> ";
        // line 162
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isActive", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
                 </div>    
        </div>      
                
              
             </div>
              <p>
                     ";
        // line 171
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Agregar Usuario", "attr" => array("class" => "btn alumnos-btn")));
        echo "
                 </p>

                 ";
        // line 174
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
         </div>
                 
     </div>
     
    
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  313 => 174,  307 => 171,  295 => 162,  291 => 161,  282 => 155,  278 => 154,  274 => 153,  263 => 145,  259 => 144,  250 => 138,  246 => 137,  230 => 124,  226 => 123,  216 => 116,  212 => 115,  198 => 104,  194 => 103,  185 => 97,  181 => 96,  170 => 88,  166 => 87,  156 => 80,  152 => 79,  141 => 71,  137 => 70,  128 => 64,  124 => 63,  120 => 62,  112 => 57,  108 => 56,  104 => 55,  94 => 48,  90 => 47,  78 => 38,  74 => 37,  65 => 31,  41 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Usuario:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/add.html.twig");
    }
}
