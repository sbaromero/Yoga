<?php

/* CYAYogaBundle:Tipocuota:edit.html.twig */
class __TwigTemplate_7299898d36b9faa605b422116136a99e1b2034a993505810129284ea85cbeed1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Tipocuota:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Tipocuota:messages/success.html.twig");
        echo "
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar tipo de cuota</h2>
\t\t\t\t</div>
\t\t\t\t";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("role" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'errors');
        echo "</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t                <div class=\"form-group\">
\t\t\t                     Nombre
\t\t\t                     ";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
\t\t\t                     <span class=\"text-danger\"> ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'errors');
        echo " </span>
\t\t\t               </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                <div class=\"form-group\">
\t\t\t                     Valor
\t\t\t                     ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "valor", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Valor")));
        echo "
\t\t\t                     <span class=\"text-danger\"> ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "valor", array()), 'errors');
        echo " </span>
\t\t\t                </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "instructorado", array()), 'widget');
        echo " Profesorado 1er. Nivel
\t\t\t                         <span class=\"text-danger\"> ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "instructorado", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "clasesyoga", array()), 'widget');
        echo " Clases de yoga
\t\t\t                         <span class=\"text-danger\"> ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "clasesyoga", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "asociacion", array()), 'widget');
        echo " Asociacion
\t\t\t                         <span class=\"text-danger\"> ";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "asociacion", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "profesorado", array()), 'widget');
        echo " Profesorado 2do Nivel.
\t\t\t                         <span class=\"text-danger\"> ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "profesorado", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 72
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "posgrado", array()), 'widget');
        echo " Posgrado
\t\t\t                         <span class=\"text-danger\"> ";
        // line 73
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "posgrado", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "casillero", array()), 'widget');
        echo " Casillero
\t\t\t                         <span class=\"text-danger\"> ";
        // line 82
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "casillero", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t            <div class=\"col-sm-4\"> 
\t\t\t                   <div class=\"checkbox\">
\t\t\t                     <label>
\t\t\t                         ";
        // line 90
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "otro", array()), 'widget');
        echo " Otro  
\t\t\t                         <span class=\"text-danger\"> ";
        // line 91
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "otro", array()), 'errors');
        echo " </span>
\t\t\t                     </label>
\t\t\t                 </div>
\t\t\t            </div>
\t\t\t            
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 99
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Modificar tipo de cuota", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 103
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Tipocuota:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  200 => 103,  193 => 99,  182 => 91,  178 => 90,  167 => 82,  163 => 81,  152 => 73,  148 => 72,  137 => 64,  133 => 63,  122 => 55,  118 => 54,  107 => 46,  103 => 45,  92 => 37,  88 => 36,  78 => 29,  74 => 28,  64 => 21,  60 => 20,  50 => 13,  46 => 12,  36 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Tipocuota:edit.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Tipocuota/edit.html.twig");
    }
}
