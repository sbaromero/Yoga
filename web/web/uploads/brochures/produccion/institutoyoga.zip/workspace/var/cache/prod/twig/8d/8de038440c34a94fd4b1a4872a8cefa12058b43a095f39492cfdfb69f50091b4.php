<?php

/* CYAYogaBundle:Producto:index.html.twig */
class __TwigTemplate_9656608c36ea2a75fea4bb69151526bb36a865627466789e601f1e73dd0ab26e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Producto:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/danger.html.twig");
        echo "


<div class=\"container-fluid producto\">
        <div class=\"container productos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Productos</h2>
                    <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_producto_add");
        echo "\" class=\"head-link\">
        \t\t\t      <h3>
        \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
    \t\t\t                Agregar nuevo producto
        \t\t\t         </h3>
        \t\t\t </a>
                </div>
               
                <div class=\"col-sm-7\">
                    
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t<div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"\" class=\"form-control\" placeholder=\"Buscar Producto\" />
        \t\t\t\t</div>
        \t\t\t\t
        \t\t\t<div class=\"form-group select-class\">
                            <select class=\"form-control\" id=\"tipoproducto\" name=\"tipoproducto\" value=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "tipoproducto"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Tipo de Producto</option>
                                ";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tipoproductos"]) ? $context["tipoproductos"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["tp"]) {
            // line 34
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tp"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tp"], "descripcion", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "                             </select>
                    </div>
                        
        \t\t\t\t
        \t\t\t\t
        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-sm btn-primary\">
        \t\t\t</form>
                </div>
            </div>
        </div>
</div>

<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 56
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Código", "r.id");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 57
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Descripción", "r.descripcion");
        echo " </th>
\t\t\t\t\t\t\t<th>Costo</th>
\t\t\t\t\t\t\t<th>Precio de Lista </th>
\t\t\t\t\t\t    <th>Stock</th>
\t\t\t\t\t\t     <th>Tipo Prod.</th>
\t\t\t\t\t\t     <th>Estado</th>
\t\t\t\t\t\t
                            <th>Acciones</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 69
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["producto"]) {
            // line 70
            echo "                                <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "id", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "descripcion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 74
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "costo", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 75
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "preciolista", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "stock", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["producto"], "tipoproducto", array()), "descripcion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 78
            if (($this->getAttribute($context["producto"], "isActive", array()) == 1)) {
                // line 79
                echo "\t\t\t\t\t               <b>   <span class=\"text-success\">Activo</span></b>
\t\t\t\t                      ";
            } elseif (($this->getAttribute(            // line 80
$context["producto"], "isActive", array()) == 0)) {
                // line 81
                echo "\t\t\t\t\t\t            <b> <span class=\"text-warning\">Inactivo</span> </b>
                                \t";
            }
            // line 82
            echo "</td>

                                <td class=\"actions\">
                                    <a href=\"";
            // line 85
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_producto_edit", array("id" => $this->getAttribute($context["producto"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                                        ";
            // line 86
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("<i class=\"icon ion-edit\"></i> editar", array(), "messages");
            // line 87
            echo "                                    </a>
                                    
                                <a href=\"";
            // line 89
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_producto_delete", array("id" => $this->getAttribute($context["producto"], "id", array()))), "html", null, true);
            echo "\" onclick=\"return confirm('Está seguro?')\"
\t\t\t                            
                                            
                                       
                                            class=\"btn btn btn-danger btn-delete\"
                                         >
\t\t\t                            eliminar
\t\t\t                     </a>
                                    
                                    
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['producto'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 102
        echo "                    </tbody>
                </table>
           <H4> ";
        // line 104
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("Total Productos:", array(), "messages");
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                ";
        // line 106
        echo "                <div class=\"navigation\">
                    ";
        // line 107
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Producto:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  222 => 107,  219 => 106,  213 => 104,  209 => 102,  190 => 89,  186 => 87,  184 => 86,  180 => 85,  175 => 82,  171 => 81,  169 => 80,  166 => 79,  164 => 78,  160 => 77,  156 => 76,  152 => 75,  148 => 74,  144 => 73,  140 => 72,  134 => 70,  130 => 69,  115 => 57,  111 => 56,  89 => 36,  78 => 34,  74 => 33,  69 => 31,  50 => 15,  39 => 7,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Producto:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Producto/index.html.twig");
    }
}
