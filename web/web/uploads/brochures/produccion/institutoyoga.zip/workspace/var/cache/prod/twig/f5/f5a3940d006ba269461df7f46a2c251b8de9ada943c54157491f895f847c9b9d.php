<?php

/* CYAYogaBundle:Tipocuota:index.html.twig */
class __TwigTemplate_4bf7d09e7ac20898e5e8d89416894f3f296ed5216f3338579eba75e229050630 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Tipocuota:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Tipocuota:messages/success.html.twig");
        echo "
<div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Tipos de Cuota</h2>
                    <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_tipocuota_add");
        echo "\" class=\"head-link\">
    \t\t\t        <h3>
    \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
    \t\t\t            Nuevo tipo de cuota
    \t\t\t         </h3>
    \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t<div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"\" class=\"form-control\" placeholder=\"Buscar tipo de cuota\" required />
        \t\t\t\t</div>
        \t\t\t\t<input type=\"submit\" value=\"buscar\" class=\"btn btn-default\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 37
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Nombre", "t.nombre");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 38
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Valor", "t.valor");
        echo " </th>
\t\t\t\t\t\t\t<th>";
        // line 39
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Profesorado 1er. Nivel", "t.instructorado");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 40
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Clases de yoga", "t.clasesyoga");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 41
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Asociacion", "t.asociacion");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 42
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Profesorado 2do. Nivel", "t.profesorado");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 43
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Posgrado", "t.posgrado");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 44
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Casillero", "t.casillero");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 45
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Otro", "t.otro");
        echo "</th>
                            <th>Acciones</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["tipocuota"]) {
            // line 52
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipocuota"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipocuota"], "nombre", array()), "html", null, true);
            echo "</td>
                                <td>\$ ";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipocuota"], "valor", array()), "html", null, true);
            echo "</td>
                                <td>
                                    ";
            // line 57
            if (($this->getAttribute($context["tipocuota"], "instructorado", array()) == 1)) {
                // line 58
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 59
            echo "    
                                    ";
            // line 60
            if (($this->getAttribute($context["tipocuota"], "instructorado", array()) == 0)) {
                // line 61
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 62
            echo "    
                                </td>
                                <td>
                                    ";
            // line 65
            if (($this->getAttribute($context["tipocuota"], "clasesyoga", array()) == 1)) {
                // line 66
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 67
            echo "    
                                    ";
            // line 68
            if (($this->getAttribute($context["tipocuota"], "clasesyoga", array()) == 0)) {
                // line 69
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 70
            echo "    
                                </td>
                                <td>
                                    ";
            // line 73
            if (($this->getAttribute($context["tipocuota"], "asociacion", array()) == 1)) {
                // line 74
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 75
            echo "    
                                    ";
            // line 76
            if (($this->getAttribute($context["tipocuota"], "asociacion", array()) == 0)) {
                // line 77
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 78
            echo "    
                                </td>
                                <td>
                                    ";
            // line 81
            if (($this->getAttribute($context["tipocuota"], "profesorado", array()) == 1)) {
                // line 82
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 83
            echo "    
                                    ";
            // line 84
            if (($this->getAttribute($context["tipocuota"], "profesorado", array()) == 0)) {
                // line 85
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 86
            echo "    
                                </td>
                                <td>
                                    ";
            // line 89
            if (($this->getAttribute($context["tipocuota"], "posgrado", array()) == 1)) {
                // line 90
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 91
            echo "    
                                    ";
            // line 92
            if (($this->getAttribute($context["tipocuota"], "posgrado", array()) == 0)) {
                // line 93
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 94
            echo "    
                                </td>
                                <td>
                                    ";
            // line 97
            if (($this->getAttribute($context["tipocuota"], "casillero", array()) == 1)) {
                // line 98
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 99
            echo "    
                                    ";
            // line 100
            if (($this->getAttribute($context["tipocuota"], "casillero", array()) == 0)) {
                // line 101
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 102
            echo "    
                                </td>
                                <td>
                                    ";
            // line 105
            if (($this->getAttribute($context["tipocuota"], "otro", array()) == 1)) {
                // line 106
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 107
            echo "    
                                    ";
            // line 108
            if (($this->getAttribute($context["tipocuota"], "otro", array()) == 0)) {
                // line 109
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 110
            echo "    
                                </td>

                                <td class=\"actions\">
                                    <a href=\"";
            // line 114
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_tipocuota_edit", array("id" => $this->getAttribute($context["tipocuota"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                                    Editar
                                    </a>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tipocuota'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 120
        echo "                    </tbody>
                </table>
           <H4> Total Tipos de cuota: ";
        // line 122
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                ";
        // line 124
        echo "                <div class=\"navigation\">
                    ";
        // line 125
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Tipocuota:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  297 => 125,  294 => 124,  290 => 122,  286 => 120,  274 => 114,  268 => 110,  264 => 109,  262 => 108,  259 => 107,  255 => 106,  253 => 105,  248 => 102,  244 => 101,  242 => 100,  239 => 99,  235 => 98,  233 => 97,  228 => 94,  224 => 93,  222 => 92,  219 => 91,  215 => 90,  213 => 89,  208 => 86,  204 => 85,  202 => 84,  199 => 83,  195 => 82,  193 => 81,  188 => 78,  184 => 77,  182 => 76,  179 => 75,  175 => 74,  173 => 73,  168 => 70,  164 => 69,  162 => 68,  159 => 67,  155 => 66,  153 => 65,  148 => 62,  144 => 61,  142 => 60,  139 => 59,  135 => 58,  133 => 57,  128 => 55,  124 => 54,  118 => 52,  114 => 51,  105 => 45,  101 => 44,  97 => 43,  93 => 42,  89 => 41,  85 => 40,  81 => 39,  77 => 38,  73 => 37,  44 => 11,  35 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Tipocuota:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Tipocuota/index.html.twig");
    }
}
