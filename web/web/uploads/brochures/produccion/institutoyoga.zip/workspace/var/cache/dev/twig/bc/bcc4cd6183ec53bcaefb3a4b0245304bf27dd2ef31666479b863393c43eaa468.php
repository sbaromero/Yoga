<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_cd251341e0ef67a8e4a926d967ac4b51eecdc809174c9b726eac5bd1b4ded441 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cd71498fbab82261fa11c05ba820894f52b35db66a1c03708f9c6f70e30ab5f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd71498fbab82261fa11c05ba820894f52b35db66a1c03708f9c6f70e30ab5f9->enter($__internal_cd71498fbab82261fa11c05ba820894f52b35db66a1c03708f9c6f70e30ab5f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_cd71498fbab82261fa11c05ba820894f52b35db66a1c03708f9c6f70e30ab5f9->leave($__internal_cd71498fbab82261fa11c05ba820894f52b35db66a1c03708f9c6f70e30ab5f9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/home/ubuntu/workspace/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/container_attributes.html.php");
    }
}
