<?php

/* CYAYogaBundle:Producto:add.html.twig */
class __TwigTemplate_9533816ac8d6399c551a02b00807bd72895145c53c79f08bd428e1ac3a7bd5e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Producto:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid producto\">
        <div class=\"container producto-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo Producto</h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_producto_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar a listado de productos
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>
    
    ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
           
     <div class=\"container grey-input\">
       <div class=\"row\">
         <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isActive", array()), 'widget');
        echo " 
                         <span class=\"text-danger\"> ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isActive", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
         </div>
      
        <div class=\"row\">
            <div class=\"col-sm-8\"> 
                    <div class=\"form-group\">
                         ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "descripcion", array()), 'label');
        echo "
                         ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "descripcion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "descripcion", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            
        </div>
        <div class=\"row\">
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         Costo \$
                         ";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "costo", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Costo")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "costo", array()), 'errors');
        echo " </span>
                    </div>
            </div>
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         Precio de Lista \$
                         ";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "preciolista", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Precio Lista")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "preciolista", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "stock", array()), 'label');
        echo "
                         ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "stock", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Stock")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 65
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "stock", array()), 'errors');
        echo " </span>
                    </div>
            </div>
         </div>  
         
         <div class=\"row\">
             <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         Tipo de Producto
                         ";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipoproducto", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Tipo Producto")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipoproducto", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                          Proveedor
                         ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "proveedor", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Proveedor")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 82
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "proveedor", array()), 'errors');
        echo " </span>
                    </div>
            </div>

         </div>  
         
         
         
         
         
      <div class=\"row\">   
     <div class=\"col-sm-12\">
                
                ";
        // line 95
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Agregar producto", "attr" => array("class" => "btn alumnos-btn")));
        echo "
                 
                
          </div>
       </div>   
           
    ";
        // line 101
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
        
     </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Producto:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  189 => 101,  180 => 95,  164 => 82,  160 => 81,  151 => 75,  147 => 74,  135 => 65,  131 => 64,  127 => 63,  118 => 57,  114 => 56,  105 => 50,  101 => 49,  89 => 40,  85 => 39,  81 => 38,  69 => 29,  65 => 28,  55 => 21,  41 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Producto:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Producto/add.html.twig");
    }
}
