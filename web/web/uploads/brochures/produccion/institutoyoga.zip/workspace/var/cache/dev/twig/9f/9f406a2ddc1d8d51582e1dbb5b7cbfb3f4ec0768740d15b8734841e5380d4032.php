<?php

/* CYAYogaBundle:Alumnocc:detallepago.html.twig */
class __TwigTemplate_de45a536330b0fb77c16dd15525f4b7f51312c4ac92ba960c764486a97e27caf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Alumnocc:detallepago.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_83be061396e72f28a8382d1b607b14d0d60846c7dfbbc198cbed99ab365f05ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83be061396e72f28a8382d1b607b14d0d60846c7dfbbc198cbed99ab365f05ef->enter($__internal_83be061396e72f28a8382d1b607b14d0d60846c7dfbbc198cbed99ab365f05ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Alumnocc:detallepago.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_83be061396e72f28a8382d1b607b14d0d60846c7dfbbc198cbed99ab365f05ef->leave($__internal_83be061396e72f28a8382d1b607b14d0d60846c7dfbbc198cbed99ab365f05ef_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_3be980a17b629207f7e5a06db0e184fc054bb6d3fbc725d07c8a8c65e056833a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3be980a17b629207f7e5a06db0e184fc054bb6d3fbc725d07c8a8c65e056833a->enter($__internal_3be980a17b629207f7e5a06db0e184fc054bb6d3fbc725d07c8a8c65e056833a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Alumnocc:detallepago.html.twig"));

        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/danger.html.twig");
        echo "
    <div class=\"container-fluid cuenta\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Detalle</h2>
                </div>
                <div class=\"col-sm-7\">
                    <form action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_index");
        echo "\" class=\"btn btn-success\">
                            Regresar
                        </a>

        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

                            <th>";
        // line 35
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Fecha", "m.fecha");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 36
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Monto", "m.monto");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 37
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Descripcion", "m.descripcion");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 38
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Usuario", "m.usuario.nombrecompleto");
        echo "</th>

                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["movimiento"]) {
            // line 44
            echo "                                
                                <td>";
            // line 45
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["movimiento"], "fecha", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td> \$ ";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "monto", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "descripcion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["movimiento"], "usuario", array()), "nombrecompleto", array()), "html", null, true);
            echo "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['movimiento'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "                    </tbody>
                </table>
           <H4> Total Cuotas: ";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                <div class=\"navigation\">
                    ";
        // line 55
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_3be980a17b629207f7e5a06db0e184fc054bb6d3fbc725d07c8a8c65e056833a->leave($__internal_3be980a17b629207f7e5a06db0e184fc054bb6d3fbc725d07c8a8c65e056833a_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Alumnocc:detallepago.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 55,  134 => 53,  130 => 51,  121 => 48,  117 => 47,  113 => 46,  109 => 45,  106 => 44,  102 => 43,  94 => 38,  90 => 37,  86 => 36,  82 => 35,  60 => 16,  48 => 7,  44 => 6,  40 => 5,  34 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

  
{% block body %}
{{ parent() }}
{{ include('CYAYogaBundle:Alumnocc:messages/success.html.twig')}}
{{ include('CYAYogaBundle:Alumnocc:messages/danger.html.twig')}}
    <div class=\"container-fluid cuenta\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Detalle</h2>
                </div>
                <div class=\"col-sm-7\">
                    <form action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <a href=\"{{ path('cya_alumnocc_index') }}\" class=\"btn btn-success\">
                            Regresar
                        </a>

        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

                            <th>{{ knp_pagination_sortable(pagination, 'Fecha', 'm.fecha') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Monto', 'm.monto') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Descripcion', 'm.descripcion') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Usuario', 'm.usuario.nombrecompleto') }}</th>

                        </tr>
                    </thead>
                    <tbody>
                        {% for movimiento in pagination %}
                                
                                <td>{{ movimiento.fecha | date('d m Y - h:i:s') }}</td>
                                <td> \$ {{ movimiento.monto }}</td>
                                <td>{{ movimiento.descripcion }}</td>
                                <td>{{ movimiento.usuario.nombrecompleto }}</td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
           <H4> Total Cuotas: {{ pagination.getTotalItemCount }}</H4>
                <div class=\"navigation\">
                    {{ knp_pagination_render(pagination) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "CYAYogaBundle:Alumnocc:detallepago.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Alumnocc/detallepago.html.twig");
    }
}
