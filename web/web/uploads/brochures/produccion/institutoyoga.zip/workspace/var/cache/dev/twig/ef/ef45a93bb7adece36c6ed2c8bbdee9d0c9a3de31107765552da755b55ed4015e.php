<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_c9377054425de25477eeb3170e41987ac500ae2dfd1cbe42509a27004fd0a06b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_397a3d1a70a9a824946f022ce41040078551805233328341d9c6ee6d330e8b32 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_397a3d1a70a9a824946f022ce41040078551805233328341d9c6ee6d330e8b32->enter($__internal_397a3d1a70a9a824946f022ce41040078551805233328341d9c6ee6d330e8b32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_397a3d1a70a9a824946f022ce41040078551805233328341d9c6ee6d330e8b32->leave($__internal_397a3d1a70a9a824946f022ce41040078551805233328341d9c6ee6d330e8b32_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/home/ubuntu/workspace/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
