<?php

/* CYAYogaBundle:Tipoproducto:index.html.twig */
class __TwigTemplate_798aa60f827e92bd7f8890a1c555a90799b6ac2758407d223ee52e472cf8f475 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Tipoproducto:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Tipoproducto:messages/success.html.twig");
        echo "
<div class=\"container-fluid producto\">
        <div class=\"container producto-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Tipos de Productos</h2>
                    <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_tipoproducto_add");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
    \t\t\t                Agregar nuevo tipo de producto
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t<div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"\" class=\"form-control\" placeholder=\"Buscar tipo producto\" required />
        \t\t\t\t</div>
        \t\t\t\t<input type=\"submit\" value=\"buscar\" class=\"btn btn-default\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 38
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Código", "r.id");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 39
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Tipo Producto", "r.descripcion");
        echo " </th>
\t\t\t\t\t\t
                            <th>Acciones</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["tipoproducto"]) {
            // line 47
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipoproducto"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipoproducto"], "id", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipoproducto"], "descripcion", array()), "html", null, true);
            echo "</td>
                                
                                

                                <td class=\"actions\">
                                    <a href=\"";
            // line 55
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_tipoproducto_edit", array("id" => $this->getAttribute($context["tipoproducto"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                                        ";
            // line 56
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("<i class=\"icon ion-edit\"></i>", array(), "messages");
            // line 57
            echo "                                    </a>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tipoproducto'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "                    </tbody>
                </table>
           <H4> ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("Total Tipos Producto:", array(), "messages");
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                ";
        // line 65
        echo "                <div class=\"navigation\">
                    ";
        // line 66
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Tipoproducto:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 66,  134 => 65,  128 => 63,  124 => 61,  115 => 57,  113 => 56,  109 => 55,  101 => 50,  97 => 49,  91 => 47,  87 => 46,  77 => 39,  73 => 38,  44 => 12,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Tipoproducto:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Tipoproducto/index.html.twig");
    }
}
