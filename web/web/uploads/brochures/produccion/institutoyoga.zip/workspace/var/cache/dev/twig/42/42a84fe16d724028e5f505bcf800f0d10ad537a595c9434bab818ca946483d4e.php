<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_d13a66bf1928e52d5d634d7931bf6083c15fd5b78cc6be65c7954b70d46f01ff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2d4184310339eb6ad13b766f30772e10a91f997896d5229845d14bc12cd7fe1e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d4184310339eb6ad13b766f30772e10a91f997896d5229845d14bc12cd7fe1e->enter($__internal_2d4184310339eb6ad13b766f30772e10a91f997896d5229845d14bc12cd7fe1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_2d4184310339eb6ad13b766f30772e10a91f997896d5229845d14bc12cd7fe1e->leave($__internal_2d4184310339eb6ad13b766f30772e10a91f997896d5229845d14bc12cd7fe1e_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_f9f5b5659237aa95fd16e00592725a3e451af13c1fdeb0d3468a4be4ce6dea7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9f5b5659237aa95fd16e00592725a3e451af13c1fdeb0d3468a4be4ce6dea7c->enter($__internal_f9f5b5659237aa95fd16e00592725a3e451af13c1fdeb0d3468a4be4ce6dea7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        echo "";
        
        $__internal_f9f5b5659237aa95fd16e00592725a3e451af13c1fdeb0d3468a4be4ce6dea7c->leave($__internal_f9f5b5659237aa95fd16e00592725a3e451af13c1fdeb0d3468a4be4ce6dea7c_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/home/ubuntu/workspace/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
