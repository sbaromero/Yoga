<?php

/* CYAYogaBundle:Alumnocc:indexpublic.html.twig */
class __TwigTemplate_159312786d87f26bc8d63cac510e3fd4c9fd70c4467875903eb3a57dcdbf873a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Alumnocc:indexpublic.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/danger.html.twig");
        echo "
  <br>
    <div class=\"container-fluid cuenta\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Cuotas</h2>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        
                        <div class=\"form-group\">
                          <select class=\"form-control\" id=\"pago\" name=\"pago\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "pago"), "method"), "html", null, true);
        echo "\">
                            <option value=\"\" selected disabled>Tipo</option>
                            <option value=\"\">Todas</option>
                            <option value=\"S\">Pagas</option>
                            <option value=\"N\">No pagas</option>
                          </select>
                        </div>
                        
          \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-success\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>Alumno</th>
\t\t\t\t\t\t\t<th>Vencimiento</th>
\t\t\t\t\t\t\t<th>Debe</th>
\t\t\t\t\t\t\t<th>Pagado</th>
\t\t\t\t\t\t\t<th>Bonificación}</th>
\t\t\t\t\t\t\t<th>Modificacion</th>
\t\t\t\t\t\t\t<th>Tipo</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 54
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["alumnocc"]) {
            // line 55
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["alumnocc"], "usuario", array()), "apellido", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["alumnocc"], "usuario", array()), "nombre", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 58
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["alumnocc"], "fechavencimiento", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td>";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "deuda", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "pagado", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "bonificacion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 62
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["alumnocc"], "fechamodificacion", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td>";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "tipo", array()), "html", null, true);
            echo "</td>
                               
                               
                                <td class=\"actions\">
                                    <a href=\"";
            // line 67
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_detallepagopublic", array("id" => $this->getAttribute($context["alumnocc"], "id", array()))), "html", null, true);
            echo "\" 
                                    ";
            // line 68
            if (($this->getAttribute($context["alumnocc"], "pagado", array()) == 0)) {
                // line 69
                echo "                                        class=\"btn btn-warning disabled\"
                                    ";
            } elseif (($this->getAttribute(            // line 70
$context["alumnocc"], "pagado", array()) > 0)) {
                echo " 
                                        class=\"btn btn-warning\"
                                    ";
            }
            // line 72
            echo " >
                                        Detalles
                                    </a>
                                    
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['alumnocc'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "                    </tbody>
                </table>
           <H4> Total Cuotas: ";
        // line 81
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                <div class=\"navigation\">
                    ";
        // line 83
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Alumnocc:indexpublic.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 83,  166 => 81,  162 => 79,  150 => 72,  144 => 70,  141 => 69,  139 => 68,  135 => 67,  128 => 63,  124 => 62,  120 => 61,  116 => 60,  112 => 59,  108 => 58,  102 => 57,  96 => 55,  92 => 54,  54 => 19,  39 => 7,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Alumnocc:indexpublic.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Alumnocc/indexpublic.html.twig");
    }
}
