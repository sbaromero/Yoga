<?php

/* CYAYogaBundle:Locker:add.html.twig */
class __TwigTemplate_7063df09edf18fd7bb4672d128df7c22437c3e10b44e609c0a40124b22d76fa9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Locker:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid producto\">
        <div class=\"container producto-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo Locker</h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_locker_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar a listado lockers
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>

    
    ";
        // line 22
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
           
     <div class=\"container grey-input\">
        <div class=\"row\">
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         Descripción del locker
                         ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "descripcion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripcion")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "descripcion", array()), 'errors');
        echo " </span>
                    </div>
            </div>

            
            <div class=\"col-sm-12\">
                
                ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Agregar Locker", "attr" => array("class" => "btn alumnos-btn")));
        echo "
                 
                
            </div>
            ";
        // line 41
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
         </div>
     </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Locker:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 41,  80 => 37,  70 => 30,  66 => 29,  56 => 22,  41 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Locker:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Locker/add.html.twig");
    }
}
