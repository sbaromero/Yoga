<?php

/* CYAYogaBundle:Alumnocc:index.html.twig */
class __TwigTemplate_3038563ad32f30f1a2d21b146bbc9d8855f6e81fcdba13e24efde025e09394cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Alumnocc:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b7a7fccd817a68a74affd9793bc4a45ff1bac9ca91d779d000ea310802c83ae8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7a7fccd817a68a74affd9793bc4a45ff1bac9ca91d779d000ea310802c83ae8->enter($__internal_b7a7fccd817a68a74affd9793bc4a45ff1bac9ca91d779d000ea310802c83ae8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Alumnocc:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b7a7fccd817a68a74affd9793bc4a45ff1bac9ca91d779d000ea310802c83ae8->leave($__internal_b7a7fccd817a68a74affd9793bc4a45ff1bac9ca91d779d000ea310802c83ae8_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_0f35f3d57e17018a6f50941f302bc51f7b217032c12ee5b04fdd9d1ffc8fc27b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f35f3d57e17018a6f50941f302bc51f7b217032c12ee5b04fdd9d1ffc8fc27b->enter($__internal_0f35f3d57e17018a6f50941f302bc51f7b217032c12ee5b04fdd9d1ffc8fc27b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Alumnocc:index.html.twig"));

        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/danger.html.twig");
        echo "
    <div class=\"container-fluid cuenta\">
        <div class=\"container cuenta-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Cuotas y Cuentas Corrientes de Alumnos </h2>
                   <h4>Leyenda: pc (pago de cuota)  - cc (cuota cancelada) - vp (venta de producto) - pd (pago diario)  </h4>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        
                        <div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"pago\" name=\"pago\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "pago"), "method"), "html", null, true);
        echo "\">
                            <option value=\"\" selected disabled>Tipo</option>
                            <option value=\"\">Todas</option>
                            <option value=\"S\">Pagas</option>
                            <option value=\"N\">No pagas</option>
                          </select>
                        </div>
                        
        \t\t\t\t<div class=\"form-group\">
                            <select class=\"selectpicker\" data-live-search=\"true\" id=\"usuario\" name=\"usuario\" value=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "usuario"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Usuario</option>
                                ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["usuarios"]) ? $context["usuarios"] : $this->getContext($context, "usuarios")));
        foreach ($context['_seq'] as $context["_key"] => $context["us"]) {
            // line 31
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "nombrecompleto", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['us'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "                             </select>
                        </div>

        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-success\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 52
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Alumno", "a.nombrecompleto");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 53
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Vencimiento Cuota", "a.fechavencimiento");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 54
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Debe", "a.deuda");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 55
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Pagado", "a.pagado");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 56
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Bonificación", "a.bonificacion");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 57
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Modificacion", "a.fechamodificacion");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 58
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Tipo", "a.tipo");
        echo "</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 63
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["alumnocc"]) {
            // line 64
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 66
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["alumnocc"], "usuario", array()), "apellido", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["alumnocc"], "usuario", array()), "nombre", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 67
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["alumnocc"], "fechavencimiento", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td>";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "deuda", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 69
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "pagado", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "bonificacion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 71
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["alumnocc"], "fechamodificacion", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td>";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "tipo", array()), "html", null, true);
            echo "</td>
                               
                               
                                <td class=\"actions\">
                                    <a href=\"";
            // line 76
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_detallepago", array("id" => $this->getAttribute($context["alumnocc"], "id", array()))), "html", null, true);
            echo "\" 
                                    ";
            // line 77
            if ((($this->getAttribute($context["alumnocc"], "pagado", array()) == 0) || ($this->getAttribute($context["alumnocc"], "tipo", array()) != "VP"))) {
                // line 78
                echo "                                        class=\"btn btn-warning disabled\"
                                    ";
            } elseif ((($this->getAttribute(            // line 79
$context["alumnocc"], "pagado", array()) > 0) || ($this->getAttribute($context["alumnocc"], "tipo", array()) == "VP"))) {
                echo " 
                                        class=\"btn btn-warning\"
                                    ";
            }
            // line 81
            echo " >
                                        detalles
                                    </a>
                                    
                                    <a href=\"";
            // line 85
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_pago", array("id" => $this->getAttribute($context["alumnocc"], "id", array()))), "html", null, true);
            echo "\"
                                        ";
            // line 86
            if (($this->getAttribute($context["alumnocc"], "deuda", array()) <= ($this->getAttribute($context["alumnocc"], "pagado", array()) + $this->getAttribute($context["alumnocc"], "bonificacion", array())))) {
                // line 87
                echo "                                            class=\"btn btn-success disabled\"
                                        ";
            } elseif (($this->getAttribute(            // line 88
$context["alumnocc"], "deuda", array()) > ($this->getAttribute($context["alumnocc"], "pagado", array()) + $this->getAttribute($context["alumnocc"], "bonificacion", array())))) {
                echo " 
                                            class=\"btn btn-success\"
                                        ";
            }
            // line 90
            echo " >
                                        Pagar
                                    </a>
                                    
                                    <a href=\"";
            // line 94
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_delete", array("id" => $this->getAttribute($context["alumnocc"], "id", array()))), "html", null, true);
            echo "\" onclick=\"return confirm('Está seguro??')\"
\t\t\t                            ";
            // line 95
            if (($this->getAttribute($context["alumnocc"], "tipo", array()) == "CC")) {
                // line 96
                echo "                                            class=\"btn btn btn-danger btn-delete\"
                                        ";
            } elseif (($this->getAttribute(            // line 97
$context["alumnocc"], "tipo", array()) == "PD")) {
                echo " 
                                            class=\"btn btn btn-danger btn-delete disabled\"
                                        ";
            } elseif (($this->getAttribute(            // line 99
$context["alumnocc"], "tipo", array()) == "VP")) {
                echo " 
                                            class=\"btn btn btn-danger btn-delete\"
                                        ";
            } elseif (($this->getAttribute(            // line 101
$context["alumnocc"], "tipo", array()) == "PC")) {
                // line 102
                echo "                                         class=\"btn btn btn-danger btn-delete\"   
                                        ";
            }
            // line 103
            echo " >
\t\t\t                            eliminar
\t\t\t                        </a>
                                    
                                </td>
                                
                                
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['alumnocc'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 112
        echo "                    </tbody>
                </table>
           <H4> Total Movimientos: ";
        // line 114
        echo twig_escape_filter($this->env, (isset($context["contador"]) ? $context["contador"] : $this->getContext($context, "contador")), "html", null, true);
        echo "</H4>
          <H4> Total Deudas: ";
        // line 115
        echo twig_escape_filter($this->env, (isset($context["deudas"]) ? $context["deudas"] : $this->getContext($context, "deudas")), "html", null, true);
        echo "</H4>
           <H4> Total Pagado: ";
        // line 116
        echo twig_escape_filter($this->env, (isset($context["pagados"]) ? $context["pagados"] : $this->getContext($context, "pagados")), "html", null, true);
        echo "</H4>
            <H4> Total Bonificaciones: ";
        // line 117
        echo twig_escape_filter($this->env, (isset($context["bonificaciones"]) ? $context["bonificaciones"] : $this->getContext($context, "bonificaciones")), "html", null, true);
        echo "</H4>
            <H4> SALDO TOTAL: ";
        // line 118
        echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : $this->getContext($context, "saldo")), "html", null, true);
        echo "</H4>
                <div class=\"navigation\">
                    ";
        // line 120
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_0f35f3d57e17018a6f50941f302bc51f7b217032c12ee5b04fdd9d1ffc8fc27b->leave($__internal_0f35f3d57e17018a6f50941f302bc51f7b217032c12ee5b04fdd9d1ffc8fc27b_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Alumnocc:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  297 => 120,  292 => 118,  288 => 117,  284 => 116,  280 => 115,  276 => 114,  272 => 112,  258 => 103,  254 => 102,  252 => 101,  247 => 99,  242 => 97,  239 => 96,  237 => 95,  233 => 94,  227 => 90,  221 => 88,  218 => 87,  216 => 86,  212 => 85,  206 => 81,  200 => 79,  197 => 78,  195 => 77,  191 => 76,  184 => 72,  180 => 71,  176 => 70,  172 => 69,  168 => 68,  164 => 67,  158 => 66,  152 => 64,  148 => 63,  140 => 58,  136 => 57,  132 => 56,  128 => 55,  124 => 54,  120 => 53,  116 => 52,  95 => 33,  84 => 31,  80 => 30,  75 => 28,  63 => 19,  48 => 7,  44 => 6,  40 => 5,  34 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

  
{% block body %}
{{ parent() }}
{{ include('CYAYogaBundle:Alumnocc:messages/success.html.twig')}}
{{ include('CYAYogaBundle:Alumnocc:messages/danger.html.twig')}}
    <div class=\"container-fluid cuenta\">
        <div class=\"container cuenta-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Cuotas y Cuentas Corrientes de Alumnos </h2>
                   <h4>Leyenda: pc (pago de cuota)  - cc (cuota cancelada) - vp (venta de producto) - pd (pago diario)  </h4>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        
                        <div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"pago\" name=\"pago\" value=\"{{ app.request.get('pago') }}\">
                            <option value=\"\" selected disabled>Tipo</option>
                            <option value=\"\">Todas</option>
                            <option value=\"S\">Pagas</option>
                            <option value=\"N\">No pagas</option>
                          </select>
                        </div>
                        
        \t\t\t\t<div class=\"form-group\">
                            <select class=\"selectpicker\" data-live-search=\"true\" id=\"usuario\" name=\"usuario\" value=\"{{ app.request.get('usuario') }}\">
                                <option value=\"\" selected disabled>Usuario</option>
                                {% for us in usuarios %}
                                    <option value=\"{{ us.id }}\">{{ us.nombrecompleto }}</option>
                                {% endfor %}
                             </select>
                        </div>

        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-success\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Alumno', 'a.nombrecompleto') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Vencimiento Cuota', 'a.fechavencimiento') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Debe', 'a.deuda') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Pagado', 'a.pagado') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Bonificación', 'a.bonificacion') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Modificacion', 'a.fechamodificacion') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Tipo', 'a.tipo') }}</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for alumnocc in pagination %}
                            <tr data-id=\"{{ alumnocc.id }}\">
                                
                                <td>{{ alumnocc.usuario.apellido }}, {{ alumnocc.usuario.nombre }}</td>
                                <td>{{ alumnocc.fechavencimiento | date('d m Y - h:i:s') }}</td>
                                <td>{{ alumnocc.deuda }}</td>
                                <td>{{ alumnocc.pagado }}</td>
                                <td>{{ alumnocc.bonificacion }}</td>
                                <td>{{ alumnocc.fechamodificacion | date('d m Y - h:i:s') }}</td>
                                <td>{{ alumnocc.tipo }}</td>
                               
                               
                                <td class=\"actions\">
                                    <a href=\"{{ path('cya_alumnocc_detallepago', {id: alumnocc.id }) }}\" 
                                    {% if alumnocc.pagado == 0 or alumnocc.tipo != 'VP' %}
                                        class=\"btn btn-warning disabled\"
                                    {% elseif alumnocc.pagado > 0 or alumnocc.tipo == 'VP' %} 
                                        class=\"btn btn-warning\"
                                    {% endif %} >
                                        detalles
                                    </a>
                                    
                                    <a href=\"{{ path('cya_alumnocc_pago', {id: alumnocc.id }) }}\"
                                        {% if alumnocc.deuda <= (alumnocc.pagado + alumnocc.bonificacion)  %}
                                            class=\"btn btn-success disabled\"
                                        {% elseif alumnocc.deuda > (alumnocc.pagado + alumnocc.bonificacion) %} 
                                            class=\"btn btn-success\"
                                        {% endif %} >
                                        Pagar
                                    </a>
                                    
                                    <a href=\"{{ path('cya_alumnocc_delete', {id: alumnocc.id }) }}\" onclick=\"return confirm('Está seguro??')\"
\t\t\t                            {% if alumnocc.tipo == 'CC' %}
                                            class=\"btn btn btn-danger btn-delete\"
                                        {% elseif alumnocc.tipo == 'PD' %} 
                                            class=\"btn btn btn-danger btn-delete disabled\"
                                        {% elseif alumnocc.tipo == 'VP' %} 
                                            class=\"btn btn btn-danger btn-delete\"
                                        {% elseif alumnocc.tipo == 'PC' %}
                                         class=\"btn btn btn-danger btn-delete\"   
                                        {% endif %} >
\t\t\t                            eliminar
\t\t\t                        </a>
                                    
                                </td>
                                
                                
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
           <H4> Total Movimientos: {{ contador }}</H4>
          <H4> Total Deudas: {{ deudas }}</H4>
           <H4> Total Pagado: {{ pagados }}</H4>
            <H4> Total Bonificaciones: {{ bonificaciones }}</H4>
            <H4> SALDO TOTAL: {{ saldo }}</H4>
                <div class=\"navigation\">
                    {{ knp_pagination_render(pagination) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "CYAYogaBundle:Alumnocc:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Alumnocc/index.html.twig");
    }
}
