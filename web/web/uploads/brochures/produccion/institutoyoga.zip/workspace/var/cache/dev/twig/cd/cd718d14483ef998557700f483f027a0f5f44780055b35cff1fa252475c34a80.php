<?php

/* CYAYogaBundle:Detalleventa:add.html.1.twig */
class __TwigTemplate_d3c9287f16b832ed94f4ee4f289e2c25e779b23bbc9b0d330b010ab3848dd5ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Detalleventa:add.html.1.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_112fa8c02ae3af60cb98d3a9d96175d4af1586f60417084187bb49734e1167d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_112fa8c02ae3af60cb98d3a9d96175d4af1586f60417084187bb49734e1167d2->enter($__internal_112fa8c02ae3af60cb98d3a9d96175d4af1586f60417084187bb49734e1167d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Detalleventa:add.html.1.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_112fa8c02ae3af60cb98d3a9d96175d4af1586f60417084187bb49734e1167d2->leave($__internal_112fa8c02ae3af60cb98d3a9d96175d4af1586f60417084187bb49734e1167d2_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_c875c2f3d7572629da07d2e21c87b9699790d2eceab09afc7d416a9345a2dab0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c875c2f3d7572629da07d2e21c87b9699790d2eceab09afc7d416a9345a2dab0->enter($__internal_c875c2f3d7572629da07d2e21c87b9699790d2eceab09afc7d416a9345a2dab0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Detalleventa:add.html.1.twig"));

        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Detalleventa:messages/success.html.twig");
        echo "
<div class=\"container-fluid productos\">
        <div class=\"container productos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Venta de Productos</h2>
                </div>
            </div>
        </div>
</div>
    
\t<div class=\"container\">
\t    ";
        // line 18
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
\t    <div class=\"container grey-input\">
        <div class=\"row\">

            <div class=\"col-sm-2\">
            <div class=\"form-group\">
            Elija los Productos
            <select class=\"selectpicker\" data-live-search=\"true\" id=\"producto\" name=\"producto\" value=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "producto"), "method"), "html", null, true);
        echo "\">
                <option value=\"\" selected disabled>Producto</option>
                ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["productos"]) ? $context["productos"] : $this->getContext($context, "productos")));
        foreach ($context['_seq'] as $context["_key"] => $context["us"]) {
            // line 28
            echo "                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "descripcion", array()), "html", null, true);
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['us'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "             </select>
            </div>
            </div> 
        </div>
        <div class=\"row\">   
            <div class=\"col-sm-2\"> 
                <div class=\"form-group\">
                     Cantidad
                     ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "cantidad", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Cantidad")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "cantidad", array()), 'errors');
        echo " </span>
                </div>
            </div>



            <div class=\"col-sm-12\">
                ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Agregar Producto", "attr" => array("class" => "btn alumnos-btn")));
        echo "
            </div>
            
            
          </div>
          </div>
            ";
        // line 52
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
         
        
         
 
 ";
        
        $__internal_c875c2f3d7572629da07d2e21c87b9699790d2eceab09afc7d416a9345a2dab0->leave($__internal_c875c2f3d7572629da07d2e21c87b9699790d2eceab09afc7d416a9345a2dab0_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Detalleventa:add.html.1.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 52,  113 => 46,  103 => 39,  99 => 38,  89 => 30,  78 => 28,  74 => 27,  69 => 25,  59 => 18,  44 => 6,  40 => 5,  34 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

  
{% block body %}
{{ parent() }}
{{ include('CYAYogaBundle:Detalleventa:messages/success.html.twig')}}
<div class=\"container-fluid productos\">
        <div class=\"container productos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Venta de Productos</h2>
                </div>
            </div>
        </div>
</div>
    
\t<div class=\"container\">
\t    {{ form_start(form, {'attr' : {'role' : 'form'}, 'action':'', 'method':'POST' }) }}
\t    <div class=\"container grey-input\">
        <div class=\"row\">

            <div class=\"col-sm-2\">
            <div class=\"form-group\">
            Elija los Productos
            <select class=\"selectpicker\" data-live-search=\"true\" id=\"producto\" name=\"producto\" value=\"{{ app.request.get('producto') }}\">
                <option value=\"\" selected disabled>Producto</option>
                {% for us in productos %}
                    <option value=\"{{ us.id }}\">{{ us.descripcion }}</option>
                {% endfor %}
             </select>
            </div>
            </div> 
        </div>
        <div class=\"row\">   
            <div class=\"col-sm-2\"> 
                <div class=\"form-group\">
                     Cantidad
                     {{ form_widget(form.cantidad, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Cantidad'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.cantidad) }} </span>
                </div>
            </div>



            <div class=\"col-sm-12\">
                {{ form_widget(form.save, {'label' : 'Agregar Producto', 'attr': {'class': 'btn alumnos-btn'} }) }}
            </div>
            
            
          </div>
          </div>
            {{ form_end(form) }}
    </div>
         
        
         
 
 {% endblock %}
", "CYAYogaBundle:Detalleventa:add.html.1.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Detalleventa/add.html.1.twig");
    }
}
