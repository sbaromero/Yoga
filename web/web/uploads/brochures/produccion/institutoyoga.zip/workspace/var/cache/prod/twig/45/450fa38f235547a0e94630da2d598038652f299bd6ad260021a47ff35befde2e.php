<?php

/* CYAYogaBundle:Alumnocc:pago.html.twig */
class __TwigTemplate_be032f6251a7c3841993f70cd5b8aadbe049a2300cdd307cf1cded6d294caed8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Alumnocc:pago.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/success.html.twig");
        echo "
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Pago de cuota</h2>
\t\t\t\t\t<h3>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["nombrecompleto"]) ? $context["nombrecompleto"] : null), "html", null, true);
        echo "</h3>
\t\t\t\t\t<h3> Vencimiento: ";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["vencimiento"]) ? $context["vencimiento"] : null), "html", null, true);
        echo "</h3>
\t\t\t\t\t<h3> Saldo: \$";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : null), "html", null, true);
        echo "</h3>
\t\t\t\t
\t\t\t\t</div>
\t\t\t\t";
        // line 16
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("rol" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'errors');
        echo "</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Monto cuota
\t\t\t\t\t        ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "deuda", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Monto cuota")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "deuda", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
                        <div class=\"form-group\">
\t\t\t\t\t        Pago
\t\t\t\t\t        ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "pagado", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Pago")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "pagado", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div> 
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Bonificacion
\t\t\t\t\t        ";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "bonificacion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Bonificacion")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "bonificacion", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>  
\t\t\t\t\t\t
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Realizar pago", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 44
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Alumnocc:pago.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 44,  107 => 40,  98 => 34,  94 => 33,  87 => 29,  83 => 28,  76 => 24,  72 => 23,  63 => 17,  59 => 16,  53 => 13,  49 => 12,  45 => 11,  36 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Alumnocc:pago.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Alumnocc/pago.html.twig");
    }
}
