<?php

/* CYAYogaBundle:Maestroventa:index.html.twig */
class __TwigTemplate_b3e585b87f79065db73b572bc6ee35a14866c8c4330ee66ef505a14216938a99 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Maestroventa:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a24a72d441c5eecbe10b994deb5a054793ccc8208f9bf2cfc42d438982ebed3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a24a72d441c5eecbe10b994deb5a054793ccc8208f9bf2cfc42d438982ebed3c->enter($__internal_a24a72d441c5eecbe10b994deb5a054793ccc8208f9bf2cfc42d438982ebed3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Maestroventa:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a24a72d441c5eecbe10b994deb5a054793ccc8208f9bf2cfc42d438982ebed3c->leave($__internal_a24a72d441c5eecbe10b994deb5a054793ccc8208f9bf2cfc42d438982ebed3c_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_8a378e60ba0d1297865c71641ff1edfd1763bfecce5d84e33db3ca5c625f9eef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a378e60ba0d1297865c71641ff1edfd1763bfecce5d84e33db3ca5c625f9eef->enter($__internal_8a378e60ba0d1297865c71641ff1edfd1763bfecce5d84e33db3ca5c625f9eef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Maestroventa:index.html.twig"));

        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/danger.html.twig");
        echo "


<div class=\"container-fluid producto\">
        <div class=\"container productos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Productos</h2>
                    <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_producto_add");
        echo "\" class=\"head-link\">
        \t\t\t      <h3>
        \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
    \t\t\t                Agregar nuevo producto
        \t\t\t         </h3>
        \t\t\t </a>
                </div>
               
                <div class=\"col-sm-7\">
                    
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t<div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"\" class=\"form-control\" placeholder=\"Buscar Producto\" required />
        \t\t\t\t</div>
        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-sm btn-primary\">
        \t\t\t</form>
                </div>
            </div>
        </div>
</div>

<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 44
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Código", "r.id");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 45
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Descripción", "r.descripcion");
        echo " </th>
\t\t\t\t\t\t\t<th>Costo</th>
\t\t\t\t\t\t\t<th>Precio de Lista </th>
\t\t\t\t\t\t    <th>Stock</th>
\t\t\t\t\t\t    <th>Tipo Prod. </th>
\t\t\t\t\t\t     <th>Estado</th>
\t\t\t\t\t\t
                            <th>Acciones</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["producto"]) {
            // line 58
            echo "                                <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "id", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "descripcion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "costo", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "preciolista", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "stock", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["producto"], "tipoproducto", array()), "descripcion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 66
            if (($this->getAttribute($context["producto"], "isActive", array()) == 1)) {
                // line 67
                echo "\t\t\t\t\t               <b>   <span class=\"text-success\">Activo</span></b>
\t\t\t\t                      ";
            } elseif (($this->getAttribute(            // line 68
$context["producto"], "isActive", array()) == 0)) {
                // line 69
                echo "\t\t\t\t\t\t            <b> <span class=\"text-warning\">Inactivo</span> </b>
                                \t";
            }
            // line 70
            echo "</td>

                                <td class=\"actions\">
                                    <a href=\"";
            // line 73
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_producto_edit", array("id" => $this->getAttribute($context["producto"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                                        ";
            // line 74
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("<i class=\"icon ion-edit\"></i>", array(), "messages");
            // line 75
            echo "                                    </a>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['producto'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "                    </tbody>
                </table>
           <H4> ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("Total Tipos Producto:", array(), "messages");
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                ";
        // line 83
        echo "                <div class=\"navigation\">
                    ";
        // line 84
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_8a378e60ba0d1297865c71641ff1edfd1763bfecce5d84e33db3ca5c625f9eef->leave($__internal_8a378e60ba0d1297865c71641ff1edfd1763bfecce5d84e33db3ca5c625f9eef_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Maestroventa:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 84,  185 => 83,  179 => 81,  175 => 79,  166 => 75,  164 => 74,  160 => 73,  155 => 70,  151 => 69,  149 => 68,  146 => 67,  144 => 66,  140 => 65,  136 => 64,  132 => 63,  128 => 62,  124 => 61,  120 => 60,  114 => 58,  110 => 57,  95 => 45,  91 => 44,  59 => 15,  48 => 7,  44 => 6,  40 => 5,  34 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

  
{% block body %}
{{ parent() }}
{{ include('CYAYogaBundle:Usuario:messages/success.html.twig')}}
{{ include('CYAYogaBundle:Usuario:messages/danger.html.twig')}}


<div class=\"container-fluid producto\">
        <div class=\"container productos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Productos</h2>
                    <a href=\"{{ path('cya_producto_add') }}\" class=\"head-link\">
        \t\t\t      <h3>
        \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
    \t\t\t                Agregar nuevo producto
        \t\t\t         </h3>
        \t\t\t </a>
                </div>
               
                <div class=\"col-sm-7\">
                    
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t<div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"\" class=\"form-control\" placeholder=\"Buscar Producto\" required />
        \t\t\t\t</div>
        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-sm btn-primary\">
        \t\t\t</form>
                </div>
            </div>
        </div>
</div>

<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Código', 'r.id') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Descripción', 'r.descripcion') }} </th>
\t\t\t\t\t\t\t<th>Costo</th>
\t\t\t\t\t\t\t<th>Precio de Lista </th>
\t\t\t\t\t\t    <th>Stock</th>
\t\t\t\t\t\t    <th>Tipo Prod. </th>
\t\t\t\t\t\t     <th>Estado</th>
\t\t\t\t\t\t
                            <th>Acciones</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        {% for producto in pagination %}
                                <tr data-id=\"{{ producto.id }}\">
                                
                                <td>{{ producto.id }}</td>
                                <td>{{ producto.descripcion }}</td>
                                <td>{{ producto.costo }}</td>
                                <td>{{ producto.preciolista }}</td>
                                <td>{{ producto.stock }}</td>
                                <td>{{ producto.tipoproducto.descripcion }}</td>
                                <td>{% if producto.isActive == 1 %}
\t\t\t\t\t               <b>   <span class=\"text-success\">Activo</span></b>
\t\t\t\t                      {% elseif producto.isActive == 0 %}
\t\t\t\t\t\t            <b> <span class=\"text-warning\">Inactivo</span> </b>
                                \t{% endif %}</td>

                                <td class=\"actions\">
                                    <a href=\"{{ path('cya_producto_edit', {id: producto.id }) }}\" class=\"btn btn-sm btn-primary\">
                                        {% trans %} <i class=\"icon ion-edit\"></i> {% endtrans %}
                                    </a>
                                </td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
           <H4> {% trans %}Total Tipos Producto:{% endtrans %} {{ pagination.getTotalItemCount }}</H4>
                {# display navigation #}
                <div class=\"navigation\">
                    {{ knp_pagination_render(pagination) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}", "CYAYogaBundle:Maestroventa:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Maestroventa/index.html.twig");
    }
}
