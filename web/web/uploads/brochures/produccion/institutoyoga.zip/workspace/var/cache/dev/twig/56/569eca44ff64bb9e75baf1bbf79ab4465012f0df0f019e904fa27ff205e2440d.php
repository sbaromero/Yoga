<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_f363393372ae4d9ecc6d9da7fcfb99cd5fb67d064d1fd8559a51ffadb6d9c67a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f50f2662ee30f76eeac5d94efbe2791347112762a09eda93e368e95856985eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f50f2662ee30f76eeac5d94efbe2791347112762a09eda93e368e95856985eb->enter($__internal_5f50f2662ee30f76eeac5d94efbe2791347112762a09eda93e368e95856985eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_5f50f2662ee30f76eeac5d94efbe2791347112762a09eda93e368e95856985eb->leave($__internal_5f50f2662ee30f76eeac5d94efbe2791347112762a09eda93e368e95856985eb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/home/ubuntu/workspace/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
