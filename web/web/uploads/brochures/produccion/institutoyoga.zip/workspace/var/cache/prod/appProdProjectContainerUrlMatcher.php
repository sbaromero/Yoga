<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/usuario')) {
            // cya_usuario_index
            if ($pathinfo === '/usuario/index') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::indexAction',  '_route' => 'cya_usuario_index',);
            }

            // cya_usuario_add
            if ($pathinfo === '/usuario/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::addAction',  '_route' => 'cya_usuario_add',);
            }

            // cya_usuario_rapido
            if ($pathinfo === '/usuario/rapido') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::usuariorapidoAction',  '_route' => 'cya_usuario_rapido',);
            }

            // cya_usuario_create
            if ($pathinfo === '/usuario/create') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_cya_usuario_create;
                }

                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::createAction',  '_route' => 'cya_usuario_create',);
            }
            not_cya_usuario_create:

            if (0 === strpos($pathinfo, '/usuario/edit')) {
                // cya_usuario_edit
                if (preg_match('#^/usuario/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_usuario_edit')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::editAction',));
                }

                // cya_usuario_editpublic
                if (rtrim($pathinfo, '/') === '/usuario/editpublic') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'cya_usuario_editpublic');
                    }

                    return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::editpublicAction',  '_route' => 'cya_usuario_editpublic',);
                }

            }

            // cya_usuario_update
            if (0 === strpos($pathinfo, '/usuario/update') && preg_match('#^/usuario/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                    $allow = array_merge($allow, array('POST', 'PUT'));
                    goto not_cya_usuario_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_usuario_update')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::updateAction',));
            }
            not_cya_usuario_update:

            // cya_usuario_view
            if (0 === strpos($pathinfo, '/usuario/view') && preg_match('#^/usuario/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_usuario_view')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::viewAction',));
            }

            // cya_usuario_inicio
            if ($pathinfo === '/usuario/inicio') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::inicioAction',  '_route' => 'cya_usuario_inicio',);
            }

        }

        if (0 === strpos($pathinfo, '/rubro')) {
            // cya_rubro_index
            if ($pathinfo === '/rubro/index') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\RubroController::indexAction',  '_route' => 'cya_rubro_index',);
            }

            // cya_rubro_add
            if ($pathinfo === '/rubro/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\RubroController::addAction',  '_route' => 'cya_rubro_add',);
            }

            // cya_rubro_create
            if ($pathinfo === '/rubro/create') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_cya_rubro_create;
                }

                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\RubroController::createAction',  '_route' => 'cya_rubro_create',);
            }
            not_cya_rubro_create:

            // cya_rubro_edit
            if (0 === strpos($pathinfo, '/rubro/edit') && preg_match('#^/rubro/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_rubro_edit')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\RubroController::editAction',));
            }

            // cya_rubro_update
            if (0 === strpos($pathinfo, '/rubro/update') && preg_match('#^/rubro/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                    $allow = array_merge($allow, array('POST', 'PUT'));
                    goto not_cya_rubro_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_rubro_update')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\RubroController::updateAction',));
            }
            not_cya_rubro_update:

            // cya_rubro_view
            if (0 === strpos($pathinfo, '/rubro/view') && preg_match('#^/rubro/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_rubro_view')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\RubroController::viewAction',));
            }

        }

        if (0 === strpos($pathinfo, '/movimiento')) {
            // cya_movimiento_index
            if ($pathinfo === '/movimiento/index') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\MovimientoController::indexAction',  '_route' => 'cya_movimiento_index',);
            }

            // cya_movimiento_add
            if ($pathinfo === '/movimiento/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\MovimientoController::addAction',  '_route' => 'cya_movimiento_add',);
            }

            // cya_movimiento_create
            if ($pathinfo === '/movimiento/create') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_cya_movimiento_create;
                }

                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\MovimientoController::createAction',  '_route' => 'cya_movimiento_create',);
            }
            not_cya_movimiento_create:

            // cya_movimiento_details
            if (0 === strpos($pathinfo, '/movimiento/details') && preg_match('#^/movimiento/details/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_movimiento_details')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\MovimientoController::detailsAction',));
            }

            // cya_movimiento_update
            if (0 === strpos($pathinfo, '/movimiento/update') && preg_match('#^/movimiento/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                    $allow = array_merge($allow, array('POST', 'PUT'));
                    goto not_cya_movimiento_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_movimiento_update')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\MovimientoController::updateAction',));
            }
            not_cya_movimiento_update:

            // cya_movimiento_view
            if (0 === strpos($pathinfo, '/movimiento/view') && preg_match('#^/movimiento/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_movimiento_view')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\MovimientoController::viewAction',));
            }

            // cya_movimiento_delete
            if (0 === strpos($pathinfo, '/movimiento/delete') && preg_match('#^/movimiento/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_movimiento_delete')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\MovimientoController::deleteAction',));
            }

        }

        if (0 === strpos($pathinfo, '/tipoproducto')) {
            // cya_tipoproducto_index
            if ($pathinfo === '/tipoproducto/index') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipoproductoController::indexAction',  '_route' => 'cya_tipoproducto_index',);
            }

            // cya_tipoproducto_add
            if ($pathinfo === '/tipoproducto/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipoproductoController::addAction',  '_route' => 'cya_tipoproducto_add',);
            }

            // cya_tipoproducto_create
            if ($pathinfo === '/tipoproducto/create') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_cya_tipoproducto_create;
                }

                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipoproductoController::createAction',  '_route' => 'cya_tipoproducto_create',);
            }
            not_cya_tipoproducto_create:

            // cya_tipoproducto_edit
            if (0 === strpos($pathinfo, '/tipoproducto/edit') && preg_match('#^/tipoproducto/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_tipoproducto_edit')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipoproductoController::editAction',));
            }

            // cya_tipoproducto_update
            if (0 === strpos($pathinfo, '/tipoproducto/update') && preg_match('#^/tipoproducto/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                    $allow = array_merge($allow, array('POST', 'PUT'));
                    goto not_cya_tipoproducto_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_tipoproducto_update')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipoproductoController::updateAction',));
            }
            not_cya_tipoproducto_update:

            // cya_tipoproducto_view
            if (0 === strpos($pathinfo, '/tipoproducto/view') && preg_match('#^/tipoproducto/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_tipoproducto_view')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipoproductoController::viewAction',));
            }

        }

        if (0 === strpos($pathinfo, '/locker')) {
            // cya_locker_index
            if ($pathinfo === '/locker/index') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\LockerController::indexAction',  '_route' => 'cya_locker_index',);
            }

            // cya_locker_add
            if ($pathinfo === '/locker/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\LockerController::addAction',  '_route' => 'cya_locker_add',);
            }

            // cya_locker_create
            if ($pathinfo === '/locker/create') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_cya_locker_create;
                }

                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\LockerController::createAction',  '_route' => 'cya_locker_create',);
            }
            not_cya_locker_create:

            // cya_locker_edit
            if (0 === strpos($pathinfo, '/locker/edit') && preg_match('#^/locker/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_locker_edit')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\LockerController::editAction',));
            }

            // cya_locker_update
            if (0 === strpos($pathinfo, '/locker/update') && preg_match('#^/locker/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                    $allow = array_merge($allow, array('POST', 'PUT'));
                    goto not_cya_locker_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_locker_update')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\LockerController::updateAction',));
            }
            not_cya_locker_update:

            // cya_locker_view
            if (0 === strpos($pathinfo, '/locker/view') && preg_match('#^/locker/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_locker_view')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\LockerController::viewAction',));
            }

            // cya_locker_delete
            if (0 === strpos($pathinfo, '/locker/delete') && preg_match('#^/locker/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_locker_delete')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\LockerController::deleteAction',));
            }

        }

        if (0 === strpos($pathinfo, '/producto')) {
            // cya_producto_index
            if ($pathinfo === '/producto/index') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\ProductoController::indexAction',  '_route' => 'cya_producto_index',);
            }

            // cya_producto_add
            if ($pathinfo === '/producto/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\ProductoController::addAction',  '_route' => 'cya_producto_add',);
            }

            // cya_producto_create
            if ($pathinfo === '/producto/create') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_cya_producto_create;
                }

                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\ProductoController::createAction',  '_route' => 'cya_producto_create',);
            }
            not_cya_producto_create:

            // cya_producto_edit
            if (0 === strpos($pathinfo, '/producto/edit') && preg_match('#^/producto/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_producto_edit')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\ProductoController::editAction',));
            }

            // cya_producto_update
            if (0 === strpos($pathinfo, '/producto/update') && preg_match('#^/producto/update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                    $allow = array_merge($allow, array('POST', 'PUT'));
                    goto not_cya_producto_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_producto_update')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\ProductoController::updateAction',));
            }
            not_cya_producto_update:

            // cya_producto_view
            if (0 === strpos($pathinfo, '/producto/view') && preg_match('#^/producto/view/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_producto_view')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\ProductoController::viewAction',));
            }

            // cya_producto_delete
            if (0 === strpos($pathinfo, '/producto/delete') && preg_match('#^/producto/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_producto_delete')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\ProductoController::deleteAction',));
            }

        }

        if (0 === strpos($pathinfo, '/alumnocc')) {
            if (0 === strpos($pathinfo, '/alumnocc/index')) {
                // cya_alumnocc_index
                if ($pathinfo === '/alumnocc/index') {
                    return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::indexAction',  '_route' => 'cya_alumnocc_index',);
                }

                // cya_alumnocc_indexpublic
                if ($pathinfo === '/alumnocc/indexpublic') {
                    return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::indexpublicAction',  '_route' => 'cya_alumnocc_indexpublic',);
                }

            }

            // cya_alumnocc_add
            if ($pathinfo === '/alumnocc/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::addAction',  '_route' => 'cya_alumnocc_add',);
            }

            // cya_alumnocc_pagodiario
            if ($pathinfo === '/alumnocc/pagodiarioAction') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::pagodiarioAction',  '_route' => 'cya_alumnocc_pagodiario',);
            }

            // cya_alumnocc_create
            if ($pathinfo === '/alumnocc/create') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_cya_alumnocc_create;
                }

                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::createAction',  '_route' => 'cya_alumnocc_create',);
            }
            not_cya_alumnocc_create:

            if (0 === strpos($pathinfo, '/alumnocc/de')) {
                if (0 === strpos($pathinfo, '/alumnocc/deta')) {
                    // cya_alumnocc_detallepago
                    if (0 === strpos($pathinfo, '/alumnocc/detallepago') && preg_match('#^/alumnocc/detallepago/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_alumnocc_detallepago')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::detallepagoAction',));
                    }

                    // cya_alumnocc_details
                    if (0 === strpos($pathinfo, '/alumnocc/details') && preg_match('#^/alumnocc/details/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_alumnocc_details')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::detailsAction',));
                    }

                }

                // cya_alumnocc_delete
                if (0 === strpos($pathinfo, '/alumnocc/delete') && preg_match('#^/alumnocc/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_alumnocc_delete')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::deleteAction',));
                }

                // cya_alumnocc_detallepagopublic
                if (0 === strpos($pathinfo, '/alumnocc/detallepagopublic') && preg_match('#^/alumnocc/detallepagopublic/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_alumnocc_detallepagopublic')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::detallepagopublicAction',));
                }

            }

            // cya_alumnocc_pago
            if (0 === strpos($pathinfo, '/alumnocc/pago') && preg_match('#^/alumnocc/pago/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_alumnocc_pago')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\AlumnoccController::pagoAction',));
            }

        }

        if (0 === strpos($pathinfo, '/tipocuota')) {
            // cya_tipocuota_index
            if ($pathinfo === '/tipocuota/index') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipocuotaController::indexAction',  '_route' => 'cya_tipocuota_index',);
            }

            // cya_tipocuota_add
            if ($pathinfo === '/tipocuota/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipocuotaController::addAction',  '_route' => 'cya_tipocuota_add',);
            }

            // cya_tipocuota_edit
            if (0 === strpos($pathinfo, '/tipocuota/edit') && preg_match('#^/tipocuota/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_tipocuota_edit')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\TipocuotaController::editAction',));
            }

        }

        // cya_maestroventa_add
        if ($pathinfo === '/maestroventa/add') {
            return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\MaestroventaController::addAction',  '_route' => 'cya_maestroventa_add',);
        }

        if (0 === strpos($pathinfo, '/detalleventa')) {
            // cya_detalleventa_add
            if ($pathinfo === '/detalleventa/add') {
                return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\DetalleventaController::addAction',  '_route' => 'cya_detalleventa_add',);
            }

            // cya_detalleventa_delete
            if (0 === strpos($pathinfo, '/detalleventa/delete') && preg_match('#^/detalleventa/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cya_detalleventa_delete')), array (  '_controller' => 'CYA\\YogaBundle\\Controller\\DetalleventaController::deleteAction',));
            }

        }

        // cya_yoga_home
        if ($pathinfo === '/home') {
            return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\UsuarioController::homeAction',  '_route' => 'cya_yoga_home',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // cya_yoga_login
                if ($pathinfo === '/login') {
                    return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\SecurityController::loginAction',  '_route' => 'cya_yoga_login',);
                }

                // cya_yoga_login_check
                if ($pathinfo === '/login_check') {
                    return array (  '_controller' => 'CYA\\YogaBundle\\Controller\\SecurityController::loginCheckAction',  '_route' => 'cya_yoga_login_check',);
                }

            }

            // cya_yoga_logout
            if ($pathinfo === '/logout') {
                return array('_route' => 'cya_yoga_logout');
            }

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
