<?php

/* CYAYogaBundle:Maestroventa:edit.html.twig */
class __TwigTemplate_3cf96f5c39d5eb53f96f6639a0e296e9f08e4c19c22e82dc3ccb3deae7824218 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Maestroventa:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e13235a2293f5c9b9dc6c247caa953dd8f246274b56c14442f91992ce5a0be8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e13235a2293f5c9b9dc6c247caa953dd8f246274b56c14442f91992ce5a0be8->enter($__internal_1e13235a2293f5c9b9dc6c247caa953dd8f246274b56c14442f91992ce5a0be8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Maestroventa:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1e13235a2293f5c9b9dc6c247caa953dd8f246274b56c14442f91992ce5a0be8->leave($__internal_1e13235a2293f5c9b9dc6c247caa953dd8f246274b56c14442f91992ce5a0be8_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_f8090ab613dca91a1e43cd116f3d0f53a58e6f993a5b86e6c28e8116e29e5245 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8090ab613dca91a1e43cd116f3d0f53a58e6f993a5b86e6c28e8116e29e5245->enter($__internal_f8090ab613dca91a1e43cd116f3d0f53a58e6f993a5b86e6c28e8116e29e5245_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Maestroventa:edit.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Tipoproducto:messages/success.html.twig");
        echo "
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar Producto</h2>
\t\t\t\t</div>
\t\t\t\t";
        // line 12
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("role" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t<div class=\"form-group\">
 
\t                         ";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'widget', array("attr" => array("class" => "form-control inputswitch", "placeholder" => "Activo")));
        echo "
\t                         <span class=\"text-danger\"> ";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'errors');
        echo " </span>
                    \t</div> 

\t\t\t\t\t    <div class=\"form-group\">
\t                         ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "descripcion", array()), 'label');
        echo "
\t                         ";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "descripcion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripcion")));
        echo "
\t                         <span class=\"text-danger\"> ";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "descripcion", array()), 'errors');
        echo " </span>
                    \t</div>
                       
                       \t<div class=\"form-group\">
\t                         ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "costo", array()), 'label');
        echo "
\t                         ";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "costo", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Precio de Costo")));
        echo "
\t                         <span class=\"text-danger\"> ";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "costo", array()), 'errors');
        echo " </span>
                    \t</div>   

\t\t                   <div class=\"form-group\">
\t                         ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "preciolista", array()), 'label');
        echo "
\t                         ";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "preciolista", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Precio de Lista")));
        echo "
\t                         <span class=\"text-danger\"> ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "preciolista", array()), 'errors');
        echo " </span>
                    \t</div>   
\t\t               
\t\t               \t<div class=\"form-group\">
\t                         ";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "stock", array()), 'label');
        echo "
\t                         ";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "stock", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Stock")));
        echo "
\t                         <span class=\"text-danger\"> ";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "stock", array()), 'errors');
        echo " </span>
                    \t</div>   
\t\t               
\t\t               \t\t<div class=\"form-group\">
\t                         ";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "proveedor", array()), 'label');
        echo "
\t                         ";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "proveedor", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Proveedor")));
        echo "
\t                         <span class=\"text-danger\"> ";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "proveedor", array()), 'errors');
        echo " </span>
                    \t</div> 
\t\t               
\t\t               \t <div class=\"form-group\">
\t                       <b> Tipo de Producto</b>
\t                         ";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipoproducto", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Tipo Producto")));
        echo "
\t                         <span class=\"text-danger\"> ";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipoproducto", array()), 'errors');
        echo " </span>
                    \t</div> 
\t\t               
\t\t               \t
\t\t               
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Modificar Producto", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 67
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
        
        $__internal_f8090ab613dca91a1e43cd116f3d0f53a58e6f993a5b86e6c28e8116e29e5245->leave($__internal_f8090ab613dca91a1e43cd116f3d0f53a58e6f993a5b86e6c28e8116e29e5245_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Maestroventa:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 67,  169 => 63,  158 => 55,  154 => 54,  146 => 49,  142 => 48,  138 => 47,  131 => 43,  127 => 42,  123 => 41,  116 => 37,  112 => 36,  108 => 35,  101 => 31,  97 => 30,  93 => 29,  86 => 25,  82 => 24,  78 => 23,  71 => 19,  67 => 18,  59 => 13,  55 => 12,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    {{ include('CYAYogaBundle:Tipoproducto:messages/success.html.twig') }}
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Editar Producto</h2>
\t\t\t\t</div>
\t\t\t\t{{ form_start(form, {'attr': { 'role' : 'form'}}) }}
\t\t\t\t<h4 class=\"text-danger\">{{ form_errors(form) }}</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t<div class=\"form-group\">
 
\t                         {{ form_widget(form.isActive, { 'attr' : { 'class' : 'form-control inputswitch', 'placeholder' : 'Activo'} }) }}
\t                         <span class=\"text-danger\"> {{ form_errors(form.isActive) }} </span>
                    \t</div> 

\t\t\t\t\t    <div class=\"form-group\">
\t                         {{ form_label(form.descripcion) }}
\t                         {{ form_widget(form.descripcion, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Descripcion'} }) }}
\t                         <span class=\"text-danger\"> {{ form_errors(form.descripcion) }} </span>
                    \t</div>
                       
                       \t<div class=\"form-group\">
\t                         {{ form_label(form.costo) }}
\t                         {{ form_widget(form.costo, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Precio de Costo'} }) }}
\t                         <span class=\"text-danger\"> {{ form_errors(form.costo) }} </span>
                    \t</div>   

\t\t                   <div class=\"form-group\">
\t                         {{ form_label(form.preciolista) }}
\t                         {{ form_widget(form.preciolista, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Precio de Lista'} }) }}
\t                         <span class=\"text-danger\"> {{ form_errors(form.preciolista) }} </span>
                    \t</div>   
\t\t               
\t\t               \t<div class=\"form-group\">
\t                         {{ form_label(form.stock) }}
\t                         {{ form_widget(form.stock, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Stock'} }) }}
\t                         <span class=\"text-danger\"> {{ form_errors(form.stock) }} </span>
                    \t</div>   
\t\t               
\t\t               \t\t<div class=\"form-group\">
\t                         {{ form_label(form.proveedor) }}
\t                         {{ form_widget(form.proveedor, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Proveedor'} }) }}
\t                         <span class=\"text-danger\"> {{ form_errors(form.proveedor) }} </span>
                    \t</div> 
\t\t               
\t\t               \t <div class=\"form-group\">
\t                       <b> Tipo de Producto</b>
\t                         {{ form_widget(form.tipoproducto, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Tipo Producto'} }) }}
\t                         <span class=\"text-danger\"> {{ form_errors(form.tipoproducto) }} </span>
                    \t</div> 
\t\t               
\t\t               \t
\t\t               
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        {{ form_widget(form.save, {'label' : 'Modificar Producto', 'attr': {'class': 'btn btn-success'}}) }}
\t\t\t\t    </p>
                 
                   
\t\t\t\t{{ form_end(form) }}
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}", "CYAYogaBundle:Maestroventa:edit.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Maestroventa/edit.html.twig");
    }
}
