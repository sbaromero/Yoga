<?php

/* CYAYogaBundle:Alumnocc:pagodiario.html.twig */
class __TwigTemplate_05081950d860e32b16e8e53e5fda6121b91ceb0991420127440ecdca76bd2fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Alumnocc:pagodiario.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a208378cb91566f2e6a520b7a5b4e7e7f86bee7d6897da2b7853e2d59a7a231a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a208378cb91566f2e6a520b7a5b4e7e7f86bee7d6897da2b7853e2d59a7a231a->enter($__internal_a208378cb91566f2e6a520b7a5b4e7e7f86bee7d6897da2b7853e2d59a7a231a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Alumnocc:pagodiario.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a208378cb91566f2e6a520b7a5b4e7e7f86bee7d6897da2b7853e2d59a7a231a->leave($__internal_a208378cb91566f2e6a520b7a5b4e7e7f86bee7d6897da2b7853e2d59a7a231a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0bf338eb4039df420749a24df15ec82bb02a12539da4db62800288c0a0e51b75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0bf338eb4039df420749a24df15ec82bb02a12539da4db62800288c0a0e51b75->enter($__internal_0bf338eb4039df420749a24df15ec82bb02a12539da4db62800288c0a0e51b75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Alumnocc:pagodiario.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/success.html.twig");
        echo "
     <div class=\"container-fluid cuenta\">
        <div class=\"container cuenta-icon\">
            <div class=\"row\">
            \t<div class=\"col-sm-12\">
\t\t\t\t\t<h2>Pago diario</h2>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
            
            \t
\t<div class=\"container grey-input\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-sm-5\">
\t\t\t\t
\t\t\t\t";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("rol" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "</h4>
                     
                         
                         <div class=\"form-group\">
\t\t\t\t\t        Alumno
\t\t\t\t\t        ";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "usuario", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Alumno")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "usuario", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>  
\t\t\t\t\t    
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Pago
\t\t\t\t\t        ";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pagado", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Pago")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pagado", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div> 
\t\t\t\t\t    
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Realizar pago", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 42
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
        
        $__internal_0bf338eb4039df420749a24df15ec82bb02a12539da4db62800288c0a0e51b75->leave($__internal_0bf338eb4039df420749a24df15ec82bb02a12539da4db62800288c0a0e51b75_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Alumnocc:pagodiario.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 42,  99 => 38,  92 => 34,  88 => 33,  80 => 28,  76 => 27,  68 => 22,  64 => 21,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    {{ include('CYAYogaBundle:Alumnocc:messages/success.html.twig') }}
     <div class=\"container-fluid cuenta\">
        <div class=\"container cuenta-icon\">
            <div class=\"row\">
            \t<div class=\"col-sm-12\">
\t\t\t\t\t<h2>Pago diario</h2>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
            
            \t
\t<div class=\"container grey-input\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-sm-5\">
\t\t\t\t
\t\t\t\t{{ form_start(form, {'attr': { 'rol' : 'form'}}) }}
\t\t\t\t<h4 class=\"text-danger\">{{ form_errors(form) }}</h4>
                     
                         
                         <div class=\"form-group\">
\t\t\t\t\t        Alumno
\t\t\t\t\t        {{ form_widget(form.usuario, {'attr': {'class': 'form-control', 'placeholder' : 'Alumno'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.usuario) }}</span>
\t\t\t\t\t    </div>  
\t\t\t\t\t    
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Pago
\t\t\t\t\t        {{ form_widget(form.pagado, {'attr': {'class': 'form-control', 'placeholder' : 'Pago'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.pagado) }}</span>
\t\t\t\t\t    </div> 
\t\t\t\t\t    
\t\t\t\t    <p>
\t\t\t\t        {{ form_widget(form.save, {'label' : 'Realizar pago', 'attr': {'class': 'btn btn-success'}}) }}
\t\t\t\t    </p>
                 
                   
\t\t\t\t{{ form_end(form) }}
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}", "CYAYogaBundle:Alumnocc:pagodiario.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Alumnocc/pagodiario.html.twig");
    }
}
