<?php

/* CYAYogaBundle:Rubro:add.html.twig */
class __TwigTemplate_e500a85f6806ec17570128fe99f3d2107c055c183dd11b05290b1317795a5a35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Rubro:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec038b41516c7e2536e407dcf7edeb266dd18ab06a2d2d8f357c1315ef96b0c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec038b41516c7e2536e407dcf7edeb266dd18ab06a2d2d8f357c1315ef96b0c9->enter($__internal_ec038b41516c7e2536e407dcf7edeb266dd18ab06a2d2d8f357c1315ef96b0c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Rubro:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ec038b41516c7e2536e407dcf7edeb266dd18ab06a2d2d8f357c1315ef96b0c9->leave($__internal_ec038b41516c7e2536e407dcf7edeb266dd18ab06a2d2d8f357c1315ef96b0c9_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_34b45f5f388af9e451e52f18b657f8b33bf9cb960dd726b2748f89d27ee7f459 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34b45f5f388af9e451e52f18b657f8b33bf9cb960dd726b2748f89d27ee7f459->enter($__internal_34b45f5f388af9e451e52f18b657f8b33bf9cb960dd726b2748f89d27ee7f459_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Rubro:add.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid caja\">
        <div class=\"container caja-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo Rubro de Caja</h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_rubro_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar a rubros
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>
    
    ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
           
     <div class=\"container grey-input\">
        <div class=\"row\">
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         ";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'label');
        echo "
                         ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'errors');
        echo " </span>
                    </div>
            </div>

             <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipo", array()), 'label');
        echo "
                     ";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipo", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipo", array()), 'errors');
        echo " </span>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
               <div class=\"checkbox\">
                 <label>
                     ";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'widget');
        echo " Activo
                     <span class=\"text-danger\"> ";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'errors');
        echo " </span>
                 </label>
             </div>
            
            
            <div class=\"col-sm-12\">
                
                ";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Agregar Rubro", "attr" => array("class" => "btn alumnos-btn")));
        echo "
                 
                
            </div>
            ";
        // line 56
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
         </div>
     </div>
";
        
        $__internal_34b45f5f388af9e451e52f18b657f8b33bf9cb960dd726b2748f89d27ee7f459->leave($__internal_34b45f5f388af9e451e52f18b657f8b33bf9cb960dd726b2748f89d27ee7f459_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Rubro:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 56,  122 => 52,  112 => 45,  108 => 44,  98 => 37,  94 => 36,  90 => 35,  81 => 29,  77 => 28,  73 => 27,  64 => 21,  50 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    <div class=\"container-fluid caja\">
        <div class=\"container caja-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo Rubro de Caja</h2>
                    <a href=\"{{ path('cya_rubro_index') }}\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar a rubros
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>
    
    {{ form_start(form, {'attr' : {'role' : 'form'}, 'action':'', 'method':'POST' }) }}
           
     <div class=\"container grey-input\">
        <div class=\"row\">
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         {{ form_label(form.nombre) }}
                         {{ form_widget(form.nombre, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Nombre'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.nombre) }} </span>
                    </div>
            </div>

             <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     {{ form_label(form.tipo) }}
                     {{ form_widget(form.tipo, { 'attr' : { 'class' : 'form-control'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.tipo) }} </span>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
               <div class=\"checkbox\">
                 <label>
                     {{ form_widget(form.isActive) }} Activo
                     <span class=\"text-danger\"> {{ form_errors(form.isActive) }} </span>
                 </label>
             </div>
            
            
            <div class=\"col-sm-12\">
                
                {{ form_widget(form.save, {'label' : 'Agregar Rubro', 'attr': {'class': 'btn alumnos-btn'} }) }}
                 
                
            </div>
            {{ form_end(form) }}
         </div>
     </div>
{% endblock %}

", "CYAYogaBundle:Rubro:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Rubro/add.html.twig");
    }
}
