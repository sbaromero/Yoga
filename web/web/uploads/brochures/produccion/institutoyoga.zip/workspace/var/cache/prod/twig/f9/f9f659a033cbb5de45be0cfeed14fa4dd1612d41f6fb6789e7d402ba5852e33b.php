<?php

/* CYAYogaBundle:Usuario:view.html.twig */
class __TwigTemplate_9a537db654c7dbc270a9de429eb139c8fc85ba48a721e1c60883963699681ce5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:view.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "\t";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
\t
\t    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                   <h2>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "nombre", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "apellido", array()), "html", null, true);
        echo " (edad: ";
        echo twig_escape_filter($this->env, (isset($context["edad"]) ? $context["edad"] : null), "html", null, true);
        echo "    años)</h2>
                    <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <i class=\"icon ion-android-arrow-dropleft-circle\"></i>
        \t\t\t            regresar al listado de usuarios
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                
            </div>
        </div>
    </div>
\t
\t<div class=\"container well\">
\t    <div class=\"col-md-9\">
\t  \t    <br>
\t        <dl>
\t            
\t            <dt>Usuario</dt></dt>
\t            <dd>
\t                ";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "nombreusuario", array()), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>

\t            <dt>Nombre</dt>
\t            <dd>
\t                ";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "nombre", array()), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>

\t            <dt>Apellido</dt>
\t            <dd>
\t                ";
        // line 44
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "apellido", array()), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>

               <dt>DNI</dt>
\t            <dd>
\t                ";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "dni", array()), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>
\t            
\t            <dt>Dirección</dt>
\t            <dd>
\t                ";
        // line 58
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "direccion", array()), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>
\t            <dt>Ciudad</dt>
\t            <dd>
\t                ";
        // line 64
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "ciudad", array()), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>
\t            

\t            <dt>Teléfono</dt>
\t            <dd>
\t                ";
        // line 72
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "telefono", array()), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>

\t            <br>
\t            <dt>Mail</dt>
\t            <dd>
\t                ";
        // line 80
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "mail", array()), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t             <br>
\t            
\t            <dt>Fecha Nacimiento</dt>
\t            <dd>
\t                ";
        // line 87
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "fechanacimiento", array()), "d-m-Y"), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>
\t            <dt>Fecha Ingreso</dt>
\t            
\t            <dd>
\t                ";
        // line 94
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "fechaingreso", array()), "d-m-Y"), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>
\t            <dt>Fecha Re-Ingreso</dt>
\t            <dd>
\t                ";
        // line 100
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "fechareingreso", array()), "d-m-Y"), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            
\t            <br>
\t            <dt>Tipo de Alumno</dt>
\t            <dd>
\t                ";
        // line 107
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "tipocuota", array()), "nombre", array()), "html", null, true);
        echo "

\t                &nbsp;
\t            </dd>
\t            <br>
\t            <dt>Rol</dt>
\t            <dd>
                \t";
        // line 114
        if (($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "rol", array()) == "ROLE_ADMIN")) {
            // line 115
            echo "\t\t\t\t\t\tAdministrador
\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 116
(isset($context["usuario"]) ? $context["usuario"] : null), "rol", array()) == "ROLE_USER")) {
            // line 117
            echo "\t\t\t\t\t\tUsuario
\t\t\t    \t";
        } elseif (($this->getAttribute(        // line 118
(isset($context["usuario"]) ? $context["usuario"] : null), "rol", array()) == "ROLE_SUPER")) {
            // line 119
            echo "\t\t\t\t    \tSuperadmin
                \t";
        }
        // line 121
        echo "\t                &nbsp;
\t            </dd>
\t            <br>

\t            <dt>Estado del Usuario</dt>
\t            <dd>
                \t";
        // line 127
        if (($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "isActive", array()) == 1)) {
            // line 128
            echo "\t\t\t\t\t\t<span class=\"text-success\">Usuario Activo</span>
\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 129
(isset($context["usuario"]) ? $context["usuario"] : null), "isActive", array()) == 0)) {
            // line 130
            echo "\t\t\t\t\t\t<span class=\"text-warning\">Usuario Inactivo</span>
                \t";
        }
        // line 132
        echo "\t                &nbsp;
\t            </dd>
\t            <br>
               
\t            <dt>Creado el</dt>
\t            <dd>
\t                ";
        // line 138
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "createdAt", array()), "d-m-Y"), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>

\t            <dt>Actualizado el</dt>
\t            <dd>
\t                ";
        // line 145
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "updatedAt", array()), "d-m-Y"), "html", null, true);
        echo "
\t                &nbsp;
\t            </dd>
\t            <br>
\t         
\t       
\t        </dl>
\t    </div>
\t    <div class=\"col-md-3\">
\t    \t<h3>Acciones:</h3>
\t\t\t<p>
\t\t    \t<a href=\"";
        // line 156
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_edit", array("id" => $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-primary btn-lg btn-block\">
\t\t    \t\t<span class=\"glyphicon glyphicon-edit\"></span>
\t\t        \t Editar Usuario
\t\t\t\t </a>
\t\t\t</p>
\t    </div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  258 => 156,  244 => 145,  234 => 138,  226 => 132,  222 => 130,  220 => 129,  217 => 128,  215 => 127,  207 => 121,  203 => 119,  201 => 118,  198 => 117,  196 => 116,  193 => 115,  191 => 114,  181 => 107,  171 => 100,  162 => 94,  152 => 87,  142 => 80,  131 => 72,  120 => 64,  111 => 58,  101 => 51,  91 => 44,  81 => 37,  71 => 30,  49 => 11,  41 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Usuario:view.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/view.html.twig");
    }
}
