<?php

/* CYAYogaBundle:Alumnocc:pago.html.twig */
class __TwigTemplate_dabab6980f7cae4b5068ba1be81e3831f34f10b164905a90aba399355422c5f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Alumnocc:pago.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c5c725d72bc721219bcf89609383653f5458a2100007219fc2f9d135a6cf418 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c5c725d72bc721219bcf89609383653f5458a2100007219fc2f9d135a6cf418->enter($__internal_3c5c725d72bc721219bcf89609383653f5458a2100007219fc2f9d135a6cf418_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Alumnocc:pago.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3c5c725d72bc721219bcf89609383653f5458a2100007219fc2f9d135a6cf418->leave($__internal_3c5c725d72bc721219bcf89609383653f5458a2100007219fc2f9d135a6cf418_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_eee24e8e7940433a381dc588348b3f53f9d463dbf13c342900b1b7931b5cf6be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eee24e8e7940433a381dc588348b3f53f9d463dbf13c342900b1b7931b5cf6be->enter($__internal_eee24e8e7940433a381dc588348b3f53f9d463dbf13c342900b1b7931b5cf6be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Alumnocc:pago.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/success.html.twig");
        echo "
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Pago de cuota</h2>
\t\t\t\t\t<h3>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["nombrecompleto"]) ? $context["nombrecompleto"] : $this->getContext($context, "nombrecompleto")), "html", null, true);
        echo "</h3>
\t\t\t\t\t<h3> Vencimiento: ";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["vencimiento"]) ? $context["vencimiento"] : $this->getContext($context, "vencimiento")), "html", null, true);
        echo "</h3>
\t\t\t\t\t<h3> Saldo: \$";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : $this->getContext($context, "saldo")), "html", null, true);
        echo "</h3>
\t\t\t\t
\t\t\t\t</div>
\t\t\t\t";
        // line 16
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("rol" => "form")));
        echo "
\t\t\t\t<h4 class=\"text-danger\">";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Monto cuota
\t\t\t\t\t        ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "deuda", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Monto cuota")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "deuda", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>
                        <div class=\"form-group\">
\t\t\t\t\t        Pago
\t\t\t\t\t        ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pagado", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Pago")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pagado", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div> 
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Bonificacion
\t\t\t\t\t        ";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "bonificacion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Bonificacion")));
        echo "
\t\t\t\t\t        <span class=\"text-danger\">";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "bonificacion", array()), 'errors');
        echo "</span>
\t\t\t\t\t    </div>  
\t\t\t\t\t\t
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Realizar pago", "attr" => array("class" => "btn btn-success")));
        echo "
\t\t\t\t    </p>
                 
                   
\t\t\t\t";
        // line 44
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
";
        
        $__internal_eee24e8e7940433a381dc588348b3f53f9d463dbf13c342900b1b7931b5cf6be->leave($__internal_eee24e8e7940433a381dc588348b3f53f9d463dbf13c342900b1b7931b5cf6be_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Alumnocc:pago.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 44,  116 => 40,  107 => 34,  103 => 33,  96 => 29,  92 => 28,  85 => 24,  81 => 23,  72 => 17,  68 => 16,  62 => 13,  58 => 12,  54 => 11,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    {{ include('CYAYogaBundle:Alumnocc:messages/success.html.twig') }}
\t<div class=\"main container\">
\t\t<div class=\"row well\">
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t<h2>Pago de cuota</h2>
\t\t\t\t\t<h3>{{ nombrecompleto }}</h3>
\t\t\t\t\t<h3> Vencimiento: {{ vencimiento }}</h3>
\t\t\t\t\t<h3> Saldo: \${{ saldo }}</h3>
\t\t\t\t
\t\t\t\t</div>
\t\t\t\t{{ form_start(form, {'attr': { 'rol' : 'form'}}) }}
\t\t\t\t<h4 class=\"text-danger\">{{ form_errors(form) }}</h4>
                     
\t\t\t\t\t<fieldset>
\t\t\t\t\t\t
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Monto cuota
\t\t\t\t\t        {{ form_widget(form.deuda, {'attr': {'class': 'form-control', 'placeholder' : 'Monto cuota'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.deuda) }}</span>
\t\t\t\t\t    </div>
                        <div class=\"form-group\">
\t\t\t\t\t        Pago
\t\t\t\t\t        {{ form_widget(form.pagado, {'attr': {'class': 'form-control', 'placeholder' : 'Pago'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.pagado) }}</span>
\t\t\t\t\t    </div> 
\t\t\t\t\t    <div class=\"form-group\">
\t\t\t\t\t        Bonificacion
\t\t\t\t\t        {{ form_widget(form.bonificacion, {'attr': {'class': 'form-control', 'placeholder' : 'Bonificacion'}}) }}
\t\t\t\t\t        <span class=\"text-danger\">{{ form_errors(form.bonificacion) }}</span>
\t\t\t\t\t    </div>  
\t\t\t\t\t\t
\t\t\t\t \t</fieldset>
                     
\t\t\t\t    <p>
\t\t\t\t        {{ form_widget(form.save, {'label' : 'Realizar pago', 'attr': {'class': 'btn btn-success'}}) }}
\t\t\t\t    </p>
                 
                   
\t\t\t\t{{ form_end(form) }}
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}", "CYAYogaBundle:Alumnocc:pago.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Alumnocc/pago.html.twig");
    }
}
