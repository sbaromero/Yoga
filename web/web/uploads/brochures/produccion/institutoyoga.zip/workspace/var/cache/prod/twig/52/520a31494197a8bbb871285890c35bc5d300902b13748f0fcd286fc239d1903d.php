<?php

/* CYAYogaBundle:Detalleventa:index.html.twig */
class __TwigTemplate_fffa8359957b2b24c3adff1f0239b18a4484813158f49fc21089d2f377fc42c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Detalleventa:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Movimiento:messages/success.html.twig");
        echo "
<div class=\"container-fluid caja\">
        <div class=\"container caja-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Movimientos</h2>
                    <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_add");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
        \t\t\t            Nuevo movimiento
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t
        \t\t\t\t<div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"dc\"name=\"dc\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "dc"), "method"), "html", null, true);
        echo "\">
                            <option value=\"\" selected disabled>Débito/Crédito</option>
                            <option value=\"\">Todos</option>
                            <option value=\"D\">Débito</option>
                            <option value=\"C\">Crédito</option>
                          </select>
                        </div>
                        
                        <div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"tipo\"name=\"tipo\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "tipo"), "method"), "html", null, true);
        echo "\">
                            <option value=\"\" selected disabled>Tipo</option>
                            <option value=\"\">Todos</option>
                            <option value=\"MB\">Movimientos básicos</option>
                            <option value=\"CC\">Movimientos CC</option>
                            <option value=\"VP\">Venta de productos</option>
                          </select>
                        </div>
                        
                        <div class=\"form-group select-class\">
                            <select class=\"form-control\" id=\"rubro\" name=\"rubro\" value=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "rubro"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Rubro</option>
                                ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rubros"]) ? $context["rubros"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["ru"]) {
            // line 45
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ru"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ru"], "nombre", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ru'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "                             </select>
                        </div>
                        
                        <div class=\"form-group select-class\">
                            <select class=\"form-control\" id=\"usuario\" name=\"usuario\" value=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "usuario"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Usuario</option>
                                ";
        // line 53
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["usuarios"]) ? $context["usuarios"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["us"]) {
            // line 54
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "nombrecompleto", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['us'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "                             </select>
                        </div>
                        
                        <div class=\"select-class2\">
                            <div class=\"form-group\">
                                    Desde
                                    <input type='date' class=\"\" id=\"fd\"name=\"fd\" value=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "fd"), "method"), "html", null, true);
        echo "\" />
                            </div>
                            
                            <div class=\"form-group\">
                                    Hasta
                                    <input type='date' class=\"\" id=\"fh\"name=\"fh\" value=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "fh"), "method"), "html", null, true);
        echo "\" />
                            </div>
                        
                        <input type=\"submit\" value=\"buscar\" class=\"btn btn-success\" margin-top=\"5px\">
        \t\t\t\t</div>
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
    <div class=\"container\">
        <div class=\"row\">
    \t
    \t    <div class=\"table-responsive\">
                    <table class=\"table table-hover\">
                        <thead>
                            <tr>
    
    \t\t\t\t\t\t\t<th>";
        // line 85
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Fecha", "m.fecha");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 86
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Monto", "m.monto");
        echo " </th>
    \t\t\t\t\t\t\t<th>";
        // line 87
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Descripcion", "m.descripcion");
        echo " </th>
    \t\t\t\t\t\t\t<th>";
        // line 88
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Rubro", "m.rubro.nombre");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 89
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "D/C", "m.rubro.tipo");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 90
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Tipo", "m.tipo");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 91
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Usuario", "m.usuario.nombrecompleto");
        echo "</th>
    \t\t\t\t\t\t\t<th>";
        // line 92
        echo "Acciones";
        echo "</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 97
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["movimiento"]) {
            // line 98
            echo "                                <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "id", array()), "html", null, true);
            echo "\">
                                    
                                    <td>";
            // line 100
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["movimiento"], "fecha", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                    <td>\$ ";
            // line 101
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "monto", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute($context["movimiento"], "descripcion", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 103
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "nombre", array()), "html", null, true);
            echo "</td>
                                    
                                    <td>
                                        ";
            // line 106
            if (($this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "tipo", array()) == "C")) {
                // line 107
                echo "                                            <strong>Crédito</strong>
                                        ";
            }
            // line 108
            echo "    
                                        ";
            // line 109
            if (($this->getAttribute($this->getAttribute($context["movimiento"], "rubro", array()), "tipo", array()) == "D")) {
                // line 110
                echo "                                            <strong>Débito</strong>
                                        ";
            }
            // line 111
            echo "    
                                    </td>
                                    
                                    
                                    <td>
                                        ";
            // line 116
            if (($this->getAttribute($context["movimiento"], "tipo", array()) == "MB")) {
                // line 117
                echo "                                            <strong>Movimiento de caja básico</strong>
                                        ";
            }
            // line 118
            echo "    
                                        ";
            // line 119
            if (($this->getAttribute($context["movimiento"], "tipo", array()) == "CC")) {
                // line 120
                echo "                                            <strong>Movimiento de CC - ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["movimiento"], "alumnocc", array()), "usuario", array()), "nombrecompleto", array()), "html", null, true);
                echo "</strong>
                                        ";
            }
            // line 121
            echo "   
                                        ";
            // line 122
            if (($this->getAttribute($context["movimiento"], "tipo", array()) == "VP")) {
                // line 123
                echo "                                            <strong>Venta de productos</strong>
                                        ";
            }
            // line 124
            echo "   
                                    </td>
                                    
                                    <td>";
            // line 127
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["movimiento"], "usuario", array()), "nombrecompleto", array()), "html", null, true);
            echo "</td>
                                    <td class=\"actions\">
                                        <a href=\"";
            // line 129
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_details", array("id" => $this->getAttribute($context["movimiento"], "id", array()))), "html", null, true);
            echo "\" 
                                        ";
            // line 130
            if ((($this->getAttribute($context["movimiento"], "tipo", array()) == "MB") || ($this->getAttribute($context["movimiento"], "tipo", array()) == "CC"))) {
                // line 131
                echo "                                            class=\"btn btn-sm btn-primary disabled\"
                                        ";
            } elseif (($this->getAttribute(            // line 132
$context["movimiento"], "tipo", array()) == "VP")) {
                echo " 
                                            class=\"btn btn-sm btn-primary\"
                                        ";
            }
            // line 134
            echo "  
                                        >
                                            detalles
                                        </a>
                                         <a href=\"";
            // line 138
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_delete", array("id" => $this->getAttribute($context["movimiento"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-danger btn-delete\" onclick=\"return confirm('Está seguro?')\">
    \t\t\t                            eliminar
    \t\t\t                        </a>
                                    </td>
    
                                </tr>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['movimiento'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 145
        echo "                        </tbody>
                    </table>
                   
               <H4> ";
        // line 148
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("Total Movimientos:", array(), "messages");
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                    <div class=\"navigation\">
                        ";
        // line 150
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                    </div>
    
                </div>   
                    
                </div>
            </div>
        </div>
 </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Detalleventa:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  334 => 150,  327 => 148,  322 => 145,  309 => 138,  303 => 134,  297 => 132,  294 => 131,  292 => 130,  288 => 129,  283 => 127,  278 => 124,  274 => 123,  272 => 122,  269 => 121,  263 => 120,  261 => 119,  258 => 118,  254 => 117,  252 => 116,  245 => 111,  241 => 110,  239 => 109,  236 => 108,  232 => 107,  230 => 106,  224 => 103,  220 => 102,  216 => 101,  212 => 100,  206 => 98,  202 => 97,  194 => 92,  190 => 91,  186 => 90,  182 => 89,  178 => 88,  174 => 87,  170 => 86,  166 => 85,  145 => 67,  137 => 62,  129 => 56,  118 => 54,  114 => 53,  109 => 51,  103 => 47,  92 => 45,  88 => 44,  83 => 42,  70 => 32,  58 => 23,  44 => 12,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Detalleventa:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Detalleventa/index.html.twig");
    }
}
