<?php

/* CYAYogaBundle:Usuario:home.html.twig */
class __TwigTemplate_daa528e6b19d34153de5c2c9874fd7be6524ea491a54e395863194f706731e55 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:home.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "\t";
        $this->displayParentBlock("body", $context, $blocks);
        echo " 
\t";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/success.html.twig");
        echo "
    ";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/danger.html.twig");
        echo "
\t<div class=\"container\">
\t\t<div class=\"row\">
\t\t    <div class=\"home-avatar\">
\t\t\t    <span>
\t\t            <img src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/img/avatar.jpg"), "html", null, true);
        echo "\" class=\"img-circle\"/> 
\t\t        </span>
\t\t        <h2 class=\"bienvenido\">
\t\t            Bienvenido ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "username", array()), "html", null, true);
        echo "
\t\t            <!-- <small>
\t\t            ";
        // line 16
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "rol", array()) == "ROLE_ADMIN")) {
            // line 17
            echo "\t\t                Administrador
\t\t            ";
        } elseif (($this->getAttribute($this->getAttribute(        // line 18
(isset($context["app"]) ? $context["app"] : null), "user", array()), "rol", array()) == "ROLE_USER")) {
            // line 19
            echo "\t\t                Usuario
\t\t            ";
        } elseif (($this->getAttribute($this->getAttribute(        // line 20
(isset($context["app"]) ? $context["app"] : null), "user", array()), "rol", array()) == "ROLE_SUPER")) {
            // line 21
            echo "\t\t                Superadmin
\t\t            ";
        }
        // line 23
        echo "\t\t            </small>
\t\t            -->
\t\t        </h2>
\t\t        <div class=\"clearfix\"></div>
\t        </div>
        </div>
\t</div>
\t";
        // line 30
        if (($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_SUPER") || $this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN"))) {
            // line 31
            echo "\t<div class=\"container home\">
\t    <div class=\"row\">
    \t        <div class=\"col-sm-4\">
    \t        \t<div class=\"top alumnos\"><i class=\"icon ion-android-people\"></i> <h2>Usuarios</h2></div>
    \t        \t<div class=\"box\">
    \t        \t\t<ul class=\"list-group\">
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 38
            echo twig_escape_filter($this->env, (isset($context["usuariosa"]) ? $context["usuariosa"] : null), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Usuarios activos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 42
            echo twig_escape_filter($this->env, (isset($context["usuariosi"]) ? $context["usuariosi"] : null), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Usuarios Inactivos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 46
            echo twig_escape_filter($this->env, (isset($context["usuariost"]) ? $context["usuariost"] : null), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Total
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<a href=\"";
            // line 50
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_rapido");
            echo "\" class=\"btn home-usuario\"><i class=\"icon ion-android-people\"></i><span>Carga rápida de usuario</span></a>
    \t        \t</div>
    \t        </div>
\t       
\t        
    \t        <div class=\"col-sm-4\">
    \t        \t<div class=\"top producto\"><i class=\"icon ion-bag\"></i> <h2>Productos y lockers</h2></div>
    \t            <div class=\"box\">
    \t        \t\t<ul class=\"list-group\">
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 60
            echo twig_escape_filter($this->env, (isset($context["productos"]) ? $context["productos"] : null), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Productos activos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 64
            echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : null), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Stock 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 68
            echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : null), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Lockers 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<a href=\"";
            // line 72
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_rapido");
            echo "\" class=\"btn home-usuario productos\"><i class=\"icon ion-bag\"></i><span>Nuevo producto</span></a>
\t\t\t\t\t\t<a href=\"";
            // line 73
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_locker_add");
            echo "\" class=\"btn home-usuario productos\"><i class=\"icon ion-unlocked\"></i><span>Nuevo locker</span></a>
    \t        \t</div>
    \t        </div>
\t        
\t         <a href=\"";
            // line 77
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_add");
            echo "\">
    \t        <div class=\"col-sm-4 caja\">
    \t            <i class=\"icon ion-ios-box\"></i>
    \t            <h2>CAJA</h2>
    \t        </div>
\t         </a>
\t          <a href=\"";
            // line 83
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_index");
            echo "\">
\t        <div class=\"col-sm-6 cuenta\">
\t            <i class=\"icon ion-card\"></i>
\t            <h2>CUENTA CORRIENTE</h2>
\t        </div>
\t        </a>
\t    </div>
\t</div>
\t";
        }
        // line 92
        echo "\t
\t
\t";
        // line 94
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 95
            echo "\t<div class=\"container home\">
\t    <div class=\"row\">
\t        <a href=\"";
            // line 97
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_editpublic");
            echo "\">
    \t        <div class=\"col-sm-6 alumnos\">
    \t            <i class=\"icon ion-android-people\"></i>
    \t            <h2>EDITAR USUARIO</h2>
    \t        </div>
\t        </a>
\t          <a href=\"";
            // line 103
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_indexpublic");
            echo "\">
\t        <div class=\"col-sm-6 cuenta\">
\t            <i class=\"icon ion-card\"></i>
\t            <h2>CUENTA CORRIENTE</h2>
\t        </div>
\t        </a>
\t    </div>
\t</div>
\t";
        }
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 103,  192 => 97,  188 => 95,  186 => 94,  182 => 92,  170 => 83,  161 => 77,  154 => 73,  150 => 72,  143 => 68,  136 => 64,  129 => 60,  116 => 50,  109 => 46,  102 => 42,  95 => 38,  86 => 31,  84 => 30,  75 => 23,  71 => 21,  69 => 20,  66 => 19,  64 => 18,  61 => 17,  59 => 16,  54 => 14,  48 => 11,  40 => 6,  36 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Usuario:home.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/home.html.twig");
    }
}
