<?php

/* CYAYogaBundle:Usuario:add.html.twig */
class __TwigTemplate_4dcfb9f2d18d71d0418bce25ed2fbc4597c48ee850b6724def453494bd44257d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8727a4be772988045c63a8de7f9ece2d96cbb6f923dcb0a74f27c2b8cc17d925 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8727a4be772988045c63a8de7f9ece2d96cbb6f923dcb0a74f27c2b8cc17d925->enter($__internal_8727a4be772988045c63a8de7f9ece2d96cbb6f923dcb0a74f27c2b8cc17d925_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Usuario:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8727a4be772988045c63a8de7f9ece2d96cbb6f923dcb0a74f27c2b8cc17d925->leave($__internal_8727a4be772988045c63a8de7f9ece2d96cbb6f923dcb0a74f27c2b8cc17d925_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e786cfdd5017ceaff11f618299b3fa9b2925bd1d023a87f18c9e2489557a0ec8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e786cfdd5017ceaff11f618299b3fa9b2925bd1d023a87f18c9e2489557a0ec8->enter($__internal_e786cfdd5017ceaff11f618299b3fa9b2925bd1d023a87f18c9e2489557a0ec8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Usuario:add.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <h2>Agregar nuevo usuario </h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar al listado de usuarios
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                
            </div>
        </div>
    </div>
    
           
     <div class=\"container grey-input\">
        
        <div class=\"modulo-form\">
        
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                 
             ";
        // line 31
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
            


                 <div class=\"form-group\">
                     Usuario
                     ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombreusuario", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre de Usuario")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombreusuario", array()), 'errors');
        echo " </span>
                 </div>
                     

            </div>
            <div class=\"col-sm-4\">
  
                <div class=\"form-group\">
                         DNI
                         ";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dni", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "DNI")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dni", array()), 'errors');
        echo " </span>
               </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         ";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'label');
        echo "
                         ";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            <div class=\"col-sm-4\"> 
                     <div class=\"form-group\">
                         ";
        // line 62
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "apellido", array()), 'label');
        echo "
                         ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "apellido", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Apellido")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "apellido", array()), 'errors');
        echo " </span>
                     </div>
            </div>
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         Fecha de Nacimiento
                         ";
        // line 70
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechanacimiento", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha de Nacimiento")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 71
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechanacimiento", array()), 'errors');
        echo " </span>
                 </div>
            </div> 
        </div>
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <div class=\"form-group\">
                     Dirección
                     ";
        // line 79
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "direccion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Dirección")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 80
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "direccion", array()), 'errors');
        echo " </span>
                 </div>
            </div>

            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                    Ciudad/Provincia
                     ";
        // line 87
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "ciudad", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Ciudad/Provincia")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 88
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "ciudad", array()), 'errors');
        echo " </span>
                 </div>
            </div>
          </div>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                 <div class=\"form-group\">
                     Mail
                     ";
        // line 96
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mail", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Mail")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 97
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mail", array()), 'errors');
        echo " </span>
                 </div>
                 </div>
            <div class=\"col-sm-4\">
                  <div class=\"form-group\">
                     Teléfono
                     ";
        // line 103
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telefono", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Teléfono")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 104
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telefono", array()), 'errors');
        echo " </span>
                 </div>
           
            </div>
          </div>
     
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                    Fecha de Ingreso
                     ";
        // line 115
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechaingreso", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha Ingreso")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 116
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechaingreso", array()), 'errors');
        echo " </span>
                 </div>
                
            </div>
                    <div class=\"col-sm-4\">
                <div class=\"form-group\">
                       Fecha de Re-Ingreso (se generarán las deudas de cta. cte a partir de esta fecha) 
                     ";
        // line 123
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechareingreso", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Fecha Reingreso")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 124
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fechareingreso", array()), 'errors');
        echo " </span>
                </div>
            </div>
        </div>   
        
    
    
      
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Tipo de Cuota
                     ";
        // line 137
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipocuota", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 138
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipocuota", array()), 'errors');
        echo " </span>
                 </div>
            </div>
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Rol
                     ";
        // line 144
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "rol", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 145
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "rol", array()), 'errors');
        echo " </span>
                 </div>
            </div>
        </div>
           
        <div class=\"row\">
            <div class=\"col-sm-4\">

                     ";
        // line 153
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "password", array()), 'label');
        echo "
                     ";
        // line 154
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "password", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Password")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 155
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "password", array()), 'errors');
        echo " </span>
        
                  </div> 
                            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 161
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'widget');
        echo "
                         <span class=\"text-danger\"> ";
        // line 162
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
                 </div>    
        </div>      
                
              
             </div>
              <p>
                     ";
        // line 171
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Agregar Usuario", "attr" => array("class" => "btn alumnos-btn")));
        echo "
                 </p>

                 ";
        // line 174
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
         </div>
                 
     </div>
     
    
";
        
        $__internal_e786cfdd5017ceaff11f618299b3fa9b2925bd1d023a87f18c9e2489557a0ec8->leave($__internal_e786cfdd5017ceaff11f618299b3fa9b2925bd1d023a87f18c9e2489557a0ec8_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  322 => 174,  316 => 171,  304 => 162,  300 => 161,  291 => 155,  287 => 154,  283 => 153,  272 => 145,  268 => 144,  259 => 138,  255 => 137,  239 => 124,  235 => 123,  225 => 116,  221 => 115,  207 => 104,  203 => 103,  194 => 97,  190 => 96,  179 => 88,  175 => 87,  165 => 80,  161 => 79,  150 => 71,  146 => 70,  137 => 64,  133 => 63,  129 => 62,  121 => 57,  117 => 56,  113 => 55,  103 => 48,  99 => 47,  87 => 38,  83 => 37,  74 => 31,  50 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <h2>Agregar nuevo usuario </h2>
                    <a href=\"{{ path('cya_usuario_index') }}\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar al listado de usuarios
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                
            </div>
        </div>
    </div>
    
           
     <div class=\"container grey-input\">
        
        <div class=\"modulo-form\">
        
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                 
             {{ form_start(form, {'attr' : {'role' : 'form'}, 'action':'', 'method':'POST' }) }}
            


                 <div class=\"form-group\">
                     Usuario
                     {{ form_widget(form.nombreusuario, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Nombre de Usuario'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.nombreusuario) }} </span>
                 </div>
                     

            </div>
            <div class=\"col-sm-4\">
  
                <div class=\"form-group\">
                         DNI
                         {{ form_widget(form.dni, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'DNI'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.dni) }} </span>
               </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         {{ form_label(form.nombre) }}
                         {{ form_widget(form.nombre, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Nombre'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.nombre) }} </span>
                    </div>
            </div>
            <div class=\"col-sm-4\"> 
                     <div class=\"form-group\">
                         {{ form_label(form.apellido) }}
                         {{ form_widget(form.apellido, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Apellido'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.apellido) }} </span>
                     </div>
            </div>
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         Fecha de Nacimiento
                         {{ form_widget(form.fechanacimiento, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Fecha de Nacimiento'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.fechanacimiento) }} </span>
                 </div>
            </div> 
        </div>
        <div class=\"row\">
            <div class=\"col-sm-8\">
                <div class=\"form-group\">
                     Dirección
                     {{ form_widget(form.direccion, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Dirección'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.direccion) }} </span>
                 </div>
            </div>

            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                    Ciudad/Provincia
                     {{ form_widget(form.ciudad, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Ciudad/Provincia'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.ciudad) }} </span>
                 </div>
            </div>
          </div>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                 <div class=\"form-group\">
                     Mail
                     {{ form_widget(form.mail, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Mail'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.mail) }} </span>
                 </div>
                 </div>
            <div class=\"col-sm-4\">
                  <div class=\"form-group\">
                     Teléfono
                     {{ form_widget(form.telefono, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Teléfono'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.telefono) }} </span>
                 </div>
           
            </div>
          </div>
     
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                    Fecha de Ingreso
                     {{ form_widget(form.fechaingreso, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Fecha Ingreso'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.fechaingreso) }} </span>
                 </div>
                
            </div>
                    <div class=\"col-sm-4\">
                <div class=\"form-group\">
                       Fecha de Re-Ingreso (se generarán las deudas de cta. cte a partir de esta fecha) 
                     {{ form_widget(form.fechareingreso, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Fecha Reingreso'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.fechareingreso) }} </span>
                </div>
            </div>
        </div>   
        
    
    
      
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Tipo de Cuota
                     {{ form_widget(form.tipocuota, { 'attr' : { 'class' : 'form-control'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.tipocuota) }} </span>
                 </div>
            </div>
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Rol
                     {{ form_widget(form.rol, { 'attr' : { 'class' : 'form-control'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.rol) }} </span>
                 </div>
            </div>
        </div>
           
        <div class=\"row\">
            <div class=\"col-sm-4\">

                     {{ form_label(form.password) }}
                     {{ form_widget(form.password, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Password'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.password) }} </span>
        
                  </div> 
                            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.isActive) }}
                         <span class=\"text-danger\"> {{ form_errors(form.isActive) }} </span>
                     </label>
                 </div>
                 </div>    
        </div>      
                
              
             </div>
              <p>
                     {{ form_widget(form.save, {'label' : 'Agregar Usuario', 'attr': {'class': 'btn alumnos-btn'} }) }}
                 </p>

                 {{ form_end(form) }}
         </div>
                 
     </div>
     
    
{% endblock %}

", "CYAYogaBundle:Usuario:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/add.html.twig");
    }
}
