<?php

/* CYAYogaBundle:Tipocuota:add.html.twig */
class __TwigTemplate_bd570d3483ebdf929f5ed1c742cd5c859d2f70f5a19498a21ecd6b678c478e9a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Tipocuota:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_646cf11cbfeeadcdec72688faedb5c31383cbed05b7b1e1ad1e64319bd18dafc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_646cf11cbfeeadcdec72688faedb5c31383cbed05b7b1e1ad1e64319bd18dafc->enter($__internal_646cf11cbfeeadcdec72688faedb5c31383cbed05b7b1e1ad1e64319bd18dafc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Tipocuota:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_646cf11cbfeeadcdec72688faedb5c31383cbed05b7b1e1ad1e64319bd18dafc->leave($__internal_646cf11cbfeeadcdec72688faedb5c31383cbed05b7b1e1ad1e64319bd18dafc_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3cf56313b50fa3a523a5ab3662171f60230fb8976af8f1220a1f435caad4157d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cf56313b50fa3a523a5ab3662171f60230fb8976af8f1220a1f435caad4157d->enter($__internal_3cf56313b50fa3a523a5ab3662171f60230fb8976af8f1220a1f435caad4157d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Tipocuota:add.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo tipo de cuota</h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_tipocuota_index");
        echo "\" class=\"head-link\">
    \t\t\t        <h3>
    \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
    \t\t\t            regresar al listado
    \t\t\t         </h3>
    \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>
    
    ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
           
     <div class=\"container grey-input\">
        <div class=\"row\">
            
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Nombre
                     ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nombre", array()), 'errors');
        echo " </span>
               </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                <div class=\"form-group\">
                     Valor
                     ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "valor", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Valor")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "valor", array()), 'errors');
        echo " </span>
                </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "instructorado", array()), 'widget');
        echo " Profesorado 1er. Nivel
                         <span class=\"text-danger\"> ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "instructorado", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "clasesyoga", array()), 'widget');
        echo " Clases de yoga
                         <span class=\"text-danger\"> ";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "clasesyoga", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "asociacion", array()), 'widget');
        echo " Asociacion
                         <span class=\"text-danger\"> ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "asociacion", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 72
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "profesorado", array()), 'widget');
        echo " Profesorado 2do. Nivel
                         <span class=\"text-danger\"> ";
        // line 73
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "profesorado", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "posgrado", array()), 'widget');
        echo " Posgrado
                         <span class=\"text-danger\"> ";
        // line 82
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "posgrado", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 90
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "casillero", array()), 'widget');
        echo " Casillero
                         <span class=\"text-danger\"> ";
        // line 91
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "casillero", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 99
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "otro", array()), 'widget');
        echo " Otro
                         <span class=\"text-danger\"> ";
        // line 100
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "otro", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-12\">
                ";
        // line 106
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Agregar tipo de cuota", "attr" => array("class" => "btn alumnos-btn")));
        echo "
            </div>
            
            ";
        // line 109
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
         </div>
     </div>
";
        
        $__internal_3cf56313b50fa3a523a5ab3662171f60230fb8976af8f1220a1f435caad4157d->leave($__internal_3cf56313b50fa3a523a5ab3662171f60230fb8976af8f1220a1f435caad4157d_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Tipocuota:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  212 => 109,  206 => 106,  197 => 100,  193 => 99,  182 => 91,  178 => 90,  167 => 82,  163 => 81,  152 => 73,  148 => 72,  137 => 64,  133 => 63,  122 => 55,  118 => 54,  107 => 46,  103 => 45,  93 => 38,  89 => 37,  79 => 30,  75 => 29,  64 => 21,  50 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo tipo de cuota</h2>
                    <a href=\"{{ path('cya_tipocuota_index') }}\" class=\"head-link\">
    \t\t\t        <h3>
    \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
    \t\t\t            regresar al listado
    \t\t\t         </h3>
    \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>
    
    {{ form_start(form, {'attr' : {'role' : 'form'}, 'action':'', 'method':'POST' }) }}
           
     <div class=\"container grey-input\">
        <div class=\"row\">
            
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Nombre
                     {{ form_widget(form.nombre, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Nombre'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.nombre) }} </span>
               </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                <div class=\"form-group\">
                     Valor
                     {{ form_widget(form.valor, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Valor'} }) }}
                     <span class=\"text-danger\"> {{ form_errors(form.valor) }} </span>
                </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.instructorado) }} Profesorado 1er. Nivel
                         <span class=\"text-danger\"> {{ form_errors(form.instructorado) }} </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.clasesyoga) }} Clases de yoga
                         <span class=\"text-danger\"> {{ form_errors(form.clasesyoga) }} </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.asociacion) }} Asociacion
                         <span class=\"text-danger\"> {{ form_errors(form.asociacion) }} </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.profesorado) }} Profesorado 2do. Nivel
                         <span class=\"text-danger\"> {{ form_errors(form.profesorado) }} </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.posgrado) }} Posgrado
                         <span class=\"text-danger\"> {{ form_errors(form.posgrado) }} </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.casillero) }} Casillero
                         <span class=\"text-danger\"> {{ form_errors(form.casillero) }} </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.otro) }} Otro
                         <span class=\"text-danger\"> {{ form_errors(form.otro) }} </span>
                     </label>
                 </div>
            </div>
            
            <div class=\"col-sm-12\">
                {{ form_widget(form.save, {'label' : 'Agregar tipo de cuota', 'attr': {'class': 'btn alumnos-btn'} }) }}
            </div>
            
            {{ form_end(form) }}
         </div>
     </div>
{% endblock %}

", "CYAYogaBundle:Tipocuota:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Tipocuota/add.html.twig");
    }
}
