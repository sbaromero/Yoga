<?php

/* CYAYogaBundle:Movimiento:details.html.twig */
class __TwigTemplate_abeda5cf8889a6d03b95ed09fe531ab5385c4bfbed66bd2cc1b3249374bf22b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Movimiento:details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23b85dc1034c1ff9939f6f0ae59f5d4dad4a8c5af9e0cae725ca49e06220c71f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23b85dc1034c1ff9939f6f0ae59f5d4dad4a8c5af9e0cae725ca49e06220c71f->enter($__internal_23b85dc1034c1ff9939f6f0ae59f5d4dad4a8c5af9e0cae725ca49e06220c71f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Movimiento:details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_23b85dc1034c1ff9939f6f0ae59f5d4dad4a8c5af9e0cae725ca49e06220c71f->leave($__internal_23b85dc1034c1ff9939f6f0ae59f5d4dad4a8c5af9e0cae725ca49e06220c71f_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_a3f1ae86f8d7a58fc70e72cd824911436bc0febd11627018f9ca68c381b67454 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a3f1ae86f8d7a58fc70e72cd824911436bc0febd11627018f9ca68c381b67454->enter($__internal_a3f1ae86f8d7a58fc70e72cd824911436bc0febd11627018f9ca68c381b67454_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Movimiento:details.html.twig"));

        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Movimiento:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Movimiento:messages/danger.html.twig");
        echo "
    <div class=\"container-fluid caja\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Detalle de venta</h2>
                    <h2> Fecha: ";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["fecha"]) ? $context["fecha"] : $this->getContext($context, "fecha")), "html", null, true);
        echo "</h2>
\t\t\t\t\t<h2> Monto: \$";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["total"]) ? $context["total"] : $this->getContext($context, "total")), "html", null, true);
        echo "</h2>
                </div>
\t\t\t\t\t
                
                
                <div class=\"col-sm-7\">
                    <form action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_index");
        echo "\" class=\"btn btn-success\">
                            Regresar
                        </a>
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 39
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Producto", "m.nombreproducto");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 40
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Cantidad", "m.cantidad");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 41
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Precio unitario", "m.producto.precio");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 42
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Precio Total", "m.precioproducto");
        echo "</th>
\t\t\t\t\t\t
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 47
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["detalleventa"]) {
            // line 48
            echo "                                
                                <td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["detalleventa"], "nombreproducto", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["detalleventa"], "cantidad", array()), "html", null, true);
            echo "</td>
                                <td>\$";
            // line 51
            echo twig_escape_filter($this->env, ($this->getAttribute($context["detalleventa"], "precioproducto", array()) / $this->getAttribute($context["detalleventa"], "cantidad", array())), "html", null, true);
            echo "</td>
                                <td>\$ ";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute($context["detalleventa"], "precioproducto", array()), "html", null, true);
            echo "</td>
                                
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['detalleventa'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "                    </tbody>

                </table>
           <H4> Total Productos: ";
        // line 59
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                <div class=\"navigation\">
                    ";
        // line 61
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_a3f1ae86f8d7a58fc70e72cd824911436bc0febd11627018f9ca68c381b67454->leave($__internal_a3f1ae86f8d7a58fc70e72cd824911436bc0febd11627018f9ca68c381b67454_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Movimiento:details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 61,  146 => 59,  141 => 56,  131 => 52,  127 => 51,  123 => 50,  119 => 49,  116 => 48,  112 => 47,  104 => 42,  100 => 41,  96 => 40,  92 => 39,  71 => 21,  61 => 14,  57 => 13,  48 => 7,  44 => 6,  40 => 5,  34 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

  
{% block body %}
{{ parent() }}
{{ include('CYAYogaBundle:Movimiento:messages/success.html.twig')}}
{{ include('CYAYogaBundle:Movimiento:messages/danger.html.twig')}}
    <div class=\"container-fluid caja\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Detalle de venta</h2>
                    <h2> Fecha: {{ fecha }}</h2>
\t\t\t\t\t<h2> Monto: \${{ total }}</h2>
                </div>
\t\t\t\t\t
                
                
                <div class=\"col-sm-7\">
                    <form action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <a href=\"{{ path('cya_movimiento_index') }}\" class=\"btn btn-success\">
                            Regresar
                        </a>
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Producto', 'm.nombreproducto') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Cantidad', 'm.cantidad') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Precio unitario', 'm.producto.precio') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Precio Total', 'm.precioproducto') }}</th>
\t\t\t\t\t\t
                        </tr>
                    </thead>
                    <tbody>
                        {% for detalleventa in pagination %}
                                
                                <td>{{ detalleventa.nombreproducto }}</td>
                                <td>{{ detalleventa.cantidad }}</td>
                                <td>\${{ detalleventa.precioproducto/detalleventa.cantidad }}</td>
                                <td>\$ {{ detalleventa.precioproducto }}</td>
                                
                            </tr>
                        {% endfor %}
                    </tbody>

                </table>
           <H4> Total Productos: {{ pagination.getTotalItemCount }}</H4>
                <div class=\"navigation\">
                    {{ knp_pagination_render(pagination) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "CYAYogaBundle:Movimiento:details.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Movimiento/details.html.twig");
    }
}
