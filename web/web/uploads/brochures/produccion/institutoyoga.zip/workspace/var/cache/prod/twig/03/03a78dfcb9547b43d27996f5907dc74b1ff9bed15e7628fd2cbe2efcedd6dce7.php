<?php

/* CYAYogaBundle:Usuario:index.html.twig */
class __TwigTemplate_6083d344607fd8b00b67e2cd728cf05de36996009fa631c5849fb21411662f10 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/danger.html.twig");
        echo "
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Usuarios</h2>
                    <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_add");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t            <span><i class=\"icon ion-android-person-add\"></i></span>
        \t\t\t            agregar nuevo usuario
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        <div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "query"), "method"), "html", null, true);
        echo "\" class=\"form-control\" placeholder=\"Buscar Usuario por Apellido, Nombre o DNI\" />
        \t\t\t\t</div>
        \t\t\t\t
        \t\t\t\t<div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"estado\"name=\"estado\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "estado"), "method"), "html", null, true);
        echo "\">
                            <option value=\"3\">Todos</option>
                            <option value=\"1\">Activos</option>
                            <option value=\"0\">Inactivos</option>
                          </select>
                        </div>
                        
                        <br>
                        <br>
                        
                        <div class=\"form-group select-class\">
                            <select class=\"form-control\" id=\"tipocuota\" name=\"tipocuota\" value=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "tipocuota"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Buscar por Tipo de cuota</option>
                                ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tipocuotas"]) ? $context["tipocuotas"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["tc"]) {
            // line 41
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tc"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tc"], "nombre", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tc'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "                             </select>
                        </div>
                        
        \t\t\t\t
        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-default\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 63
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Usuario", "u.apellido");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 64
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "DNI", "u.dni");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 65
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Teléfono", "u.telefono");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 66
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Mail", "u.mail");
        echo "</th>
\t\t\t\t\t\t\t<th>Tipo de Cuota</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 72
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["usuario"]) {
            // line 73
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td colspan=\"1\"> <img src=\"";
            // line 75
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/img/avatar.jpg"), "html", null, true);
            echo "\" class=\"avatar-tabla\" />  ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "apellido", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "nombre", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "dni", array()), "html", null, true);
            echo "</td>
                                 <td>";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "telefono", array()), "html", null, true);
            echo "</td>
                                 <td>";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "mail", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 79
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["usuario"], "tipocuota", array()), "nombre", array()), "html", null, true);
            echo "</td>
                               
                               
                                <td class=\"actions\">
                                    <a href=\"";
            // line 83
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_view", array("id" => $this->getAttribute($context["usuario"], "id", array()))), "html", null, true);
            echo "\"class=\"btn btn-sm btn-primary\">
                                        <i class=\"icon ion-eye\"></i> Ver
                                    </a>
                                    <a href=\"";
            // line 86
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_edit", array("id" => $this->getAttribute($context["usuario"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                                        <i class=\"icon ion-wand\"></i> Editar
                                    </a>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['usuario'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 92
        echo "                    </tbody>
                </table>
           <H4> Total Usuarios: ";
        // line 94
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                <div class=\"navigation\">
                    ";
        // line 96
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  209 => 96,  204 => 94,  200 => 92,  188 => 86,  182 => 83,  175 => 79,  171 => 78,  167 => 77,  163 => 76,  155 => 75,  149 => 73,  145 => 72,  136 => 66,  132 => 65,  128 => 64,  124 => 63,  102 => 43,  91 => 41,  87 => 40,  82 => 38,  68 => 27,  61 => 23,  48 => 13,  39 => 7,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Usuario:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/index.html.twig");
    }
}
