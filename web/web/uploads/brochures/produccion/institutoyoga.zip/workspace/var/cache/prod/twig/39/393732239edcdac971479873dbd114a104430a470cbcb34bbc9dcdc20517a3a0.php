<?php

/* CYAYogaBundle:Rubro:add.html.twig */
class __TwigTemplate_c8de85a98d6fcc1399270bde11a6b0fdafda43a93434a74333b2ef1ce9936e49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Rubro:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid caja\">
        <div class=\"container caja-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo Rubro de Caja</h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_rubro_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar a rubros
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>
    
    ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
           
     <div class=\"container grey-input\">
        <div class=\"row\">
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         ";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'label');
        echo "
                         ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'errors');
        echo " </span>
                    </div>
            </div>

             <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipo", array()), 'label');
        echo "
                     ";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipo", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipo", array()), 'errors');
        echo " </span>
                 </div>
            </div>
            
            <div class=\"col-sm-4\"> 
               <div class=\"checkbox\">
                 <label>
                     ";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isActive", array()), 'widget');
        echo " Activo
                     <span class=\"text-danger\"> ";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isActive", array()), 'errors');
        echo " </span>
                 </label>
             </div>
            
            
            <div class=\"col-sm-12\">
                
                ";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Agregar Rubro", "attr" => array("class" => "btn alumnos-btn")));
        echo "
                 
                
            </div>
            ";
        // line 56
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
         </div>
     </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Rubro:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 56,  113 => 52,  103 => 45,  99 => 44,  89 => 37,  85 => 36,  81 => 35,  72 => 29,  68 => 28,  64 => 27,  55 => 21,  41 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Rubro:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Rubro/add.html.twig");
    }
}
