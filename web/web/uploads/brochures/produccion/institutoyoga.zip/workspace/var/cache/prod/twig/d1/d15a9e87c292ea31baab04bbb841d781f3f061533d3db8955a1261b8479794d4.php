<?php

/* CYAYogaBundle:Security:login.html.twig */
class __TwigTemplate_ad6239d586951aa5008782532417d06328e57f91992c52293fa184810b673cf9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Security:login.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/signin.css"), "html", null, true);
        echo "\">
";
    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        // line 10
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-4 col-sm-offset-4\">
                <form action=\"";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_yoga_login_check");
        echo "\" method=\"post\" class=\"form-signin\">
        \t\t\t<h2 class=\"form-signin-heading\">Por favor, regístrese</h2>
        
                    ";
        // line 17
        if ((isset($context["error"]) ? $context["error"] : null)) {
            // line 18
            echo "                    <div class=\"text-danger\">
                        <p>
                            <strong>
                                ";
            // line 21
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : null), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : null), "messageData", array()), "security"), "html", null, true);
            echo "
                            </strong>
                        </p>
                    </div>
                    ";
        }
        // line 26
        echo "                    
                    <span class=\"sign-in-avatar\">
                        <img src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/img/avatar.jpg"), "html", null, true);
        echo "\"/> 
                    </span>
        
        \t\t    <label for=\"username\" class=\"sr-only\">";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Username"), "html", null, true);
        echo ":</label>
        \t\t    <input type=\"text\" id=\"username\" class=\"form-control\" name=\"_nombreusuario\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : null), "html", null, true);
        echo "\" placeholder=\"Nombre de Usuario\" required autofocus />
        
        \t\t    <label for=\"password\" class=\"sr-only\">";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Password"), "html", null, true);
        echo ":</label>
        \t\t    <input type=\"password\" id=\"password\" class=\"form-control\" name=\"_password\" placeholder=\"Contraseña\" required />
        \t\t    
        \t\t    <input type=\"hidden\" name=\"_target_path\" value=\"cya_yoga_home\" />
        
        \t\t    <button type=\"submit\" class=\"btn btn-lg btn-sign-in\">Registrarse</button>
        \t\t</form>
            </div>
        </div>
\t\t
    </div> <!-- /container -->
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 34,  87 => 32,  83 => 31,  77 => 28,  73 => 26,  65 => 21,  60 => 18,  58 => 17,  52 => 14,  46 => 10,  43 => 8,  37 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Security:login.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Security/login.html.twig");
    }
}
