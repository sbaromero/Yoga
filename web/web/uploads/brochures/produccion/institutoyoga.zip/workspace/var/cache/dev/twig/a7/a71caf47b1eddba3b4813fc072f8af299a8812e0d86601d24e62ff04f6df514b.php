<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_05fe1f61a8d75254237da69575d1cb0e609c6efa7d93d50a695ea2fa0bf8479c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dfcfe29f29c95c979f78c92c7c64d1a6d61aa253df1316b2ecb69ef9c314af7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dfcfe29f29c95c979f78c92c7c64d1a6d61aa253df1316b2ecb69ef9c314af7b->enter($__internal_dfcfe29f29c95c979f78c92c7c64d1a6d61aa253df1316b2ecb69ef9c314af7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_dfcfe29f29c95c979f78c92c7c64d1a6d61aa253df1316b2ecb69ef9c314af7b->leave($__internal_dfcfe29f29c95c979f78c92c7c64d1a6d61aa253df1316b2ecb69ef9c314af7b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/home/ubuntu/workspace/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}
