<?php

/* CYAYogaBundle:Tipocuota:index.html.twig */
class __TwigTemplate_565cb20edf40f60ca264fb86825fee290428da293424685919e2d5aa7e26f619 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Tipocuota:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_80cb8834e82b6161479f73ae2a891d90d5a9ef245ee92e2cefcc93e33827dd65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80cb8834e82b6161479f73ae2a891d90d5a9ef245ee92e2cefcc93e33827dd65->enter($__internal_80cb8834e82b6161479f73ae2a891d90d5a9ef245ee92e2cefcc93e33827dd65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Tipocuota:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_80cb8834e82b6161479f73ae2a891d90d5a9ef245ee92e2cefcc93e33827dd65->leave($__internal_80cb8834e82b6161479f73ae2a891d90d5a9ef245ee92e2cefcc93e33827dd65_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_9cb13b13740c8e17dee447e993e7db70cb15cd0f65269fa548e6822a4a6cc767 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cb13b13740c8e17dee447e993e7db70cb15cd0f65269fa548e6822a4a6cc767->enter($__internal_9cb13b13740c8e17dee447e993e7db70cb15cd0f65269fa548e6822a4a6cc767_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Tipocuota:index.html.twig"));

        // line 4
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Tipocuota:messages/success.html.twig");
        echo "
<div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Tipos de Cuota</h2>
                    <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_tipocuota_add");
        echo "\" class=\"head-link\">
    \t\t\t        <h3>
    \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
    \t\t\t            Nuevo tipo de cuota
    \t\t\t         </h3>
    \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t<div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"\" class=\"form-control\" placeholder=\"Buscar tipo de cuota\" required />
        \t\t\t\t</div>
        \t\t\t\t<input type=\"submit\" value=\"buscar\" class=\"btn btn-default\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 37
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Nombre", "t.nombre");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 38
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Valor", "t.valor");
        echo " </th>
\t\t\t\t\t\t\t<th>";
        // line 39
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Profesorado 1er. Nivel", "t.instructorado");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 40
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Clases de yoga", "t.clasesyoga");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 41
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Asociacion", "t.asociacion");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 42
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Profesorado 2do. Nivel", "t.profesorado");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 43
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Posgrado", "t.posgrado");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 44
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Casillero", "t.casillero");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 45
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Otro", "t.otro");
        echo "</th>
                            <th>Acciones</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["tipocuota"]) {
            // line 52
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipocuota"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipocuota"], "nombre", array()), "html", null, true);
            echo "</td>
                                <td>\$ ";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipocuota"], "valor", array()), "html", null, true);
            echo "</td>
                                <td>
                                    ";
            // line 57
            if (($this->getAttribute($context["tipocuota"], "instructorado", array()) == 1)) {
                // line 58
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 59
            echo "    
                                    ";
            // line 60
            if (($this->getAttribute($context["tipocuota"], "instructorado", array()) == 0)) {
                // line 61
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 62
            echo "    
                                </td>
                                <td>
                                    ";
            // line 65
            if (($this->getAttribute($context["tipocuota"], "clasesyoga", array()) == 1)) {
                // line 66
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 67
            echo "    
                                    ";
            // line 68
            if (($this->getAttribute($context["tipocuota"], "clasesyoga", array()) == 0)) {
                // line 69
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 70
            echo "    
                                </td>
                                <td>
                                    ";
            // line 73
            if (($this->getAttribute($context["tipocuota"], "asociacion", array()) == 1)) {
                // line 74
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 75
            echo "    
                                    ";
            // line 76
            if (($this->getAttribute($context["tipocuota"], "asociacion", array()) == 0)) {
                // line 77
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 78
            echo "    
                                </td>
                                <td>
                                    ";
            // line 81
            if (($this->getAttribute($context["tipocuota"], "profesorado", array()) == 1)) {
                // line 82
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 83
            echo "    
                                    ";
            // line 84
            if (($this->getAttribute($context["tipocuota"], "profesorado", array()) == 0)) {
                // line 85
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 86
            echo "    
                                </td>
                                <td>
                                    ";
            // line 89
            if (($this->getAttribute($context["tipocuota"], "posgrado", array()) == 1)) {
                // line 90
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 91
            echo "    
                                    ";
            // line 92
            if (($this->getAttribute($context["tipocuota"], "posgrado", array()) == 0)) {
                // line 93
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 94
            echo "    
                                </td>
                                <td>
                                    ";
            // line 97
            if (($this->getAttribute($context["tipocuota"], "casillero", array()) == 1)) {
                // line 98
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 99
            echo "    
                                    ";
            // line 100
            if (($this->getAttribute($context["tipocuota"], "casillero", array()) == 0)) {
                // line 101
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 102
            echo "    
                                </td>
                                <td>
                                    ";
            // line 105
            if (($this->getAttribute($context["tipocuota"], "otro", array()) == 1)) {
                // line 106
                echo "                                        <strong>SI</strong>
                                    ";
            }
            // line 107
            echo "    
                                    ";
            // line 108
            if (($this->getAttribute($context["tipocuota"], "otro", array()) == 0)) {
                // line 109
                echo "                                        <strong>No</strong>
                                    ";
            }
            // line 110
            echo "    
                                </td>

                                <td class=\"actions\">
                                    <a href=\"";
            // line 114
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_tipocuota_edit", array("id" => $this->getAttribute($context["tipocuota"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                                    Editar
                                    </a>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tipocuota'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 120
        echo "                    </tbody>
                </table>
           <H4> Total Tipos de cuota: ";
        // line 122
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
        echo "</H4>
                ";
        // line 124
        echo "                <div class=\"navigation\">
                    ";
        // line 125
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_9cb13b13740c8e17dee447e993e7db70cb15cd0f65269fa548e6822a4a6cc767->leave($__internal_9cb13b13740c8e17dee447e993e7db70cb15cd0f65269fa548e6822a4a6cc767_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Tipocuota:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  306 => 125,  303 => 124,  299 => 122,  295 => 120,  283 => 114,  277 => 110,  273 => 109,  271 => 108,  268 => 107,  264 => 106,  262 => 105,  257 => 102,  253 => 101,  251 => 100,  248 => 99,  244 => 98,  242 => 97,  237 => 94,  233 => 93,  231 => 92,  228 => 91,  224 => 90,  222 => 89,  217 => 86,  213 => 85,  211 => 84,  208 => 83,  204 => 82,  202 => 81,  197 => 78,  193 => 77,  191 => 76,  188 => 75,  184 => 74,  182 => 73,  177 => 70,  173 => 69,  171 => 68,  168 => 67,  164 => 66,  162 => 65,  157 => 62,  153 => 61,  151 => 60,  148 => 59,  144 => 58,  142 => 57,  137 => 55,  133 => 54,  127 => 52,  123 => 51,  114 => 45,  110 => 44,  106 => 43,  102 => 42,  98 => 41,  94 => 40,  90 => 39,  86 => 38,  82 => 37,  53 => 11,  44 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
{{ parent() }}
{{ include('CYAYogaBundle:Tipocuota:messages/success.html.twig')}}
<div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Tipos de Cuota</h2>
                    <a href=\"{{ path('cya_tipocuota_add') }}\" class=\"head-link\">
    \t\t\t        <h3>
    \t\t\t           <span><i class=\"icon ion-plus\"></i></span>
    \t\t\t            Nuevo tipo de cuota
    \t\t\t         </h3>
    \t\t\t    </a>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
        \t\t\t\t<div class=\"form-group\">
        \t\t\t\t\t<input type=\"text\" size=\"40\" name=\"query\" value=\"\" class=\"form-control\" placeholder=\"Buscar tipo de cuota\" required />
        \t\t\t\t</div>
        \t\t\t\t<input type=\"submit\" value=\"buscar\" class=\"btn btn-default\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Nombre', 't.nombre') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Valor', 't.valor') }} </th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Profesorado 1er. Nivel', 't.instructorado') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Clases de yoga', 't.clasesyoga') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Asociacion', 't.asociacion') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Profesorado 2do. Nivel', 't.profesorado') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Posgrado', 't.posgrado') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Casillero', 't.casillero') }}</th>
\t\t\t\t\t\t\t<th>{{ knp_pagination_sortable(pagination, 'Otro', 't.otro') }}</th>
                            <th>Acciones</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        {% for tipocuota in pagination %}
                            <tr data-id=\"{{ tipocuota.id }}\">
                                
                                <td>{{ tipocuota.nombre }}</td>
                                <td>\$ {{ tipocuota.valor }}</td>
                                <td>
                                    {% if tipocuota.instructorado == 1  %}
                                        <strong>SI</strong>
                                    {% endif %}    
                                    {% if tipocuota.instructorado == 0 %}
                                        <strong>No</strong>
                                    {% endif %}    
                                </td>
                                <td>
                                    {% if tipocuota.clasesyoga == 1  %}
                                        <strong>SI</strong>
                                    {% endif %}    
                                    {% if tipocuota.clasesyoga == 0 %}
                                        <strong>No</strong>
                                    {% endif %}    
                                </td>
                                <td>
                                    {% if tipocuota.asociacion == 1  %}
                                        <strong>SI</strong>
                                    {% endif %}    
                                    {% if tipocuota.asociacion == 0 %}
                                        <strong>No</strong>
                                    {% endif %}    
                                </td>
                                <td>
                                    {% if tipocuota.profesorado == 1  %}
                                        <strong>SI</strong>
                                    {% endif %}    
                                    {% if tipocuota.profesorado == 0 %}
                                        <strong>No</strong>
                                    {% endif %}    
                                </td>
                                <td>
                                    {% if tipocuota.posgrado == 1  %}
                                        <strong>SI</strong>
                                    {% endif %}    
                                    {% if tipocuota.posgrado == 0 %}
                                        <strong>No</strong>
                                    {% endif %}    
                                </td>
                                <td>
                                    {% if tipocuota.casillero == 1  %}
                                        <strong>SI</strong>
                                    {% endif %}    
                                    {% if tipocuota.casillero == 0 %}
                                        <strong>No</strong>
                                    {% endif %}    
                                </td>
                                <td>
                                    {% if tipocuota.otro == 1  %}
                                        <strong>SI</strong>
                                    {% endif %}    
                                    {% if tipocuota.otro == 0 %}
                                        <strong>No</strong>
                                    {% endif %}    
                                </td>

                                <td class=\"actions\">
                                    <a href=\"{{ path('cya_tipocuota_edit', {id: tipocuota.id }) }}\" class=\"btn btn-sm btn-primary\">
                                    Editar
                                    </a>
                                </td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
           <H4> Total Tipos de cuota: {{ pagination.getTotalItemCount }}</H4>
                {# display navigation #}
                <div class=\"navigation\">
                    {{ knp_pagination_render(pagination) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}", "CYAYogaBundle:Tipocuota:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Tipocuota/index.html.twig");
    }
}
