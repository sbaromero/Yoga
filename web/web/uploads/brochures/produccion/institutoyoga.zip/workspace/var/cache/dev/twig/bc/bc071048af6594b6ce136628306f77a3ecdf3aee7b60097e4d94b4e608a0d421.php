<?php

/* CYAYogaBundle:Producto:add.html.twig */
class __TwigTemplate_454d8b5d043d82fc2a1e1ac3a2b80f19883fb3cede1b402a27165a963e4fa82c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Producto:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a258381bbfecc8b47bf11dbc812690a39cb1d498e8f43193bfdad0bb925e7306 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a258381bbfecc8b47bf11dbc812690a39cb1d498e8f43193bfdad0bb925e7306->enter($__internal_a258381bbfecc8b47bf11dbc812690a39cb1d498e8f43193bfdad0bb925e7306_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Producto:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a258381bbfecc8b47bf11dbc812690a39cb1d498e8f43193bfdad0bb925e7306->leave($__internal_a258381bbfecc8b47bf11dbc812690a39cb1d498e8f43193bfdad0bb925e7306_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_34fe25cc55d57bf7e293d4395e0959324c421a6d675534769df17ca333031cbc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34fe25cc55d57bf7e293d4395e0959324c421a6d675534769df17ca333031cbc->enter($__internal_34fe25cc55d57bf7e293d4395e0959324c421a6d675534769df17ca333031cbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Producto:add.html.twig"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid producto\">
        <div class=\"container producto-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo Producto</h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_producto_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar a listado de productos
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>
    
    ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
           
     <div class=\"container grey-input\">
       <div class=\"row\">
         <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'widget');
        echo " 
                         <span class=\"text-danger\"> ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isActive", array()), 'errors');
        echo " </span>
                     </label>
                 </div>
            </div>
         </div>
      
        <div class=\"row\">
            <div class=\"col-sm-8\"> 
                    <div class=\"form-group\">
                         ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "descripcion", array()), 'label');
        echo "
                         ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "descripcion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "descripcion", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            
        </div>
        <div class=\"row\">
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         Costo \$
                         ";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "costo", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Costo")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "costo", array()), 'errors');
        echo " </span>
                    </div>
            </div>
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         Precio de Lista \$
                         ";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "preciolista", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Precio Lista")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "preciolista", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "stock", array()), 'label');
        echo "
                         ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "stock", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Stock")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 65
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "stock", array()), 'errors');
        echo " </span>
                    </div>
            </div>
         </div>  
         
         <div class=\"row\">
             <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         Tipo de Producto
                         ";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipoproducto", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Tipo Producto")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipoproducto", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                          Proveedor
                         ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "proveedor", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Proveedor")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 82
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "proveedor", array()), 'errors');
        echo " </span>
                    </div>
            </div>

         </div>  
         
         
         
         
         
      <div class=\"row\">   
     <div class=\"col-sm-12\">
                
                ";
        // line 95
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("label" => "Agregar producto", "attr" => array("class" => "btn alumnos-btn")));
        echo "
                 
                
          </div>
       </div>   
           
    ";
        // line 101
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
        
     </div>
";
        
        $__internal_34fe25cc55d57bf7e293d4395e0959324c421a6d675534769df17ca333031cbc->leave($__internal_34fe25cc55d57bf7e293d4395e0959324c421a6d675534769df17ca333031cbc_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Producto:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  198 => 101,  189 => 95,  173 => 82,  169 => 81,  160 => 75,  156 => 74,  144 => 65,  140 => 64,  136 => 63,  127 => 57,  123 => 56,  114 => 50,  110 => 49,  98 => 40,  94 => 39,  90 => 38,  78 => 29,  74 => 28,  64 => 21,  50 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    {{ parent() }}
    <div class=\"container-fluid producto\">
        <div class=\"container producto-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Nuevo Producto</h2>
                    <a href=\"{{ path('cya_producto_index') }}\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar a listado de productos
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
            </div>
        </div>
    </div>
    
    {{ form_start(form, {'attr' : {'role' : 'form'}, 'action':'', 'method':'POST' }) }}
           
     <div class=\"container grey-input\">
       <div class=\"row\">
         <div class=\"col-sm-4\"> 
                   <div class=\"checkbox\">
                     <label>
                         {{ form_widget(form.isActive) }} 
                         <span class=\"text-danger\"> {{ form_errors(form.isActive) }} </span>
                     </label>
                 </div>
            </div>
         </div>
      
        <div class=\"row\">
            <div class=\"col-sm-8\"> 
                    <div class=\"form-group\">
                         {{ form_label(form.descripcion) }}
                         {{ form_widget(form.descripcion, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Descripción'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.descripcion) }} </span>
                    </div>
            </div>
            
        </div>
        <div class=\"row\">
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         Costo \$
                         {{ form_widget(form.costo, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Costo'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.costo) }} </span>
                    </div>
            </div>
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         Precio de Lista \$
                         {{ form_widget(form.preciolista, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Precio Lista'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.preciolista) }} </span>
                    </div>
            </div>
            
             <div class=\"col-sm-2\"> 
                    <div class=\"form-group\">
                         {{ form_label(form.stock) }}
                         {{ form_widget(form.stock, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Stock'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.stock) }} </span>
                    </div>
            </div>
         </div>  
         
         <div class=\"row\">
             <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         Tipo de Producto
                         {{ form_widget(form.tipoproducto, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Tipo Producto'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.tipoproducto) }} </span>
                    </div>
            </div>
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                          Proveedor
                         {{ form_widget(form.proveedor, { 'attr' : { 'class' : 'form-control', 'placeholder' : 'Proveedor'} }) }}
                         <span class=\"text-danger\"> {{ form_errors(form.proveedor) }} </span>
                    </div>
            </div>

         </div>  
         
         
         
         
         
      <div class=\"row\">   
     <div class=\"col-sm-12\">
                
                {{ form_widget(form.save, {'label' : 'Agregar producto', 'attr': {'class': 'btn alumnos-btn'} }) }}
                 
                
          </div>
       </div>   
           
    {{ form_end(form) }}
        
     </div>
{% endblock %}

", "CYAYogaBundle:Producto:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Producto/add.html.twig");
    }
}
