<?php

/* CYAYogaBundle:Usuario:usuariorapido.html.twig */
class __TwigTemplate_e93fed5f61e4998a7d1fbb37e616734ca43c219225d667119083ba9730faad1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:usuariorapido.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid alumnos\">
        <div class=\"container alumnos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <h2>Carga Rápida de Usuario </h2>
                    <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_index");
        echo "\" class=\"head-link\">
        \t\t\t        <h3>
        \t\t\t           <span><i class=\"icon ion-android-arrow-dropleft back\"></i></span>
        \t\t\t            regresar al listado de usuarios
        \t\t\t         </h3>
        \t\t\t    </a>
                </div>
                
            </div>
        </div>
    </div>
    
           
     <div class=\"container grey-input\">
        
        <div class=\"modulo-form\">
        
        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                 
             ";
        // line 31
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
            


                 <div class=\"form-group\">
                     Usuario
                     ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombreusuario", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre de Usuario")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombreusuario", array()), 'errors');
        echo " </span>
                 </div>
                     

            </div>
            <div class=\"col-sm-4\">
  
                <div class=\"form-group\">
                         DNI
                         ";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dni", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "DNI")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dni", array()), 'errors');
        echo " </span>
               </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-sm-4\"> 
                    <div class=\"form-group\">
                         ";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'label');
        echo "
                         ";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "nombre", array()), 'errors');
        echo " </span>
                    </div>
            </div>
            <div class=\"col-sm-4\"> 
                     <div class=\"form-group\">
                         ";
        // line 62
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "apellido", array()), 'label');
        echo "
                         ";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "apellido", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Apellido")));
        echo "
                         <span class=\"text-danger\"> ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "apellido", array()), 'errors');
        echo " </span>
                     </div>
            </div>

        </div>

        
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"form-group\">
                     Tipo de Cuota
                     ";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipocuota", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 76
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "tipocuota", array()), 'errors');
        echo " </span>
                 </div>
            </div>
        </div>
           
        <div class=\"row\">
            <div class=\"col-sm-4\">

                     ";
        // line 84
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "password", array()), 'label');
        echo "
                     ";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "password", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Password")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 86
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "password", array()), 'errors');
        echo " </span>
        
                  </div> 
                            
        </div>      
                
              
             </div>
              <p>
                     ";
        // line 95
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Agregar Usuario", "attr" => array("class" => "btn alumnos-btn")));
        echo "
                 </p>

                 ";
        // line 98
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
         </div>
                 
     </div>
     
    
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:usuariorapido.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  183 => 98,  177 => 95,  165 => 86,  161 => 85,  157 => 84,  146 => 76,  142 => 75,  128 => 64,  124 => 63,  120 => 62,  112 => 57,  108 => 56,  104 => 55,  94 => 48,  90 => 47,  78 => 38,  74 => 37,  65 => 31,  41 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Usuario:usuariorapido.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/usuariorapido.html.twig");
    }
}
