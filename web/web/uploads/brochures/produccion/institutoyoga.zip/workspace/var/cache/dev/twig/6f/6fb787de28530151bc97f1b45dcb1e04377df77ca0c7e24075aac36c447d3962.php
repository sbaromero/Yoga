<?php

/* CYAYogaBundle:Usuario:home.html.twig */
class __TwigTemplate_01d45f0f578eb90f06abfd0df79d2333ac5fdb19d0de42c5ea8c858a4d191980 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Usuario:home.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_54b204a8cda36481b9a4aae0f7dacb4d432637c434bf2f5e9161551aa79d7313 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54b204a8cda36481b9a4aae0f7dacb4d432637c434bf2f5e9161551aa79d7313->enter($__internal_54b204a8cda36481b9a4aae0f7dacb4d432637c434bf2f5e9161551aa79d7313_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CYAYogaBundle:Usuario:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_54b204a8cda36481b9a4aae0f7dacb4d432637c434bf2f5e9161551aa79d7313->leave($__internal_54b204a8cda36481b9a4aae0f7dacb4d432637c434bf2f5e9161551aa79d7313_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_2f9e3f3f8922ef1e89133056b485b14104c7466b9cbd8e68d874ee2fdcb569fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f9e3f3f8922ef1e89133056b485b14104c7466b9cbd8e68d874ee2fdcb569fb->enter($__internal_2f9e3f3f8922ef1e89133056b485b14104c7466b9cbd8e68d874ee2fdcb569fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "CYAYogaBundle:Usuario:home.html.twig"));

        // line 4
        echo "\t";
        $this->displayParentBlock("body", $context, $blocks);
        echo " 
\t";
        // line 5
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/success.html.twig");
        echo "
    ";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Usuario:messages/danger.html.twig");
        echo "
\t<div class=\"container\">
\t\t<div class=\"row\">
\t\t    <div class=\"home-avatar\">
\t\t\t    <span>
\t\t            <img src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/img/avatar.jpg"), "html", null, true);
        echo "\" class=\"img-circle\"/> 
\t\t        </span>
\t\t        <h2 class=\"bienvenido\">
\t\t            Bienvenido ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo "
\t\t            <!-- <small>
\t\t            ";
        // line 16
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "rol", array()) == "ROLE_ADMIN")) {
            // line 17
            echo "\t\t                Administrador
\t\t            ";
        } elseif (($this->getAttribute($this->getAttribute(        // line 18
(isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "rol", array()) == "ROLE_USER")) {
            // line 19
            echo "\t\t                Usuario
\t\t            ";
        } elseif (($this->getAttribute($this->getAttribute(        // line 20
(isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "rol", array()) == "ROLE_SUPER")) {
            // line 21
            echo "\t\t                Superadmin
\t\t            ";
        }
        // line 23
        echo "\t\t            </small>
\t\t            -->
\t\t        </h2>
\t\t        <div class=\"clearfix\"></div>
\t        </div>
        </div>
\t</div>
\t";
        // line 30
        if (($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_SUPER") || $this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN"))) {
            // line 31
            echo "\t<div class=\"container home\">
\t    <div class=\"row\">
    \t        <div class=\"col-sm-4\">
    \t        \t<div class=\"top alumnos\"><i class=\"icon ion-android-people\"></i> <h2>Usuarios</h2></div>
    \t        \t<div class=\"box\">
    \t        \t\t<ul class=\"list-group\">
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 38
            echo twig_escape_filter($this->env, (isset($context["usuariosa"]) ? $context["usuariosa"] : $this->getContext($context, "usuariosa")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Usuarios activos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 42
            echo twig_escape_filter($this->env, (isset($context["usuariosi"]) ? $context["usuariosi"] : $this->getContext($context, "usuariosi")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Usuarios Inactivos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 46
            echo twig_escape_filter($this->env, (isset($context["usuariost"]) ? $context["usuariost"] : $this->getContext($context, "usuariost")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Total
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<a href=\"";
            // line 50
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_rapido");
            echo "\" class=\"btn home-usuario\"><i class=\"icon ion-android-people\"></i><span>Carga rápida de usuario</span></a>
    \t        \t</div>
    \t        </div>
\t       
\t        
    \t        <div class=\"col-sm-4\">
    \t        \t<div class=\"top producto\"><i class=\"icon ion-bag\"></i> <h2>Productos y lockers</h2></div>
    \t            <div class=\"box\">
    \t        \t\t<ul class=\"list-group\">
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 60
            echo twig_escape_filter($this->env, (isset($context["productos"]) ? $context["productos"] : $this->getContext($context, "productos")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Productos activos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 64
            echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : $this->getContext($context, "saldo")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Stock 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">";
            // line 68
            echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : $this->getContext($context, "saldo")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t    Lockers 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<a href=\"";
            // line 72
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_rapido");
            echo "\" class=\"btn home-usuario productos\"><i class=\"icon ion-bag\"></i><span>Nuevo producto</span></a>
\t\t\t\t\t\t<a href=\"";
            // line 73
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_locker_add");
            echo "\" class=\"btn home-usuario productos\"><i class=\"icon ion-unlocked\"></i><span>Nuevo locker</span></a>
    \t        \t</div>
    \t        </div>
\t        
\t         <a href=\"";
            // line 77
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_movimiento_add");
            echo "\">
    \t        <div class=\"col-sm-4 caja\">
    \t            <i class=\"icon ion-ios-box\"></i>
    \t            <h2>CAJA</h2>
    \t        </div>
\t         </a>
\t          <a href=\"";
            // line 83
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_index");
            echo "\">
\t        <div class=\"col-sm-6 cuenta\">
\t            <i class=\"icon ion-card\"></i>
\t            <h2>CUENTA CORRIENTE</h2>
\t        </div>
\t        </a>
\t    </div>
\t</div>
\t";
        }
        // line 92
        echo "\t
\t
\t";
        // line 94
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 95
            echo "\t<div class=\"container home\">
\t    <div class=\"row\">
\t        <a href=\"";
            // line 97
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_usuario_editpublic");
            echo "\">
    \t        <div class=\"col-sm-6 alumnos\">
    \t            <i class=\"icon ion-android-people\"></i>
    \t            <h2>EDITAR USUARIO</h2>
    \t        </div>
\t        </a>
\t          <a href=\"";
            // line 103
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_indexpublic");
            echo "\">
\t        <div class=\"col-sm-6 cuenta\">
\t            <i class=\"icon ion-card\"></i>
\t            <h2>CUENTA CORRIENTE</h2>
\t        </div>
\t        </a>
\t    </div>
\t</div>
\t";
        }
        
        $__internal_2f9e3f3f8922ef1e89133056b485b14104c7466b9cbd8e68d874ee2fdcb569fb->leave($__internal_2f9e3f3f8922ef1e89133056b485b14104c7466b9cbd8e68d874ee2fdcb569fb_prof);

    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Usuario:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 103,  201 => 97,  197 => 95,  195 => 94,  191 => 92,  179 => 83,  170 => 77,  163 => 73,  159 => 72,  152 => 68,  145 => 64,  138 => 60,  125 => 50,  118 => 46,  111 => 42,  104 => 38,  95 => 31,  93 => 30,  84 => 23,  80 => 21,  78 => 20,  75 => 19,  73 => 18,  70 => 17,  68 => 16,  63 => 14,  57 => 11,  49 => 6,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
\t{{ parent() }} 
\t{{ include('CYAYogaBundle:Usuario:messages/success.html.twig')}}
    {{ include('CYAYogaBundle:Usuario:messages/danger.html.twig')}}
\t<div class=\"container\">
\t\t<div class=\"row\">
\t\t    <div class=\"home-avatar\">
\t\t\t    <span>
\t\t            <img src=\"{{ asset('public/img/avatar.jpg') }}\" class=\"img-circle\"/> 
\t\t        </span>
\t\t        <h2 class=\"bienvenido\">
\t\t            Bienvenido {{ app.user.username }}
\t\t            <!-- <small>
\t\t            {% if app.user.rol == 'ROLE_ADMIN' %}
\t\t                Administrador
\t\t            {% elseif app.user.rol == 'ROLE_USER' %}
\t\t                Usuario
\t\t            {% elseif app.user.rol == 'ROLE_SUPER' %}
\t\t                Superadmin
\t\t            {% endif %}
\t\t            </small>
\t\t            -->
\t\t        </h2>
\t\t        <div class=\"clearfix\"></div>
\t        </div>
        </div>
\t</div>
\t{% if is_granted('ROLE_SUPER') or is_granted('ROLE_ADMIN') %}
\t<div class=\"container home\">
\t    <div class=\"row\">
    \t        <div class=\"col-sm-4\">
    \t        \t<div class=\"top alumnos\"><i class=\"icon ion-android-people\"></i> <h2>Usuarios</h2></div>
    \t        \t<div class=\"box\">
    \t        \t\t<ul class=\"list-group\">
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">{{ usuariosa }}</span>
\t\t\t\t\t\t\t    Usuarios activos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">{{ usuariosi }}</span>
\t\t\t\t\t\t\t    Usuarios Inactivos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">{{ usuariost }}</span>
\t\t\t\t\t\t\t    Total
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<a href=\"{{ path('cya_usuario_rapido') }}\" class=\"btn home-usuario\"><i class=\"icon ion-android-people\"></i><span>Carga rápida de usuario</span></a>
    \t        \t</div>
    \t        </div>
\t       
\t        
    \t        <div class=\"col-sm-4\">
    \t        \t<div class=\"top producto\"><i class=\"icon ion-bag\"></i> <h2>Productos y lockers</h2></div>
    \t            <div class=\"box\">
    \t        \t\t<ul class=\"list-group\">
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">{{ productos }}</span>
\t\t\t\t\t\t\t    Productos activos 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">{{ saldo }}</span>
\t\t\t\t\t\t\t    Stock 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"list-group-item\">
\t\t\t\t\t\t\t    <span class=\"badge\">{{ saldo }}</span>
\t\t\t\t\t\t\t    Lockers 
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<a href=\"{{ path('cya_usuario_rapido') }}\" class=\"btn home-usuario productos\"><i class=\"icon ion-bag\"></i><span>Nuevo producto</span></a>
\t\t\t\t\t\t<a href=\"{{ path('cya_locker_add') }}\" class=\"btn home-usuario productos\"><i class=\"icon ion-unlocked\"></i><span>Nuevo locker</span></a>
    \t        \t</div>
    \t        </div>
\t        
\t         <a href=\"{{ path('cya_movimiento_add') }}\">
    \t        <div class=\"col-sm-4 caja\">
    \t            <i class=\"icon ion-ios-box\"></i>
    \t            <h2>CAJA</h2>
    \t        </div>
\t         </a>
\t          <a href=\"{{ path('cya_alumnocc_index') }}\">
\t        <div class=\"col-sm-6 cuenta\">
\t            <i class=\"icon ion-card\"></i>
\t            <h2>CUENTA CORRIENTE</h2>
\t        </div>
\t        </a>
\t    </div>
\t</div>
\t{% endif %}
\t
\t
\t{% if is_granted('ROLE_USER') %}
\t<div class=\"container home\">
\t    <div class=\"row\">
\t        <a href=\"{{ path('cya_usuario_editpublic') }}\">
    \t        <div class=\"col-sm-6 alumnos\">
    \t            <i class=\"icon ion-android-people\"></i>
    \t            <h2>EDITAR USUARIO</h2>
    \t        </div>
\t        </a>
\t          <a href=\"{{ path('cya_alumnocc_indexpublic') }}\">
\t        <div class=\"col-sm-6 cuenta\">
\t            <i class=\"icon ion-card\"></i>
\t            <h2>CUENTA CORRIENTE</h2>
\t        </div>
\t        </a>
\t    </div>
\t</div>
\t{% endif %}
{% endblock %}", "CYAYogaBundle:Usuario:home.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Usuario/home.html.twig");
    }
}
