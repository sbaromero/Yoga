<?php

/* CYAYogaBundle:Detalleventa:add.html.twig */
class __TwigTemplate_bd592320e3524bd93244d7302b3eb06f6175bfdd0823116fb1a2f38fc0b680ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Detalleventa:add.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Detalleventa:messages/success.html.twig");
        echo "


<div class=\"container-fluid producto\">
        <div class=\"container productos-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Venta de Productos</h2>
                    <a href=\"";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_maestroventa_add");
        echo "\" class=\"head-link\">
        \t\t\t      <h3>
        \t\t\t           <span><i class=\"icon ion-skip-forward\"></i></span>
    \t\t\t                Confirmar la Venta
        \t\t\t         </h3>
        \t\t\t </a>
                </div>
            </div>
        </div>
</div>



\t<div class=\"container\">
\t    ";
        // line 28
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("attr" => array("role" => "form"), "action" => "", "method" => "POST"));
        echo "
\t    <div class=\"container grey-input\">
       



 
  <div class = row>     
            <div class=\"col-sm-2\"> 
                <div class=\"form-group\">
                     Cantidad
                     ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "cantidad", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Cantidad")));
        echo "
                     <span class=\"text-danger\"> ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "cantidad", array()), 'errors');
        echo " </span>
                </div>
            </div>
       <br>
            <div class=\"col-sm-8\">
            <div class=\"form-group\">
        
            <select class=\"selectpicker\" data-live-search=\"true\" id=\"producto\" name=\"producto\" value=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "producto"), "method"), "html", null, true);
        echo "\">
                <option value=\"\" selected disabled>Producto</option>
                ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["productos"]) ? $context["productos"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["us"]) {
            // line 50
            echo "                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "descripcion", array()), "html", null, true);
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['us'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "             </select>
            </div>
            </div> 
 </div>
 
   <div class = row> 

            <div class=\"col-sm-12\">
                ";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("label" => "Agregar Producto", "attr" => array("class" => "btn alumnos-btn")));
        echo "
            </div>
            
        
          </div>
            ";
        // line 65
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
    </div>
   </div>     
   <br>
   <br>
         <div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 78
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Producto", "m.nombreproducto");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 79
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Cantidad", "m.cantidad");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 80
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Precio unitario", "m.producto.precio");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 81
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Precio Total", "m.precioproducto");
        echo "</th>
\t\t\t\t\t\t
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 86
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["detalleventa"]) {
            // line 87
            echo "                                
                                <td>";
            // line 88
            echo twig_escape_filter($this->env, $this->getAttribute($context["detalleventa"], "nombreproducto", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 89
            echo twig_escape_filter($this->env, $this->getAttribute($context["detalleventa"], "cantidad", array()), "html", null, true);
            echo "</td>
                                <td>\$";
            // line 90
            echo twig_escape_filter($this->env, ($this->getAttribute($context["detalleventa"], "precioproducto", array()) / $this->getAttribute($context["detalleventa"], "cantidad", array())), "html", null, true);
            echo "</td>
                                <td>\$ ";
            // line 91
            echo twig_escape_filter($this->env, $this->getAttribute($context["detalleventa"], "precioproducto", array()), "html", null, true);
            echo "</td>
                                 <td class=\"actions\">
                                         <a href=\"";
            // line 93
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_detalleventa_delete", array("id" => $this->getAttribute($context["detalleventa"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-danger btn-delete\" onclick=\"return confirm('Está seguro?')\">
    \t\t\t                            Eliminar
    \t\t\t                        </a>
                                    </td>
                                
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['detalleventa'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 100
        echo "                    </tbody>

                </table>

           <br>

            <b>
           <H4> ";
        // line 107
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("Total productos cargados:", array(), "messages");
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : null), "getTotalItemCount", array()), "html", null, true);
        echo " </H4> <h4>Monto Total: \$ ";
        echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : null), "html", null, true);
        echo "</h4>
                ";
        // line 109
        echo "                <div class=\"navigation\">
                    ";
        // line 110
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                </div>
             
            </b>
             <br>
              <br>
            </div>
             <a href=\"";
        // line 117
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_maestroventa_add");
        echo "\" class=\"btn alumnos-btn\" onclick=\"return confirm('Está seguro?')\">
    \t\t Confirmar Venta
    \t\t</a>
                
            </div>
        </div> 
         
         
         
         
 
 ";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Detalleventa:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  232 => 117,  222 => 110,  219 => 109,  211 => 107,  202 => 100,  189 => 93,  184 => 91,  180 => 90,  176 => 89,  172 => 88,  169 => 87,  165 => 86,  157 => 81,  153 => 80,  149 => 79,  145 => 78,  129 => 65,  121 => 60,  111 => 52,  100 => 50,  96 => 49,  91 => 47,  81 => 40,  77 => 39,  63 => 28,  46 => 14,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Detalleventa:add.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Detalleventa/add.html.twig");
    }
}
