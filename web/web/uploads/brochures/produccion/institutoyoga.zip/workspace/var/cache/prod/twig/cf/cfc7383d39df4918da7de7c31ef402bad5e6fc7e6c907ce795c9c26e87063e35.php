<?php

/* CYAYogaBundle:Alumnocc:index.html.twig */
class __TwigTemplate_0db03843bb85796a83faed9d8c7d7edafcdb86f865c11e17718431088e9da967 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "CYAYogaBundle:Alumnocc:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "
";
        // line 6
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/success.html.twig");
        echo "
";
        // line 7
        echo twig_include($this->env, $context, "CYAYogaBundle:Alumnocc:messages/danger.html.twig");
        echo "
    <div class=\"container-fluid cuenta\">
        <div class=\"container cuenta-icon\">
            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <h2>Listado de Cuotas y Cuentas Corrientes de Alumnos </h2>
                   <h4>Leyenda: pc (pago de cuota)  - cc (cuota cancelada) - vp (venta de producto) - pd (pago diario)  </h4>
                </div>
                <div class=\"col-sm-7\">
                    <form method=\"get\" action=\"\" class=\"form-inline pull-right\" role=\"search\">
                        
                        <div class=\"form-group select-class\">
                          <select class=\"form-control\" id=\"pago\" name=\"pago\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "pago"), "method"), "html", null, true);
        echo "\">
                            <option value=\"\" selected disabled>Tipo</option>
                            <option value=\"\">Todas</option>
                            <option value=\"S\">Pagas</option>
                            <option value=\"N\">No pagas</option>
                          </select>
                        </div>
                        
        \t\t\t\t<div class=\"form-group\">
                            <select class=\"selectpicker\" data-live-search=\"true\" id=\"usuario\" name=\"usuario\" value=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "usuario"), "method"), "html", null, true);
        echo "\">
                                <option value=\"\" selected disabled>Usuario</option>
                                ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["usuarios"]) ? $context["usuarios"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["us"]) {
            // line 31
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["us"], "nombrecompleto", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['us'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "                             </select>
                        </div>

        \t\t\t\t<input type=\"submit\" value=\"Buscar\" class=\"btn btn-success\">
        \t\t\t</form>
                </div>
            </div>
        </div>
    </div>
           
            
\t<div class=\"container\">
\t    <div class=\"row\">
\t    \t
\t    <div class=\"table-responsive\">
                <table class=\"table table-hover\">
                    <thead>
                        <tr>

\t\t\t\t\t\t\t<th>";
        // line 52
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Alumno", "a.nombrecompleto");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 53
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Vencimiento Cuota", "a.fechavencimiento");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 54
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Debe", "a.deuda");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 55
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Pagado", "a.pagado");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 56
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Bonificación", "a.bonificacion");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 57
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Modificacion", "a.fechamodificacion");
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 58
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : null), "Tipo", "a.tipo");
        echo "</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 63
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["alumnocc"]) {
            // line 64
            echo "                            <tr data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "id", array()), "html", null, true);
            echo "\">
                                
                                <td>";
            // line 66
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["alumnocc"], "usuario", array()), "apellido", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["alumnocc"], "usuario", array()), "nombre", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 67
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["alumnocc"], "fechavencimiento", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td>";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "deuda", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 69
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "pagado", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "bonificacion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 71
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["alumnocc"], "fechamodificacion", array()), "d m Y - h:i:s"), "html", null, true);
            echo "</td>
                                <td>";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute($context["alumnocc"], "tipo", array()), "html", null, true);
            echo "</td>
                               
                               
                                <td class=\"actions\">
                                    <a href=\"";
            // line 76
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_detallepago", array("id" => $this->getAttribute($context["alumnocc"], "id", array()))), "html", null, true);
            echo "\" 
                                    ";
            // line 77
            if ((($this->getAttribute($context["alumnocc"], "pagado", array()) == 0) || ($this->getAttribute($context["alumnocc"], "tipo", array()) != "VP"))) {
                // line 78
                echo "                                        class=\"btn btn-warning disabled\"
                                    ";
            } elseif ((($this->getAttribute(            // line 79
$context["alumnocc"], "pagado", array()) > 0) || ($this->getAttribute($context["alumnocc"], "tipo", array()) == "VP"))) {
                echo " 
                                        class=\"btn btn-warning\"
                                    ";
            }
            // line 81
            echo " >
                                        detalles
                                    </a>
                                    
                                    <a href=\"";
            // line 85
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_pago", array("id" => $this->getAttribute($context["alumnocc"], "id", array()))), "html", null, true);
            echo "\"
                                        ";
            // line 86
            if (($this->getAttribute($context["alumnocc"], "deuda", array()) <= ($this->getAttribute($context["alumnocc"], "pagado", array()) + $this->getAttribute($context["alumnocc"], "bonificacion", array())))) {
                // line 87
                echo "                                            class=\"btn btn-success disabled\"
                                        ";
            } elseif (($this->getAttribute(            // line 88
$context["alumnocc"], "deuda", array()) > ($this->getAttribute($context["alumnocc"], "pagado", array()) + $this->getAttribute($context["alumnocc"], "bonificacion", array())))) {
                echo " 
                                            class=\"btn btn-success\"
                                        ";
            }
            // line 90
            echo " >
                                        Pagar
                                    </a>
                                    
                                    <a href=\"";
            // line 94
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("cya_alumnocc_delete", array("id" => $this->getAttribute($context["alumnocc"], "id", array()))), "html", null, true);
            echo "\" onclick=\"return confirm('Está seguro??')\"
\t\t\t                            ";
            // line 95
            if (($this->getAttribute($context["alumnocc"], "tipo", array()) == "CC")) {
                // line 96
                echo "                                            class=\"btn btn btn-danger btn-delete\"
                                        ";
            } elseif (($this->getAttribute(            // line 97
$context["alumnocc"], "tipo", array()) == "PD")) {
                echo " 
                                            class=\"btn btn btn-danger btn-delete disabled\"
                                        ";
            } elseif (($this->getAttribute(            // line 99
$context["alumnocc"], "tipo", array()) == "VP")) {
                echo " 
                                            class=\"btn btn btn-danger btn-delete\"
                                        ";
            } elseif (($this->getAttribute(            // line 101
$context["alumnocc"], "tipo", array()) == "PC")) {
                // line 102
                echo "                                         class=\"btn btn btn-danger btn-delete\"   
                                        ";
            }
            // line 103
            echo " >
\t\t\t                            eliminar
\t\t\t                        </a>
                                    
                                </td>
                                
                                
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['alumnocc'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 112
        echo "                    </tbody>
                </table>
           <H4> Total Movimientos: ";
        // line 114
        echo twig_escape_filter($this->env, (isset($context["contador"]) ? $context["contador"] : null), "html", null, true);
        echo "</H4>
          <H4> Total Deudas: ";
        // line 115
        echo twig_escape_filter($this->env, (isset($context["deudas"]) ? $context["deudas"] : null), "html", null, true);
        echo "</H4>
           <H4> Total Pagado: ";
        // line 116
        echo twig_escape_filter($this->env, (isset($context["pagados"]) ? $context["pagados"] : null), "html", null, true);
        echo "</H4>
            <H4> Total Bonificaciones: ";
        // line 117
        echo twig_escape_filter($this->env, (isset($context["bonificaciones"]) ? $context["bonificaciones"] : null), "html", null, true);
        echo "</H4>
            <H4> SALDO TOTAL: ";
        // line 118
        echo twig_escape_filter($this->env, (isset($context["saldo"]) ? $context["saldo"] : null), "html", null, true);
        echo "</H4>
                <div class=\"navigation\">
                    ";
        // line 120
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "CYAYogaBundle:Alumnocc:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  288 => 120,  283 => 118,  279 => 117,  275 => 116,  271 => 115,  267 => 114,  263 => 112,  249 => 103,  245 => 102,  243 => 101,  238 => 99,  233 => 97,  230 => 96,  228 => 95,  224 => 94,  218 => 90,  212 => 88,  209 => 87,  207 => 86,  203 => 85,  197 => 81,  191 => 79,  188 => 78,  186 => 77,  182 => 76,  175 => 72,  171 => 71,  167 => 70,  163 => 69,  159 => 68,  155 => 67,  149 => 66,  143 => 64,  139 => 63,  131 => 58,  127 => 57,  123 => 56,  119 => 55,  115 => 54,  111 => 53,  107 => 52,  86 => 33,  75 => 31,  71 => 30,  66 => 28,  54 => 19,  39 => 7,  35 => 6,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CYAYogaBundle:Alumnocc:index.html.twig", "/home/ubuntu/workspace/src/CYA/YogaBundle/Resources/views/Alumnocc/index.html.twig");
    }
}
